'''Build MODFLOW model using GIS input
BAS, DIS, NWT, SFR, UZF, WEL, UPW, GAGE, OC
Mountain Front RCH, septic, and GW inflow via WEL'''

root=r'S:/'

import arcpy, sys, os, datetime, xlrd, math
import numpy as np
import scipy.ndimage as ndimage
from matplotlib import pyplot as plt

##sys.path.append(r'D:\CarsonValley\wespythoncode\modules')
##import readgis


modnam='CV-wes-9094SS'
#modnam='CV-wes-8194trans'
modir=os.path.join(root,r'CarsonValley\MODFLOW',modnam)
if not os.path.exists(modir):
    os.makedirs(modir)

if 'SS' in modnam:
    period=[(datetime.date(1989,10,1),datetime.date(1994,9,30))]
    tinterval=[period[0][1]-period[0][0]]
elif 'trans' in modnam:
    if 'short' in modnam:
        # stress period information for historicalshort
        period=[(datetime.date(1998,10,1),datetime.date(1999,9,30)),
                (datetime.date(1999,10,1),datetime.date(2013,10,1))]
        tinterval=[period[0][1]-period[0][0],
                    datetime.timedelta(days=7)]
    else:
        # stress period information for historical calibration
        period=[(datetime.date(1981,10,1),datetime.date(1982,9,30)),
                (datetime.date(1982,10,1),datetime.date(1983,9,30)),
                (datetime.date(1983,10,1),datetime.date(1999,10,1))]
        tinterval=[period[0][1]-period[0][0],
                    datetime.timedelta(days=30),
                    datetime.timedelta(days=7)]
elif 'drought' in modnam:
    # Stress period information for megadrought, build tabfiles for PRMS or data driven
    period=[(datetime.date(2010,10,1),datetime.date(2011,9,30)),
            (datetime.date(2011,10,1),datetime.date(2015,10,1)),
            (datetime.date(1986,10,1),datetime.date(1995,10,1))]
    tinterval=[period[0][1]-period[0][0],
                datetime.timedelta(days=7),
                datetime.timedelta(days=7)]
nsp=[]
for per in range(0,len(period)):
    nsp.append((period[per][1]-period[per][0]).days/tinterval[per].days)
sp=[]#period[0][0]] #first date is start of steady state, index 0
for per in range(0,len(period)):
    for dt in range(0,nsp[per]+1):
        sp.append(period[per][0]+datetime.timedelta(days=(dt)*tinterval[per].days))
print('start date: '+str(sp[0])+
    '\nend date: '+str(sp[-1]))
steadyper=period[0][1]-period[0][0]
print('\nsteady-state stress period of: '+str(steadyper.days)+' days'+
    '\nfrom: '+str(sp[0])+' to '+str(sp[1]))
for per in range(0,len(period)):
    print('\nperiod '+str(per+1)+':\n'+str(period[per][0])+' to '+str(period[per][1])+'\n    '+str(nsp[per])+' stress priods of: '+str(tinterval[per].days)+' days\n')
sys.stdout.flush()

# data and GIS filies
GISloc = os.path.join(root,r'CarsonValley\GIS\CV_wk_151231.gdb')
arcpy.env.workspace = os.path.join(GISloc,r'CV_wk_151231.gdb')
gridpts = os.path.join(GISloc,'CV_grid_wk_150825_pts')
ETpts = os.path.join(GISloc,'CV_ET_yager_160108')
ssfpts = os.path.join(GISloc,'CV_SSF_wk_160610_pts')
lakpts = os.path.join(GISloc,'CV_LAK_wk_151008_pts')
sfrpts = os.path.join(GISloc,'CV_SFR_wk_160525_10_GAGE_pts')
wrpts = os.path.join(GISloc,'CV_WR_wk_160120_pts')
pmppts = os.path.join(GISloc,'CV_PMP_wk_160216_final_pts')
pmppoupts = os.path.join(GISloc,'CV_PMP_POU_151201_pts')
hobpts = os.path.join(GISloc,'CV_NWIS_wk_151007_pts')
transpts = os.path.join(GISloc,'CV_transmissivity_160506')
seppts = os.path.join(GISloc,'CV_SEP_wk_150918_pts')
prcpfile=os.path.join(root,r'CarsonValley\precip\NCDC_Minden.xlsx')
prcp_name='GHCND:USC00265191' #GHCND:USC00265191 Minden
lakestagefile=os.path.join(root,r'CarsonValley\lakes\CV - reservoir stage tables.xlsx')
apmpnam=os.path.join(root,r'CarsonValley\wells\wes\CV-wes-annualpumpage-individual-adjpmp.txt')

#grid and geology bits, L#thick refers to non lake layers (i.e. L1 is model layer 2 when lakes are present)
nrow=258
ncol=206
cwidth=550
rwidth=cwidth
AFA2CFD=43560/365.25
nsublay=4 #Does not include lakes. 4 layers need 5 surfaces
Llak=1 #Llak=0 for no lakes
activethick=30 #must be >= minthick
minthick=30 #minium thickness of layers
minchthick=5 #minimum thickness beneath a channel, fails at =1
alluvmax=800 #max thickness of alluvium
minbd=500 #arbitrary thickness of bedrock outside deep basin, thickness of L5 tert in deep basin ~3000
d2Tert=2000 #maximum depth to tertiary sediments, applicable in deep basin
activelak=[1,3,4,5,9]

# play with storage components
# THTS>EXTWC>THTS-Sy; unsat ET comes from >THTS-Sy?????????
#didn't work... steady state approx was pEThi subracted from finf wehre ib[1]=1, pETlo subracted from finf where ib[1]==0
pEThi=0.018 #mean from Middle Carson April-Sept = 0.01fd, high ~0.018.
pETlo=0.004 #mean from Middle Carson Oct-March = 0.003fd.
# Lower Walker pET est 4'/yr = 0.011

uzfET=0 # estimate uzfET in aETfact and consumpfact

##if uzfET==0:
##    aETfact=0.1 #ratio of precip going into finf, the rest is lost to ET
##else:
##    aETfact=1.0
# annual average pET 2.9-4.9 ft/yr from Maurer et al 2005. CV has larger fetch?
irrmeth='upstream' # 'upstream' if water is there, take it regardless of priority. 'equal' flow is ratio of WR acres/total acres
if 'SS' in modnam:
    irrmonths=12.
else:
    irrmonths=7.
annirr=4.0*AFA2CFD*(12./irrmonths) #irrigation rate applied over irrmonth period
if uzfET==0: #fraction of irrigation water going to ET, the rest goes to finf, consumpfact*annirr ~ 3'/yr
    consumpfact=0.75 #this value gets written to sfr
else:
    consumpfact=0
wevap=0#np.mean([pEThi,pETlo])*1.05
finffact=0.12 #fraction of precip as recharge
ssfratio=0.06
extdepth=15
dleak=0.0001
manning=0.03
minsfrslope=0.0000001
seprate=21.5 #21.5 cfd per household, Yager and personal comm therein

#aquifer properties
#storage
Sstorage=[1.e-5,1.e-5,1.e-6,1.e-6,1.e-7,1.e-7]
Sy=[0.10,0.10,0.05,0.05,0.0009,0.0009]
THTS=[0.15,0.15,0.1,0.1,0.001,0.001]
THTRfact=0.1 #THTR=THTRfact*(THTS-Sy); THTR must be smaller than THTR calculated interally in SFR package = THTS-Sy
THTXfact=1.01 #THTX=THTR*THTXfact; 1.01=1% higher than THTR
THTIfact=1.01 #THTI=(THTS-Sy)*THTIfact; 1.01=1% higher than THTR caclulated internally in SFR package = THTS-Sy
#conductivity
EPS=3.5
UHCfact=0.1 #unsat under streams = factor*ib
VKSfact=1.0 #constant VKS of 0.3 from Middle Carson, unsat zone K
factorkv=0.01 #factor multiplied by VK field
lossfactor=0.01
bdlknc=0.001
#pnirrhcfact=0.01
VANIfluv=1.0
VANIalluv=1.0

#reduced K in N end of valley due to fines, spread flow for GWET
KN=1.0
KNrow=(0,0) #rows where KN starts
KNcol=(0,0)
KNtype=[1,2,3]


gelK=[25.,25.,5.,1.,0.1,0.1] #see Maurer and Berger 1997, Eagle Valley
##[40.,15.,4.,0.75,0.75,0.2] #From initial calibration, ML adjustments, and Maurer and Berger 1997, Eagle Valley
gelkey=['Kfl','Kag','Kts','Ktv','Kig','Kmv']
gelnam=['F','A','S','V','G','M']

#initialize arrays
Lbot=np.zeros((nsublay+Llak+1,nrow,ncol)) #nsublay+Llak+1 surfaces for nsublay layers, bottom alt for layer
ib=np.zeros((nsublay+Llak,nrow,ncol),dtype=int)
zone=np.zeros((nsublay+Llak,nrow,ncol),dtype=int)
VKS=np.zeros((nrow,ncol))
VANI=np.zeros((nsublay+Llak,nrow,ncol))
WHSF=np.zeros((nrow,ncol),dtype=int)
metabase=np.zeros((nrow,ncol),dtype=int)
BDLKNC=np.zeros((nrow,ncol))
cellid=np.zeros((nrow,ncol),dtype=int)
d2bd=np.zeros((nrow,ncol))
surfgeo=np.zeros((nrow,ncol),dtype=int)
modext=np.zeros((nrow,ncol),dtype=int)
iuzfbnd=np.zeros((nrow,ncol),dtype=int)
extd=np.zeros((nrow,ncol))
lakid=np.zeros((nrow,ncol),dtype=int)
lakext=np.zeros((nrow,ncol),dtype=int)
Ssarr=np.zeros((nrow,ncol))
Syarr=np.zeros((nrow,ncol))
THTSarr=np.zeros((nrow,ncol))
THTRarr=np.zeros((nrow,ncol))
THTIarr=np.zeros((nrow,ncol))
THTXarr=np.zeros((nrow,ncol))
ewprcp=np.zeros((nrow,ncol),dtype=int)
irunbnd=np.zeros((nrow,ncol),dtype=int)
pET=np.zeros((nrow,ncol))
finf=np.zeros((nrow,ncol))
cell_utm={}
aet_dict={}
prcp_dict={}
pfail_dict={}
res_dict={}
lak_dict={}
seg_dict={}
wr_dict={}
pmp_dict={}
hob_dict={}
wfail_dict={}
ssf_dict={}
sep_dict={}

# make directories
dirs=['bas','dis','divtabs','lak','laktabs','output','intabs','upw','uzf']
dd={} #dictionary of directory names
for d in dirs:
    key='{0}dir'.format(d)
    dd[key]=os.path.join(modir,d)
    if not os.path.exists(dd[key]):
        os.makedirs(dd[key])

#monthly distribution of pumping determined by Yager et al
MOUmonthly={'DOM': [0.02194, 0.02090, 0.02667, 0.05446, 0.11988, 0.14107, 0.17753, 0.16871, 0.13954, 0.07774, 0.02895, 0.02261],
            'COM': [0.08337, 0.08333, 0.08333, 0.08333, 0.08333, 0.08333, 0.08333, 0.08333, 0.08333, 0.08333, 0.08333, 0.08333],
            'IRR': [0.00000, 0.00136, 0.06733, 0.26228, 0.32134, 0.25565, 0.06913, 0.02291, 0.00000, 0.00000, 0.00000, 0.00000],
            'MUN': [0.02194, 0.02090, 0.02667, 0.05446, 0.11988, 0.14107, 0.17753, 0.16871, 0.13954, 0.07774, 0.02895, 0.02261],
            'OTH': [0.08337, 0.08333, 0.08333, 0.08333, 0.08333, 0.08333, 0.08333, 0.08333, 0.08333, 0.08333, 0.08333, 0.08333],
            'STK': [0.08337, 0.08333, 0.08333, 0.08333, 0.08333, 0.08333, 0.08333, 0.08333, 0.08333, 0.08333, 0.08333, 0.08333]}

# Get GIS data for grid
lines = arcpy.SearchCursor(gridpts)
for l in lines:
    Lbot[0][l.row-1][l.col-1]=l.L1_Top #altitude of bottom of layer 0=top of layer 1
    Lbot[Llak][l.row-1][l.col-1]=l.L1_Top #altitude of bottm of lake layer, Lbot[0] if no lakes
    #ib[Llak][l.row-1][l.col-1]=l.ibsurf #ibound for top layer, ib[0]=0 when lakes present
    d2bd[l.row-1][l.col-1]=l.d2bd
    surfgeo[l.row-1][l.col-1]=l.geo_surf
    modext[l.row-1][l.col-1]=int(l.model_ext)
    ewprcp[l.row-1][l.col-1]=l.EWprcp
    cellid[l.row-1][l.col-1]=l.cell_id
    WHSF[l.row-1][l.col-1]=l.WofHSF
    metabase[l.row-1][l.col-1]=l.meta_basement
    cell_utm[l.cell_id]=(l.UTM_x,l.UTM_y)
    if l.model_ext>0:
        irunbnd[l.row-1][l.col-1]=int(l.irunbnd)
del l
del lines
##readgis.getgrid(gridpts)

#calculate iuzfbnd
def getiuzfbnd():
    for k in range(0,Llak+nsublay):
        kk=Llak+nsublay-k #bottom layer (k=0) to layer 1
        for i in range(0,nrow):
            for j in range(0,ncol):
                if ib[kk-1][i][j]==1: #zero based indexing
                    if surfgeo[i][j]>=4: #negative iuzf for bedrock, direct to GW, ignore uzf
                        iuzfbnd[i][j]=-kk
                    else:
                        iuzfbnd[i][j]=kk
    return(iuzfbnd)
iuzfbnd=getiuzfbnd()

# Get GIS data for subsurface recharge (underflow)
#3500.0/27900=0.125 #Carson Range average of (mean annual GW inflow)/(mean annual precip) from Jeton and Maurer 2007
lines = arcpy.SearchCursor(ssfpts)
for l in lines:
    if l.ssf_name not in ssf_dict:
        ssf_dict[l.ssf_name]={}
##        if l.ssf_name=='Old Clear Creek':
##            ssf_dict[l.ssf_name]['ssfratio']=0.05
##        elif l.ssf_name=='Sierra Canyon':
##            ssf_dict[l.ssf_name]['ssfratio']=0.05
##        else:
##            ssf_dict[l.ssf_name]['ssfratio']=0.05
        if 'Eagle' in l.ssf_name:
            ssf_dict[l.ssf_name]['ssfratio']=1.0 #Determined from Maurer and Berger
        else:
            ssf_dict[l.ssf_name]['ssfratio']=ssfratio
        ssf_dict[l.ssf_name]['area']=l.area_ft2
        ssf_dict[l.ssf_name]['alt']=l.mean_alt_ft
        ssf_dict[l.ssf_name]['pos']=[]
        ssf_dict[l.ssf_name]['flowsp']=[]
    ssf_dict[l.ssf_name]['pos'].append((l.Row,l.Col))
    #surfgeo[l.Row-1,l.Col-1]=2 #make all ssf cells = alluv
del l
del lines
##ssf_dict=readgis.getssflow(ssfpts)

# Get septic data from GIS
lines = arcpy.SearchCursor(seppts)
for l in lines:
    if l.DWELLINGS>0 and l.SEPTICS>0:
        if l.APN not in sep_dict:
            sep_dict[l.APN]={}
            sep_dict[l.APN]['conyr']=int(l.CON_YEAR)
            sep_dict[l.APN]['nsep']=l.SEPTICS #number of septic systems
            sep_dict[l.APN]['pos']=[]
            sep_dict[l.APN]['flowsp']=[]
            sep_dict[l.APN]['pos'].append((l.Row,l.Col))
del l
del lines
##sep_dict=readgis.getseptic(seppts)

# get lake cell data from GIS
lines = arcpy.SearchCursor(lakpts)
for l in lines:
    if l.LAKid not in lak_dict:
        lak_dict[l.LAKid]={}
        lak_dict[l.LAKid]['name']=l.LAKnam
        lak_dict[l.LAKid]['pos']=[(l.Row,l.Col)]
        lak_dict[l.LAKid]['stage']=[]
        lak_dict[l.LAKid]['prcpsp']=[]
        lak_dict[l.LAKid]['rnf']=[]
        lak_dict[l.LAKid]['area']=[]
        lak_dict[l.LAKid]['vol']=[]
    else:
        lak_dict[l.LAKid]['pos'].append((l.Row,l.Col))
    if l.LAKid>0:
        lakext[l.Row-1][l.Col-1]=1
        lakid[l.Row-1][l.Col-1]=l.LAKid
    else: lakext[l.Row-1][l.Col-1]=0
del l
del lines
##lak_dict,lakext,lakid=readgis.getlak(lakpts)

# get water rights data from GIS
lines = arcpy.SearchCursor(wrpts)
for l in lines:
    wrid=str(l.wt_rt_id)
    if wrid not in wr_dict: #cells with no wr are blank
        wr_dict[wrid]={}
        wr_dict[wrid]['pos']=[]
        wr_dict[wrid]['alt']=[]
        wr_dict[wrid]['wrsrc']=l.Model_src #name of supplying stream
        wr_dict[wrid]['effsrc']=l.Effluent_src #none if supplying effluent pond
        wr_dict[wrid]['priority']=l.priority #none type if riparian
        wr_dict[wrid]['div']=l.main_div
##    if l.Alp_acres>0: #alp_acres field was wrong in GIS layer
##        wr_dict[wrid]['acres']=l.Alp_acres
##    else:
    wr_dict[wrid]['acres']=l.Acres2 #use calculated acres, cross check with alp_acres in spreadsheet
    wr_dict[wrid]['alt'].append(l.L1_top)
    wr_dict[wrid]['pos'].append((l.Row,l.Col))
del l
del lines
##readgis.getwr(wrpts)
###ungaged diversions, data from Unger and Charlie Condrone field visit
##ungaged=['WILL','HOME','STL','MARTIN','MID','POLE','EAST','HEIM','MCC','FT','THRAN','WHYATT','COMP','JEAST','STODIC','PBULL','MAC','ISL']
##ungflow=[25,25,20,18,15,15,10,20,15,30,15,12,20,15] #from Unger, STODIC to ISL from Charlie

# Get GIS data for high ET zones
# assuming each field has some month and year code sep by '_'
##fields = arcpy.ListFields(ETpts)
##lines=arcpy.SearchCursor(ETpts)
##for field in fields:
##    if 'ET' in field.name:
##        mo=int(field.name.split('_')[1])
##        yr=int(field.name.split('_')[2])
##        d8=datetime.date(yr,mo,01)
##        aet_dict[d8]=np.zeros((nrow,ncol))
##        for l in lines:
##            aet_dict[d8][l.Row-1][l.Col-1]=l.getValue(field.name)
##del l
##del lines
##for d8 in aet_dict:
##    aet_dict[d8]=np.nan_to_num(aet_dict[d8])

# Use Yager's ET_all points until Metric data is available
# should include PJ forests up high to balance streamflows?
# deeper roots, winter ET, need to delineate
hiET=np.zeros((nrow,ncol))
lines=arcpy.SearchCursor(ETpts)
for l in lines:
    if 'phreatophyte' in l.ET_type:
        hiET[l.Row][l.Col]=1 #4.4/365.25
    elif 'riparian' in l.ET_type:
        hiET[l.Row][l.Col]=1 #3.5/365.25
    elif 'wetland' in l.ET_type:
        hiET[l.Row][l.Col]=1 #1.9/365.25
    elif 'irrigated' not in l.ET_type:
        print('ET type '+l.ET_type+' not found for '+str(l.OBJECTID_1))

# get pmp data from GIS, generic depth by type if none exists
def getpmp(dic,moex=True): #moex=true only get pmp within domain
    dic={}
    lines = arcpy.SearchCursor(pmppts)
    for l in lines:
        proc=0
        r=l.Row
        c=l.Col
        i=r-1
        j=c-1
        if moex==True:
            if modext[l.Row-1][l.Col-1]==1:
                proc=1
        else:
            proc=1
        if proc==1:
            ID=str(l.wellID).strip()
            if ID not in dic:
                dic[ID]={}
                dic[ID]['type']=str(l.w_Type)
                dic[ID]['pos']=(r,c)
                dic[ID]['pou']=[] #to be a list of (row,col)
                dic[ID]['pmpyr']={}
                dic[ID]['pmpsp']=[]
                #dic[ID]['subarea']=[l.SUM_NAME]
                if l.w_LowerZ>0: #prefer lowerZ to allow pumping max depth
                    dic[ID]['scralt']=l.w_LowerZ
                    dic[ID]['depth']=Lbot[0][i][j]-l.w_LowerZ
                elif  l.w_HigherZ>0:
                    dic[ID]['scralt']=l.w_HigherZ
                    dic[ID]['depth']=Lbot[0][i][j]-l.w_HigherZ
                else:
                    dic[ID]['scralt']=0 #to be corrected after DWR data read
                    dic[ID]['depth']=0
    del l
    del lines
    # make consistent pmp types
    for ID in dic:
        try:
            s=['-','_','&',''] #various symbols used in same MOU abbreviations
            if 'DOM' in dic[ID]['type']:
                dic[ID]['type']='DOM'
            elif dic[ID]['type']=='IRR' or dic[ID]['type'] in ['I'+i+'D' for i in s]: # or dic[ID]['type']=='REC'
                dic[ID]['type']='IRR'
            elif dic[ID]['type'] in ['Q'+i+'M' for i in s] or dic[ID]['type']=='MUN':
                dic[ID]['type']='MUN'
            elif 'COM' in dic[ID]['type']:
                dic[ID]['type']='COM'
            elif dic[ID]['type'] in ['S'+i+'D' for i in s] or dic[ID]['type'] in ['I'+i+'S' for i in s] or dic[ID]['type']=='STK':
                dic[ID]['type']='STK'
            else:
                dic[ID]['type']='OTH'
        except:
            print('cannot convert type for: '+ID+' in '+pumpfile+'\n')
    return(dic)
pmp_dict=getpmp(pmppts,moex=False)

# get POU data associated with each well from GIS
lines = arcpy.SearchCursor(pmppoupts)
for l in lines:
    ID = l.wellID
    if ID in pmp_dict:
        pmp_dict[ID]['pou'].append((l.Row,l.Col))
        d8=datetime.date(l.prior_dt)
        if d8.year!=pmp_dict[ID]['conyr']: #issue warning for inconsistent dates
            print('different conyr and priyr for '+ID)
##readgis.getpou(pmppoupts)

# get hobs data from GIS, generic depth by type if none exists
def gethob(hobpts,surf,sp=[],tmpast=0,tmfuture=0,nlim=1,stdlim=5,plotobs=True): #tmargin allows for +/- years window in time, more obs if std fulfilled
    import string,datetime
    dic={}
    lines = arcpy.SearchCursor(hobpts)
    past=datetime.timedelta(days=tmpast*365)
    future=datetime.timedelta(days=tmfuture*365)
    for l in lines:
        r=l.Row
        c=l.Col
        if l.LEV_ACY_CD<=1 or l.LEV_STATUS_CD in list(string.ascii_uppercase) or modext[r-1][c-1]==0: #don't process bad levels outside modext
            proc=0
        else:
            for per in period: #observation exists in a period
                if per[0]-past<=l.LEV_DT.date()<=per[-1]+future:
                    proc=1
                else:
                    proc=0
            if proc==1:
                ID=str(l.short_name).strip() #short name=simple sequence, agency code - site, e.g.:USGS-384554119504201, gets cut off
                if ID not in dic: #type and location shouldn't change
                    dic[ID]={}
                    dic[ID]['date']=[]
                    dic[ID]['time']=[]
                    dic[ID]['hobbgs']=[]
                    dic[ID]['hobalt']=[]
                    dic[ID]['acy']=[]
                    dic[ID]['type']='OBS'
                    dic[ID]['USGSsite']=l.SITE_NO
                dic[ID]['pos']=(r,c)
                dic[ID]['utm']=(l.UTM_x,l.UTM_y)
                #dic[ID]['type']=str(l.WATER_USE_1_CD)
                dic[ID]['roff']=0 #364224*(l.cell_lat-l.DEC_LAT_VA)/cwidth #convert from decimal degrees to ft: negative to N, positive to south
                dic[ID]['coff']=0 #284207*(l.DEC_LONG_VA-l.cell_long)/rwidth #convert from decimal degrees to ft: negative to west, positive to east
                dic[ID]['date'].append(l.LEV_DT.date())
                #dic[ID]['time'].append(l.LEV_DT.time())
                try:
                    dic[ID]['depth']=float(l.WELL_DEPTH_VA) #considered top of screen, subtract from cell elevation. ~5% of NWIS wells in area have no depth determined
                    dic[ID]['scralt']=surf[r-1][c-1]-dic[ID]['depth']
                except:
                    dic[ID]['depth']=0 #set to maximum measured water depth (hobbgs) further down
                    dic[ID]['scralt']=0
                try:
                    lev=float(l.LEV_VA)
                    dic[ID]['hobbgs'].append(lev)
                    dic[ID]['hobalt'].append(surf[r-1,c-1]-lev)
                except: #assumes l.LEV_VA cannot be converted due to space between '-' and '#'
                    lev=float(l.LEV_VA.split()[0]+l.LEV_VA.split()[1])
                    dic[ID]['hobbgs'].append(lev)
                    dic[ID]['hobalt'].append(surf[r-1,c-1]-lev)
                if l.LEV_ACY_CD=='0': #0=worse than foot, 1=1/10 foot, 2=1/100 foot, 9=not to nearest foot
                    dic[ID]['acy'].append(99)
                elif l.LEV_ACY_CD=='1':
                    dic[ID]['acy'].append(1./10)
                elif l.LEV_ACY_CD=='2':
                    dic[ID]['acy'].append(1./100)
                else: #junk data
                    dic[ID]['acy'].append(10)
    del l
    del lines

    #delete bad obs
    dellist=[]
    ogobs=len(dic) #original number of observation locations
    for ID in dic:
        dic[ID]['hobstd']=np.std(dic[ID]['hobalt'])
        if len(dic[ID]['hobalt'])<nlim: #delete if too few values
            print('%s only had %i values: deleted' %(ID,len(dic[ID]['hobalt'])))
            dellist.append(ID)
        elif dic[ID]['hobstd']>stdlim: #delete if std too high
            print('%s std was %4.1f feet: deleted' %(ID,np.std(dic[ID]['hobalt'])))
            dellist.append(ID)
    for ID in dellist:
        del dic[ID]
    title=('%i of %i observations between %s and %s\n meet criteria: stdev<%2.1f, nvals>%i'
            %(len(dic),ogobs,str(period[0][0]-past),str(period[-1][1]+future),stdlim,nlim))
    print(title)
    if plotobs==True:
        x=[]
        y=[]
        for i in dic:
            plt.plot(dic[i]['pos'][1],dic[i]['pos'][0],'xr')
        plt.axis('equal')
        plt.title(title)
        plt.savefig(r'S:\CarsonValley\figures\hob-'+str(tmfuture)+'.png')
        plt.close()
    return(dic)
hob_dict=gethob(hobpts,Lbot[0],sp=sp)

#get transmissivity data
def gettrans(transpts):
    dic={}
    lines = arcpy.SearchCursor(transpts)
    for l in lines:
        r=l.Row
        c=l.Col
        if modext[r][c]==1:
            ID=int(l.well_log)
            if ID not in dic:
                dic[ID]={}
            dic[ID]['utm']=(l.X_UTM83,l.Y_UTM83)
            dic[ID]['pos']=(l.Row,l.Col)
            dic[ID]['scrint']=(Lbot[0][r-1][c-1]-l.screen_top,Lbot[0][r-1][c-1]-l.screen_bot)
            dic[ID]['depth']=l.screen_bot
            dic[ID]['trans']=l.Trans
            dic[ID]['type']='TRANS'
    del l
    del lines
    return(dic)
trans_dict=gettrans(transpts)


# Get SFR data from GIS
lines = arcpy.SearchCursor(sfrpts)
nstrm=0
for l in lines:
    if l.iseg not in seg_dict:
        seg_dict[l.iseg]={}
        seg_dict[l.iseg]['outseg']=l.OutSeg
        seg_dict[l.iseg]['streamtype']=l.StreamType
        seg_dict[l.iseg]['width']=l.s_WIDTH1
        seg_dict[l.iseg]['name']=l.nameLong
        seg_dict[l.iseg]['ireach']={}
        seg_dict[l.iseg]['iupseg']=l.iUpSeg
    if l.iReach not in seg_dict[l.iseg]['ireach']:
        seg_dict[l.iseg]['ireach'][l.iReach]={}
        seg_dict[l.iseg]['ireach'][l.iReach]['strhcgroup']=l.Cond_Grp
        seg_dict[l.iseg]['ireach'][l.iReach]['krch']=l.kRch
        seg_dict[l.iseg]['ireach'][l.iReach]['pos']=(l.iRch,l.jRch)
        seg_dict[l.iseg]['ireach'][l.iReach]['rchlen']=l.rchlen
        seg_dict[l.iseg]['ireach'][l.iReach]['strtop']=l.sfr_10m_ft
##        if l.sfr_lidar_ft>0:
##            seg_dict[l.iseg]['ireach'][l.iReach]['strtop']=l.sfr_lidar_ft
##        else:
##            seg_dict[l.iseg]['ireach'][l.iReach]['strtop']=l.StrTop_ft
##        if l.slope>minsfrslope:
        seg_dict[l.iseg]['ireach'][l.iReach]['slope']=l.slope
##        else:
##            seg_dict[l.iseg]['ireach'][l.iReach]['slope']=minsfrslope
        seg_dict[l.iseg]['ireach'][l.iReach]['strthick']=l.strThick
        if l.StationID is not None:
            seg_dict[l.iseg]['ireach'][l.iReach]['gage']=l.StationID.strip() #gages can be any reach
        seg_dict[l.iseg]['ireach'][l.iReach]['stationname']=l.StationName
        seg_dict[l.iseg]['ireach'][l.iReach]['stationtype']=l.station_type
    try:
        if 'inflow' in l.station_type:
            seg_dict[l.iseg]['intab']=l.StationID.strip()
    except: pass #no infow for segment
    try: #diversions apply to entire segment, not individual reaches
        if 'diversion' in l.station_type:
            seg_dict[l.iseg]['divtab']=l.StationID.lower().strip()
    except: pass #no diversion for segment
    nstrm=nstrm+1 #total number of stream reaches
del l
del lines

#approximate for <=minsfrslope slopes
for seg in seg_dict:
    for rch in seg_dict[seg]['ireach']:
        if seg_dict[seg]['ireach'][rch]['slope']<=minsfrslope:
            if rch<np.max(seg_dict[seg]['ireach'].keys()):
                de=seg_dict[seg]['ireach'][rch]['strtop']-seg_dict[seg]['ireach'][rch+1]['strtop']
                dl=seg_dict[seg]['ireach'][rch]['rchlen']
                seg_dict[seg]['ireach'][rch]['slope']=de/dl
            else:
                seg_dict[seg]['ireach'][rch]['slope']=seg_dict[seg]['ireach'][rch-1]['slope']

#prevent rejected infiltration from going back to same sfr segment
for seg in seg_dict:
    for rch in seg_dict[seg]['ireach']:
        i=seg_dict[seg]['ireach'][rch]['pos'][0]-1
        j=seg_dict[seg]['ireach'][rch]['pos'][1]-1
        if irunbnd[i][j]==seg: #send to next segment
            irunbnd[i][j]=seg_dict[seg]['outseg']

# get mean,min,max lake stages from excel, write tabfiles
lakestagewb=xlrd.open_workbook(lakestagefile) #no need to close with xlrd.open_workbook
for s in lakestagewb.sheets():
    for r in range(0,2):
        if 'lakid=' in s.row_values(r) and int(s.cell_value(r,1)) in lak_dict:
            lak=int(s.cell_value(r,1)) #lakid number in second column after 'lakid='
    for r in range(2,s.nrows):
        if 'STAGE' in s.row_values(r) and 'VOLUME' in s.row_values(r) and 'AREA' in s.row_values(r):
            for r2 in range(1,152): #always 151 values in stage-vol-area
                lak_dict[lak]['stage'].append(float(s.cell_value(r+r2,0)))
                lak_dict[lak]['vol'].append(float(s.cell_value(r+r2,1)))
                lak_dict[lak]['area'].append(float(s.cell_value(r+r2,2)))
            lak_dict[lak]['meanalt']=np.mean(lak_dict[lak]['stage'])
            lak_dict[lak]['minalt']=np.min(lak_dict[lak]['stage'])
            lak_dict[lak]['maxalt']=np.max(lak_dict[lak]['stage'])
            with open (dd['laktabsdir']+'\\'+modnam+'-'+lak_dict[lak]['name']+'-stage-volume-area.txt','w+') as laktabfile: #writes tabfile from excel file, using GIS name, linked by lakid
                for i in range(0,len(lak_dict[lak]['stage'])):
                    line=(float(lak_dict[lak]['stage'][i]),float(lak_dict[lak]['vol'][i]),float(lak_dict[lak]['area'][i]),'\n')
                    laktabfile.write('%10.4f    %.10E    %.10E    %s' %line)
#adjust altitude to accomodate lakes
if Llak>0:
    for i in range(0,nrow):
        for j in range(0,ncol):
            if lakid[i][j]>0:
                Lbot[0][i][j]=lak_dict[lakid[i][j]]['maxalt']
                Lbot[Llak][i][j]=lak_dict[lakid[i][j]]['minalt']
            else:
                Lbot[Llak][i][j]=Lbot[Llak][i][j]

#set lake controlled outlet segment equal to minalt+altadj of controlled segments and maxalt-altadj for spillway
#high slope to accomodate spill flows
for seg in seg_dict:
    if 'iupseg' in seg_dict[seg] and seg_dict[seg]['iupseg']<0:
        iuplak=abs(seg_dict[seg]['iupseg'])
        # find "center" of lake
        rows=[p[0] for p in lak_dict[iuplak]['pos']]
        cols=[p[1] for p in lak_dict[iuplak]['pos']]
        r=int(np.mean(rows))
        c=int(np.mean(cols))
        if seg_dict[seg]['outseg']>0: #spillway, set to maxalt
            bump=0.5 #bump the stream reach this much below maxalt for spillway
            seg_dict[seg]['ireach'][1]['pos']=(r,c)
            seg_dict[seg]['ireach'][1]['krch']=1 #put in lake layer
            seg_dict[seg]['ireach'][1]['slope']=0.05 #steep slope for spillway
            altadj=seg_dict[seg]['ireach'][1]['slope']*seg_dict[seg]['ireach'][1]['rchlen']/2 #dist from strtop (midrch) to either end
            seg_dict[seg]['ireach'][1]['strtop']=lak_dict[iuplak]['maxalt']-altadj-bump
            print('reset altitude of '+str(seg)+' to max '+str(lak_dict[iuplak]['maxalt']+altadj)+' for lake '+str(iuplak))
        elif seg_dict[seg]['outseg']==0: #controlled, set to bump above minalt, next seg calls diversion
            bump=0.5 #bump the stream reach this much above minalt for diversions (meanalt for SS)
            seg_dict[seg]['ireach'][1]['pos']=(r,c)
            seg_dict[seg]['ireach'][1]['krch']=1 #put in lake layer
            seg_dict[seg]['ireach'][1]['slope']=0.001 #small slope for diversion
            altadj=seg_dict[seg]['ireach'][1]['slope']*seg_dict[seg]['ireach'][1]['rchlen']/2 #dist from strtop (midrch) to either end
            seg_dict[seg]['ireach'][1]['strtop']=lak_dict[iuplak]['minalt']+bump #ensures some water remains in lake
            print('reset altitude of '+str(seg)+' to min '+str(lak_dict[iuplak]['minalt']+bump)+' for lake '+str(iuplak))

#           BUILD GRID
# use smoothed surface to avoid unwarranted complexity at bottom of L3 and L4
# DO NOT use smoothed, puts wells in layer 5 bedrock
print('Building grid from GIS\n')
sys.stdout.flush()
Ltopsmooth=Lbot[0]#ndimage.gaussian_filter(Lbot[0],sigma=(3),order=0,mode="nearest")
Ltopsmooth=np.nan_to_num(Ltopsmooth)
for i in range(0,nrow):
    for j in range(0,ncol):
        if d2bd[i][j]<=0:
            d2bd[i][j]=0
#Lbot[2], altitude of layer 2 bottom surface
#set bottom of L1 near surface water to predefined depth below surface for SW-GW interactions, except surfgeo>4
for i in range(0,nrow):
    for j in range(0,ncol):
        if modext[i][j]==1:
            if surfgeo[i][j]<3 or lakid[i][j]>0: #only alluv and fluv, cells under lakes
                Lbot[2][i][j]=Lbot[1][i][j]-activethick
            else: #no active surface, no layer 2
                Lbot[2][i][j]=Lbot[1][i][j]
#Lbot[4], altitude of layer 4 bottom
for i in range(0,nrow):
    for j in range(0,ncol):
        if modext[i][j]==1:
            if surfgeo[i][j]>4: #meta or granitic bedrock, only bottom layer
                Lbot[4][i][j]=Lbot[1][i][j]
            elif d2bd[i][j]>=d2Tert and surfgeo[i][j]<=2: # deep units in deep basin under alluv and/or fluv
                Lbot[4][i][j]=Ltopsmooth[i][j]-d2Tert #top of L3 approximates top of Tert in basin
            elif d2bd[i][j]<=2*minthick and surfgeo[i][j]<=4: # thin layers of Tv or younger, make room in L3 and L4
                Lbot[4][i][j]=Lbot[2][i][j]-2*minthick
            else: #Lbot4 is top of bedrock
                Lbot[4][i][j]=Lbot[2][i][j]-d2bd[i][j]
#Lbot[3]
for i in range(0,nrow):
    for j in range(0,ncol):
        if modext[i][j]==1:
            if lakid[i][j]>0: #cells under lakes
                if Lbot[2][i][j]-Lbot[4][i][j]>=2*minthick: #room for L2 and L3 minthick
                    Lbot[3][i][j]=Lbot[4][i][j]+(Lbot[Llak+1][i][j]-Lbot[Llak+3][i][j])/2 #enforce L3 minthick or (split dif between L1 and L2: (Lbot[Llak+1][i][j]-Lbot[Llak+3][i][j])/2)
                else:
                    Lbot[3][i][j]=Lbot[2][i][j]-minthick #must have L2 and L3 minthick under lakes regardless
                    Lbot[4][i][j]=Lbot[3][i][j]-minthick
            elif surfgeo[i][j]<=4:
                if Lbot[2][i][j]-Lbot[4][i][j]>=2*alluvmax: #limit thickness of alluv, let Ts fill the rest
                    Lbot[3][i][j]=Lbot[2][i][j]-alluvmax
                elif Lbot[2][i][j]-Lbot[4][i][j]>=2*minthick: #room for L3 and L4 minthick
                    Lbot[3][i][j]=Lbot[4][i][j]+(Lbot[2][i][j]-Lbot[4][i][j])/2 #(split dif between L1 and L2: Lbot[Llak+3][i][j]+(Lbot[Llak+1][i][j]-Lbot[Llak+3][i][j])/2)
                else: #no room of L3 or L4
                    Lbot[3][i][j]=Lbot[1][i][j] #no room for minthick in L2
                    Lbot[4][i][j]=Lbot[1][i][j] #no room for minthick in L3
            else: #bedrock on surface, one layer thick
                Lbot[3][i][j]=Lbot[1][i][j]
                Lbot[4][i][j]=Lbot[1][i][j]
#Lbot[5], must come after Lbot[3] calc
for i in range(0,nrow):
    for j in range(0,ncol):
        Lbot[5][i][j]=min(Ltopsmooth[i][j]-d2bd[i][j],Lbot[4][i][j]-minbd)

# determine zones
# zone 1 = fluvial, 2 = alluvial, etc, zone 0 = undefined
def makezones():
    dic=np.zeros((nsublay+Llak,nrow,ncol))
    for i in range(0,nrow):
        for j in range(0,ncol):
            #Subsurf1 properties, index 1, layer 2
            dic[1][i][j]=surfgeo[i][j]
            #Subsurf2 properties
            dic[2][i][j]=surfgeo[i][j]
            #Subsurf3 properties
            if surfgeo[i][j]<=2: #fluv and alluv
                if WHSF[i][j]==1:
                    if d2bd[i][j]>d2Tert: #all fluvial above Ts in deep basin
                        dic[Llak+2][i][j]=1
                    else:
                        dic[Llak+2][i][j]=2
                else:
                    dic[Llak+2][i][j]=3
            else:
                dic[Llak+2][i][j]=surfgeo[i][j]
            #Subsurf4 properties
            if d2bd[i][j]>d2Tert and surfgeo[i][j]<=2: #deep tert in basin
                dic[4][i][j]=3
            else: #bedrock material only
                if surfgeo[i][j]<6 and metabase[i][j]!=1: #younger than metamorphic, make igneous intrusive
                    dic[4][i][j]=5
                elif surfgeo[i][j]==6 or metabase[i][j]==1:
                    dic[4][i][j]=6
            #values for undefined cells make ceil of average adjacent
##            if modext[i][j]==1:
##                if surfgeo[i][j]<1:
##                    for k in range(1,np.shape(dic)[0]):
##                        g=[]
##                        for ii in range(-2,3):
##                            if 0<i+ii<nrow:
##                                for jj in range(-2,3):
##                                    if 0<j+jj<ncol:
##                                        if surfgeo[i+ii][j+jj]>0:
##                                            g.append(surfgeo[i+ii][j+jj])
##                        newg=np.min(g)
##                        dic[k][i][j]=newg
            if modext[i][j]==0:#else:
                for k in range(0,len(dic)):
                    dic[k][i][j]=0
            #exclude cells with 0 thickness
            for k in range(0,np.shape(dic)[0]):
                if int(Lbot[k][i][j]-Lbot[k+1][i][j])>0:
                    tmult=1
                else:
                    tmult=0
                dic[k][i][j]=dic[k][i][j]*modext[i][j]*tmult
    return(dic)
zone=makezones()

#set hydraulic properties based on zone
def geofromzone():
    for i in range(0,nrow):
        for j in range(0,ncol):
            Ssarr[i][j]=Sstorage[int(zone[Llak][i][j])-1]
            Syarr[i][j]=Sy[int(zone[Llak][i][j])-1]
            THTSarr[i][j]=THTS[int(zone[Llak][i][j])-1]
##            for k in range(1,np.shape(zone)[0]): #layers
##                geldex=int(zone[k][i][j])-1
##                if geldex>=0:
##                    LHK[k][i][j]=gelK[geldex] #zone gives geology in each layer
##                if zone[k][i][j]>=5 and k==4: #bedrock in bottom layer
##                    LHK[k][i][j]=gelK[int(zone[k][i][j])-1]*500/minbd #adjust transmissivity in base layer to test impact of deeper flow paths
##                if KNrow[0]<i<KNrow[1] and KNcol[0]<j<KNcol[1] and zone[k][i][j] in KNtype: #north impermeable zone
##                    LHK[k][i][j]=KN*LHK[k][i][j]
geofromzone()
THTRarr=(THTSarr-Syarr)*THTRfact
THTXarr=THTRarr*THTXfact
THTIarr=(THTSarr-Syarr)*THTIfact

#      MAKE GRID ADJUSTMENTS BASED ON PMP AND HOB WELLS
#push bottom of layer (and lower) down by diff, for cells within rad cells of pos, with diff decreasing linearlly out from center
# make no changes in adjacent cells if geology is bedrock (>exgeo)
def makepit(pos,lay,newalt,zone,rad=0,exgeo=6):
    i=pos[0]-1
    j=pos[1]-1
    if 0<zone[lay-1][i][j]<exgeo:
        if Lbot[lay][i][j]>=newalt-1:
            for di in range(-rad,rad+1):
                for dj in range(-rad,rad+1):
                    dist=(di**2+dj**2)**0.5
                    if dist<=rad:
                        diff=Lbot[lay][i][j]-(newalt-1) #arbitrary -1 to keep in lay
                        for L in range(lay,Llak+nsublay+1): #shift alt of every underlying layer
                            if rad==0:
                                fact=1
                            else:
                                fact=1-dist/rad
                            if diff*fact>=minthick and 0<zone[lay-1][i+di][j+dj]<exgeo:# or (di==0 and dj==0)):
                                Lbot[L][i+di][j+dj]=Lbot[L][i+di][j+dj]-diff*fact
                                #print('altitude of cell '+str(((i+di),(j+dj)))+' changed by '+str(diff*fact))

#make a halo of zone material with radius rad around pos
def makehalo(pos,botlay=Llak+nsublay,toplay=Llak,hzone=999,rad=0):
    i=pos[0]-1
    j=pos[1]-1
    if i<np.shape(zone)[1] and j<np.shape(zone)[2]:
        if hzone==999: #determine minimum zone from overlying layers
            hzone=np.min([zone[z][i][j] for z in range(0,len(zone)) if zone[z][i][j]!=0])
        for di in range(-rad,rad+1):
            for dj in range(-rad,rad+1):
                if 0<=i+di<np.shape(zone)[1] and 0<=j+dj<np.shape(zone)[2]:
                    dist=(di**2+dj**2)**0.5
                    if dist<=rad:
                        for L in range(toplay,botlay): #botlay=4 should only make halo into layer 3, etc
                            zone[L][i+di][j+dj]=hzone
#determine layer of well
def laywel(dic,track=False):
    print('Determining layer of wells\n')
    poplist=[]
    for ID in dic:
        r=dic[ID]['pos'][0]
        c=dic[ID]['pos'][1]
        i=r-1
        j=c-1
        if modext[i][j]==1: #ignore cells outside of model extent
            if 'scralt' in dic[ID]:
                if Lbot[nsublay+1][i][j]>dic[ID]['scralt']: #ensure model goes as deep as wells
                    Lbot[nsublay+1][i][j]=dic[ID]['scralt']-10
                for k in range(Llak+1,Llak+nsublay+1):
                    if Lbot[k][i][j]<=dic[ID]['scralt']<Lbot[k-1][i][j]: #layer determined by unit at to of screened interval
                        dic[ID]['lay']=k
                dic[ID]['zone']=int(zone[dic[ID]['lay']-1][r-1][c-1]) #set cell zone to material in new layer
            elif 'scrint' in dic[ID]:
                if Lbot[nsublay+1][i][j]>dic[ID]['scrint'][1]: #ensure model goes as deep as wells
                    Lbot[nsublay+1][i][j]=dic[ID]['scrint'][1]-10
                for k in range(Llak+1,Llak+nsublay+1):
                    if dic[ID]['scrint'][0]<Lbot[k-1][i][j]: #layer determined by unit at to of screened interval
                        dic[ID]['lay']=k
                dic[ID]['zone']=int(zone[dic[ID]['lay']-1][r-1][c-1]) #set cell zone to material in new layer
            if track==True:
                if 'scralt' in dic[ID]:
                    pass
                elif 'scrint' in dic[ID]:
                    pass
                else:
                    print('no screen altitude for '+str(ID))
                if 'lay' not in dic[ID]:
                    print('no screen layer for '+ID)
        else: #pop if not in model extent
            poplist.append(ID)
    for ID in poplist:
        dic.pop(ID)
    return(dic)
geofromzone()
#write well depths for wells in lay, import into GIS, redefine z2bd
#can't figure out how to limit GIS interpolation to deepest, only write deepest for cell
def laywelwrite(diclist,cid,lay,fname):
    subdic={}
    dlist=[]
    for d in diclist:
        for id in d:
            r=d[id]['pos'][0]
            c=d[id]['pos'][1]
            i=r-1
            j=c-1
            if (r,c) not in subdic: #new cell
                subdic[(r,c)]={}
                subdic[(r,c)]['comdep']=[]
                subdic[(r,c)]['IDlist']=[]
                for dic in diclist: #tally common depths
                    Ldep=[dic[ID]['depth'] for ID in dic if (r,c) == dic[ID]['pos'] and 'lay' in dic[ID] and dic[ID]['lay']==lay and dic[ID]['depth']>0] #lay wells in cell r,c
                    wID=[ID for ID in dic if (r,c) == dic[ID]['pos'] and 'lay' in dic[ID] and dic[ID]['lay']==lay and dic[ID]['depth']>0] #lay wells in cell r,c
                    if len(Ldep)>0:
                        subdic[(r,c)]['comdep']=Ldep+subdic[(r,c)]['comdep']
                        subdic[(r,c)]['IDlist']=wID+subdic[(r,c)]['IDlist']
                if len(subdic[(r,c)]['comdep'])>0:
                    xcomdep=np.max(subdic[(r,c)]['comdep'])
                    dlist.append((cellid[i][j],xcomdep,subdic[(r,c)]['IDlist']))
    with open (fname,'w+') as f:
        for p in range(0,len(dlist)):
            dset=set(dlist[p][2])
            Ldata=(int(dlist[p][0]),float(dlist[p][1]))
            f.write('%s,%8.3f,' %Ldata)
            f.write(",".join(str(i) for i in dset)+'\n')
##pmp_dict=laywel(pmp_dict)
##hob_dict=laywel(hob_dict)
##L5wells=os.path.join(root,'CarsonValley','GIS','L5wells.csv')
##laywelwrite([pmp_dict,hob_dict],cellid,5,L5wells)

# assign missing well depths based on assumptions
# Determine layer of screen based on ave depth of pmp type and layer thicknesses
def weldepth(dic):# assign missing well depth
    print('Assigning depth of wells with no depth information\n')
    pmpdepth=[150,300] #estimated depth of pmp based on type: 0=['COM','DOM','ENV','IND','REC','STK'], 1=['IRR','I_D','MUN','OTH','Q_M']
    for ID in dic:
        r=dic[ID]['pos'][0]
        c=dic[ID]['pos'][1]
        if dic[ID]['depth']<=0: #reset depths
            if dic[ID]['type'] in ['COM','DOM','STK']:
                dic[ID]['depth']=pmpdepth[0]
                dic[ID]['scralt']=Lbot[1][r-1][c-1]-dic[ID]['depth']
            elif dic[ID]['type'] in ['IRR','MUN','OTH']:
                dic[ID]['depth']=pmpdepth[1]
                dic[ID]['scralt']=Lbot[1][r-1][c-1]-dic[ID]['depth']
            elif 'hobbgs' in dic[ID] and np.max(dic[ID]['hobbgs'])>0:
                dic[ID]['depth']=np.max(dic[ID]['hobbgs'])+10 #set missing well depth to maximum measured water depth +10'
                dic[ID]['scralt']=Lbot[1][r-1][c-1]-dic[ID]['depth']
            else: #assign to 1' above bottom of first layer
                for k in range(1,len(Lbot)):
                    if (Lbot[k-1][r-1][c-1]-Lbot[k][r-1][c-1])>0:
                        estdepth=np.min([Lbot[k-1][r-1][c-1]-Lbot[k][r-1][c-1]-1,pmpdepth[1]])
                        dic[ID]['depth']=estdepth
                        dic[ID]['scralt']=Lbot[1][r-1][c-1]-dic[ID]['depth']
        if dic[ID]['depth']==0 and dic[ID]['type']!='OBS':
            print('no depth determined for:'+ID+'\n')
            sys.stdout.flush()
        if dic[ID]['type'] not in MOUmonthly and dic[ID]['type']!='OBS' and dic[ID]['type']!='TRANS':
            print('error with type for: '+str(ID)+'\n')
    return(dic)

pmp_dict=weldepth(pmp_dict)
hob_dict=weldepth(hob_dict)
trans_dict=weldepth(trans_dict)
pmp_dict=laywel(pmp_dict,track=False)
hob_dict=laywel(hob_dict,track=False)
trans_dict=laywel(trans_dict,track=False)
##L5wells_wdom=os.path.join(root,'CarsonValley','GIS','L5wells_wdom.csv')
##laywelwrite([pmp_dict,hob_dict],cellid,5,L5wells_wdom)

def subplotlay(arr,rows=2):
    cols=np.shape(arr)[0]/rows
    f,axarr=plt.subplots(rows,cols)
    for r in range(0,rows):
        for c in range(0,cols):
            axarr[r,c].imshow(arr[r+c])
            axarr[r,c].set_title('layer '+str(r+c))
            #axarr[r,c].colorbar()
    plt.show()

#make pits and halos for all wells intersecting layer 5
for ID in pmp_dict:
    i=pmp_dict[ID]['pos'][0]-1
    j=pmp_dict[ID]['pos'][1]-1
    if 'lay' in pmp_dict[ID] and pmp_dict[ID]['lay']==5:
        makepit(pmp_dict[ID]['pos'],4,pmp_dict[ID]['scralt'],zone,rad=3,exgeo=5)
        #makehalo(pmp_dict[ID]['pos'],botlay=4,rad=5)
for ID in hob_dict:
    i=hob_dict[ID]['pos'][0]-1
    j=hob_dict[ID]['pos'][1]-1
    if 'lay' in hob_dict[ID] and hob_dict[ID]['lay']==5:
        makepit(hob_dict[ID]['pos'],4,hob_dict[ID]['scralt'],zone,rad=3,exgeo=5)
        #makehalo(hob_dict[ID]['pos'],botlay=4,rad=5)
for ID in trans_dict:
    i=trans_dict[ID]['pos'][0]-1
    j=trans_dict[ID]['pos'][1]-1
    if 'lay' in trans_dict[ID] and trans_dict[ID]['lay']==5:
        makepit(trans_dict[ID]['pos'],4,trans_dict[ID]['scrint'][1],zone,rad=3,exgeo=5)
        #makehalo(trans_dict[ID]['pos'],botlay=4,rad=5)

pmp_dict=laywel(pmp_dict,track=True)
hob_dict=laywel(hob_dict,track=True)
geofromzone()

#           ASSIGN IBOUND BASED ON NEW LAYER THICKNESS
#assign ibound for each layer
for i in range(0,nrow):
    for j in range(0,ncol):
        for k in range(Llak,Llak+nsublay): #ib[1] is ib for first non-lake layer (defined in GIS), etc
            if Lbot[k][i][j]-Lbot[k+1][i][j]==0 or modext[i][j]==0: #ib=0 if laythick<=0
                ib[k][i][j]=0
            elif Lbot[k][i][j]-Lbot[k+1][i][j]<0:
                print('negative layer thickness for (lay,row,col): '+str(k)+' '+str(i+1)+' '+str(j+1))
            else:
                ib[k][i][j]=1


iuzfbnd=getiuzfbnd()
#deal with isolated active cells before MF does
for k in range(Llak,Llak+nsublay): #ib=0 if cell is surrounded by inactive cells
    for i in range(1,nrow-1): #1 and -1 for domain edges
        for j in range(1,ncol-1):
            if ib[k,i,j]==1 and ib[k,i+1,j]==0 and ib[k,i,j+1]==0 and ib[k,i-1,j]==0 and ib[k,i,j-1]==0: #surrounded by inactive
                tolay=abs(np.max([iuzfbnd[i+1,j],iuzfbnd[i,j+1],iuzfbnd[i-1,j],iuzfbnd[i,j-1]]))
                for kk in range(1,tolay): #deal with overlying cells
                    Lbot[kk,i,j]=Lbot[1,i,j] #bring to bottom of 1
                    zone[kk-1,i,j]=0
                    #LHK[kk-1,i,j]=0
                    ib[kk-1,i,j]=0

#           PROCESS SFR DATA
print('Generating SFR file\n')
sys.stdout.flush()
#catch missing isegs
oseg=max(seg_dict) #original number of segments in dict
newmseg=oseg #last seg entry in dict
for i in range(1,oseg):
    if i not in seg_dict and i<=newmseg:
        print ('missing segment: '+str(i))
        sys.stdout.flush()
isegsort=[s for s in seg_dict]
isegsort.sort()
wrstart=max(isegsort)+1
for i,wrid in enumerate(wr_dict):
    wr_dict[wrid]['wrseg']=wrstart+i
#correct strtop for high strtop elevations along stream course
#doesn't work with out of order reaches
flowing=False
segs=seg_dict.keys()
segs.sort()
while flowing==False:
    change=0
    for iseg in segs:
        ireaches=seg_dict[iseg]['ireach'].keys()
        ireaches.sort()
        for rch in ireaches:
            try: #get next seg and rch
                if seg_dict[iseg]['ireach'][rch+1]: #assume except if rch+1 doesn't exist for seg
                    nxtrch=rch+1
                    nxtseg=iseg
            except:
                nxtrch=1 #new seg always starts with rch=1
                nxtseg=seg_dict[iseg]['outseg']
            # adjust strtop to ensure lower than previous, based on slope of previous
            if nxtseg>0:
                if seg_dict[iseg]['ireach'][rch]['strtop']<=seg_dict[nxtseg]['ireach'][nxtrch]['strtop']:
                    s1=0.5*seg_dict[iseg]['ireach'][rch]['rchlen']*seg_dict[iseg]['ireach'][rch]['slope']
                    s2=0.5*seg_dict[nxtseg]['ireach'][nxtrch]['rchlen']*seg_dict[nxtseg]['ireach'][nxtrch]['slope']
                    rchred=np.mean([s1,s2]) #average slope of reaches
                    seg_dict[nxtseg]['ireach'][nxtrch]['strtop']=seg_dict[iseg]['ireach'][rch]['strtop']-rchred #reduce elevation by rchred
                    change=change+1
    if change>0:
        flowing=False
    else:
        flowing=True

#correct for strtop < cell bottom. set cell bottom to strtop-minthick. set ib for streams
nss=0
iuzfbnd=getiuzfbnd()
for iseg in seg_dict:
    for rch in seg_dict[iseg]['ireach']:
        i=seg_dict[iseg]['ireach'][rch]['pos'][0]-1 #-1 for python 0 indexing
        j=seg_dict[iseg]['ireach'][rch]['pos'][1]-1
        #assign krch based on iuzfbnd and strhc.
        seg_dict[iseg]['ireach'][rch]['krch']=abs(iuzfbnd[i,j])
        k=seg_dict[iseg]['ireach'][rch]['krch']
        seg_dict[iseg]['ireach'][rch]['strhc']=1000.0 #LHK[k-1][i][j]
##        if seg_dict[iseg]['ireach'][rch]['strhcgroup']=='PN IRRIGATION':
##            seg_dict[iseg]['ireach'][rch]['strhc']=STRHCfact*LHK[k-1][i][j]*pnirrhcfact
##        else:
##            seg_dict[iseg]['ireach'][rch]['strhc']=STRHCfact*LHK[k-1][i][j]
        #fix strtop<cell bottom
        if Lbot[k][i][j]>=seg_dict[iseg]['ireach'][rch]['strtop']-minchthick:
            Lbot[k][i][j]=seg_dict[iseg]['ireach'][rch]['strtop']-minchthick
        for nk in range(k,Llak+nsublay): #bump each successive layer down
            if Lbot[nk+1][i][j]>Lbot[nk][i][j]-minthick:
                Lbot[nk+1][i][j]=Lbot[nk][i][j]-minthick

nss=len(wr_dict)+len(seg_dict)
nstrm=nstrm+len(wr_dict)

# Diversions: find the closest segment to source stream with altitude > highest WR cell
for wrid in wr_dict:
    mind2=30000 #arbitrary minimum distance from segment
    maltirrdex=wr_dict[wrid]['alt'].index(max(wr_dict[wrid]['alt'])) #get maximum altitude of cell covered by wr
    wrrow=wr_dict[wrid]['pos'][maltirrdex][0]
    wrcol=wr_dict[wrid]['pos'][maltirrdex][1]
    wralt=wr_dict[wrid]['alt'][maltirrdex]
    for segid in seg_dict:
        if wr_dict[wrid]['wrsrc'].lower() in seg_dict[segid]['name'].lower(): #current segment and source must match
            segalt=seg_dict[segid]['ireach'][1]['strtop']#reach 1 always highest altitude
            for i in seg_dict[segid]['ireach']:
                segrow=seg_dict[segid]['ireach'][i]['pos'][0]
                segcol=seg_dict[segid]['ireach'][i]['pos'][1]
                rdiff=wrrow-segrow
                cdiff=wrcol-segcol
                d2=rdiff**2+cdiff**2
                if d2 < mind2:# and segalt > wralt: #Leave out altitude requirement for now, assume lateral losses approximated
                    wr_dict[wrid]['iupseg']=segid
                    mind2=d2
# Calculate total acres of WR served by each main ditch
ditchacres={}
for wrid in wr_dict:
    if wr_dict[wrid]['wrsrc'] not in ditchacres:
        ditchacres[wr_dict[wrid]['wrsrc']]=[]
    ditchacres[wr_dict[wrid]['wrsrc']].append(wr_dict[wrid]['acres'])
for da in ditchacres:
    ditchacres[da]=np.sum(ditchacres[da])
#stream width to depth ratios and channel cross sections
##xf=[0.0, 0.25, 0.35, 0.45, 0.5, 0.65, 0.75, 1.0] #fraction of width
##zf=[1,0.3,0.075,0.01,0.0,0.1,0.2,1] #fraction of depth, depth defined by width and wdr
xf=[0.0, 0.25, 0.35, 0.45, 0.5, 0.65, 0.75, 1.0] #fraction of width
zf=[1,0.3,0.075,0.01,0.0,0.1,0.2,1] #fraction of depth, depth defined by width and wdr
for iseg in seg_dict:
    if seg_dict[iseg]['streamtype']==1: #Carson River
        seg_dict[iseg]['wdr']=6. #width to depth ratio for bankfull
        seg_dict[iseg]['xs']=[w*seg_dict[iseg]['width'] for w in xf]
        seg_dict[iseg]['zs']=[w*seg_dict[iseg]['width']/seg_dict[iseg]['wdr'] for w in zf]
    elif seg_dict[iseg]['streamtype']==2: #Irrigation canals creeks
        seg_dict[iseg]['wdr']=15/3. #width to depth ratio for bankfull
        seg_dict[iseg]['xs']=[w*seg_dict[iseg]['width'] for w in xf]
        seg_dict[iseg]['zs']=[w*seg_dict[iseg]['width']/seg_dict[iseg]['wdr'] for w in zf]
    elif seg_dict[iseg]['streamtype']==3 or seg_dict[iseg]['streamtype']==4: #Pine Nut Range creeks
        seg_dict[iseg]['wdr']=12/3. #width to depth ratio for bankfull
        seg_dict[iseg]['xs']=[w*seg_dict[iseg]['width'] for w in xf]
        seg_dict[iseg]['zs']=[w*seg_dict[iseg]['width']/seg_dict[iseg]['wdr'] for w in zf]
    elif seg_dict[iseg]['streamtype']==5: #Crap to be replaced by lake?
        seg_dict[iseg]['wdr']=20/4. #width to depth ratio for bankfull
        seg_dict[iseg]['xs']=[w*seg_dict[iseg]['width'] for w in xf]
        seg_dict[iseg]['zs']=[w*seg_dict[iseg]['width']/seg_dict[iseg]['wdr'] for w in zf]

# Determine unit numbers for gage files.
# SFR tabfiles from directory. Add if stationtype is 'inflow' or 'diversion' in GIS, or ghost node for field diversions
# the divtabsdir, intabsdir must contain files before running
intabs = [f for f in os.listdir(dd['intabsdir']) if '-key' not in f and '.bak' not in f]
divtabs = [f for f in os.listdir(dd['divtabsdir']) if '-key' not in f and '.bak' not in f]
laktabs = [f for f in os.listdir(dd['laktabsdir']) if '-key' not in f and '.bak' not in f]
funit=101
inseg=[]
inlen=[]
divseg=[]
divlen=[]
gagesegrch=[]
i=0
for f in intabs:
    for seg in seg_dict:
        if 'intab' in seg_dict[seg] and len(seg_dict[seg]['intab'])>2: #ignore if empty string
            if seg_dict[seg]['intab'] in f:
                with open(dd['intabsdir']+'\\'+f,'r') as intabf:
                    for c,l in enumerate(intabf): # c will be line count at end of loop
                        if 'indate' not in seg_dict[seg]:
                            seg_dict[seg]['indate']=[]
                        if 'inflow' not in seg_dict[seg]:
                            seg_dict[seg]['inflow']=[]
                        d=l.split()[3].split('-')
                        seg_dict[seg]['indate'].append(datetime.date(int(d[0]),int(d[1]),int(d[2]))) #get date and flow
                        seg_dict[seg]['inflow'].append(l.split()[1])
                    inlen.append(c+1) #number of entries in tabfile
                seg_dict[seg]['tabfile']=(f,funit+i,c+1) #tuple of filename, unit number, length
                inseg.append(seg)
                i=i+1
for f in divtabs: # divtab unit number
    for seg in seg_dict:
        if 'divtab' in seg_dict[seg] and len(seg_dict[seg]['divtab'])>=2: #avoid blank spaces, still get diversions of len=2
            if str(seg_dict[seg]['divtab']).lower() in f and 'c76b-19891001' not in f: #use c76b-ip-3 instead
                with open(os.path.join(dd['divtabsdir'],f),'r') as divtabf: #get line count
                    for c,l in enumerate(divtabf): # c will be line count at end of loop
                        if 'divdate' not in seg_dict[seg]:
                            seg_dict[seg]['divdate']=[]
                        if 'divflow' not in seg_dict[seg]:
                            seg_dict[seg]['divflow']=[]
                        d=l.split()[3].split('-')
                        seg_dict[seg]['divdate'].append(datetime.date(int(d[0]),int(d[1]),int(d[2]))) #get date and flow
                        seg_dict[seg]['divflow'].append(l.split()[1])
                seg_dict[seg]['tabfile']=(f,funit+i,c+1) #tuple of filename, unit number, length
                divseg.append(seg)
                i=i+1
            divlen.append(c+1) #number of entries in tabfile
for f in laktabs: # lak tab unit number
    for lak in lak_dict: #easiest way to write lak file for now, add to lak_dict
        if lak_dict[lak]['name'] in f:
            lak_dict[lak]['tabfile']=(f,funit+i,151) #always 151 entries in lake tabfiles
            i=i+1
for seg in seg_dict: #get gage file unit number for every segment with a station_ID entry
    for rch in seg_dict[seg]['ireach']:
        try:
            if seg_dict[seg]['ireach'][rch]['gage'] is not None:
                seg_dict[seg]['ireach'][rch]['gunit']=funit+i
                gagesegrch.append((seg,rch))
                i=i+1
        except: pass #get gage file unit number, no explicit gage field
for wrid in wr_dict:
    wr_dict[wrid]['wrunit']=funit+i
    wr_dict[wrid]['wrname']=(''.join(wr_dict[wrid]['wrsrc'].split())+'-'+wrid)
    i=i+1

#               PROCESS PRECIP DATA (WITH LAK)
print('Generating precipitation, rch, and lake info\n')
sys.stdout.flush()
#Daily climate data from NOAA
prcpwb=xlrd.open_workbook(prcpfile) #no need to close with xlrd.open_workbook
prcpsheet=prcpwb.sheet_by_index(0)
for r in range(prcpsheet.nrows):
    try: #don't remember why I thought I needed these tries
        ID=str(int(prcpsheet.cell_value(r,0)))
    except:
        ID=str(prcpsheet.cell_value(r,0))
    if ID in prcp_name: #wtf indentation
        if prcp_name not in prcp_dict:
            prcp_dict[prcp_name]={}
            prcp_dict[prcp_name]['sitename']=(prcpsheet.cell_value(r,1))
            prcp_dict[prcp_name]['prcp']=[]
            prcp_dict[prcp_name]['prcpsp']=[] # index [0] start of steady period
            prcp_dict[prcp_name]['date']=[]
            prcp_dict[prcp_name]['wy']=[]
            prcp_dict[prcp_name]['wyprcp']=[]
        try: #should not append value if prcp cannot be converted to value
            pdate=prcpsheet.cell_value(r,2) #date in different format 'YYYYMMDD'
            pyr=int(pdate/10000)
            pmo=int(pdate%10000/100)
            pda=int(pdate%10000%100)
            pdate=datetime.date(pyr,pmo,pda)
            if (min(sp)-datetime.timedelta(days=365))<=pdate<=max(sp): #go back 1 year to get first water year precip
                pamt=max(0,float(prcpsheet.cell_value(r,5)))*0.0003280840 # convert from tenths of mm per day to feet per day
                prcp_dict[prcp_name]['date'].append(pdate)
                prcp_dict[prcp_name]['prcp'].append(pamt)
        except:
        	#print('some prcp entries failed to import: see pfail_dict')
        	if ID not in pfail_dict:
        		pfail_dict[ID]={}
        		pfail_dict[ID]['date']=[prcpsheet.cell_value(r,2)]
        		pfail_dict[ID]['prcp']=[prcpsheet.cell_value(r,5)]
        	else:
        		pfail_dict[ID]['date'].append(prcpsheet.cell_value(r,2))
        		pfail_dict[ID]['prcp'].append(prcpsheet.cell_value(r,5))
for ID in prcp_dict:
    print(prcp_dict[ID]['sitename']+': '+str(len(prcp_dict[ID]['prcp']))+' records\n')
    sys.stdout.flush()
# determine ave precip at station for each stress period
for i in range(1,len(sp)):
    psp=[]
    for j,per in enumerate(period):
        psp=[p for p,d in zip(prcp_dict[prcp_name]['prcp'],prcp_dict[prcp_name]['date']) if sp[i]-tinterval[j]<d<=sp[i]]
        if len(psp)==0: #prcpsp[0] is first stress period
            prcp_dict[prcp_name]['prcpsp'].append(0)
        else:
            prcp_dict[prcp_name]['prcpsp'].append(np.sum(psp)/tinterval[j].days) #stress period average in cfd
##################################
#from Maurer and Halford figure 4... average annual precip (in/yr) as function of altitude
prcpdir=dd['uzfdir']
prcpratio=np.zeros((nrow,ncol))
#west,east
awest=0.0054
aeast=0.0027
bwest=-11.915
beast=-5.3646
MindenAve=8.4 # ave annual precip at Minden inches per year from Maurer and Halford (8.313"/yr from current records)
prcpewa=np.where(ewprcp==1,awest,aeast) #(condition, if true WEST, if false EAST)
prcpewb=np.where(ewprcp==1,bwest,beast)
#precip as function of altitude
prcpratio=(prcpewa*Lbot[0]+prcpewb)/MindenAve #ratio of ave annual prcp at altitude (feet) to ave annual prcp at station (8.4 inches per year)
prcpratiosmooth=ndimage.gaussian_filter(prcpratio,sigma=(3),order=0,mode="nearest")
prcpratiosmooth=prcpratiosmooth.clip(min=0)
prcpratiosmooth=prcpratiosmooth*modext
prcp=[] #list of arrays
for p in prcp_dict[prcp_name]['prcpsp']:
    prcp.append(prcpratiosmooth*p) # steady state is stress period 1, prcpsp[0] and prcp[0]
#lak precip and rnf array
for i in range(1,len(sp)): # zero index sp is sp[1], write accordingly
    for lak in lak_dict: #intermediate lake precip array
        prcplak=prcp_dict[prcp_name]['prcpsp'][i-1]*((lak_dict[lak]['maxalt']*aeast+beast)/MindenAve) #use coefficients for east side, ratio of ave annual prcp at altitude to ave annual prcp at station (8.4 inches per year), converted to ft/day
        rnf=0 #-(lak_dict[lak]['pos']*cwidth*rwidth)/np.max(lak_dict[lak]['area'])
        lak_dict[lak]['rnf'].append(rnf)
        if prcplak>0:
            lak_dict[lak]['prcpsp'].append(prcplak)
        else: lak_dict[lak]['prcpsp'].append(0)

# ssf based on longterm average
longprcp=np.mean(prcp_dict[prcp_name]['prcp']) #in ft/day
for ssfname in ssf_dict:
    if ssfname=='Eagle Valley':
        ssf_dict[ssfname]['aveflow']=1500*AFA2CFD #est of 1500 AFA see Maurer and Berger 1997 or pg 38 Maurer and Berger 2007
    else:
        if ssf_dict[ssfname]['alt']>0: #use west side coefficients to estimate WS prcp from Maurer and Halford
            wsprcp=ssf_dict[ssfname]['area']*longprcp*(ssf_dict[ssfname]['alt']*awest+bwest)/MindenAve #MindenAve in inches per year: cfd*unitless
            ssf_dict[ssfname]['aveflow']=wsprcp #used (/365.25 #annual watershed precip converted to cfd) previously, don't think it is right 3/3/16
        else:
            ssf_dict[ssfname]['aveflow']=0
            #print('ssfyr value for ssf_dict '+str(ssfname)+' not calculated')


# ssf based on water year
### get water year prcp for mountain front recharge
##for s in sp:
##    pcum=[]
##    for d,p in zip(prcp_dict[prcp_name]['date'],prcp_dict[prcp_name]['prcp']):
##        pm=d.month
##        py=d.year
##        if (pm>=10 and py==(s.year-1)) or (pm<10 and py==s.year): # water year
##            pcum.append(p)
##    prcp_dict[prcp_name]['wy'].append(s.year)
##    prcp_dict[prcp_name]['wyprcp'].append(np.mean(pcum)) #wyprcp is mean rate in ft/yr
###water year ssf from prcp, multiple cells per rch zone
###ssfratio used to scale subsurf flow from watersheds as % of annual prcp
### calculate yearly ssf
##for ssfname in ssf_dict:
##    for s in range(0,len(sp)):
##        if ssfname=='Eagle Valley':
##            ssfyr=1500*AFA2CFD #est of 1500 AFA see Maurer and Berger 1997 or pg 38 Maurer and Berger 2007
##        else:
##            if ssf_dict[ssfname]['alt']>0: #use west side coefficients to estimate WS prcp from Maurer and Halford
##                wsprcp=ssf_dict[ssfname]['area']*prcp_dict[prcp_name]['wyprcp'][s]*(ssf_dict[ssfname]['alt']*awest+bwest)/MindenAve
##                ssf_dict[ssfname]['flowsp'].append(wsprcp/365.25) #volume per day from watershed
##            else:
##                ssf_dict[ssfname]['flowsp'].append(0)
##                #print('ssfyr value for ssf_dict '+str(ssfname)+' not calculated')

#           WRITE MODFLOW PACKAGE FILES

#write .nam file
print('writing .nam file\n')
cbunit=50
with open (modir+'\\'+modnam+'.nam','w+') as namfile:
    namfile.write('#Name file for Carson Valley, generated by WK\n')
    namfile.write('LIST          11     output\\'+modnam+'.list\n')
    namfile.write('BAS6          12     '+modnam+'.bas0\n')
    namfile.write('DIS           13     '+modnam+'.dis\n')
    namfile.write('UPW           14     '+modnam+'.upw\n')
    namfile.write('OC            15     '+modnam+'.oc\n')
    namfile.write('GAGE          16     '+modnam+'.gage\n')
    namfile.write('NWT           17     MCR.nwt\n') #stollen from Eric
    namfile.write('UZF           18     '+modnam+'.uzf\n')
    namfile.write('LAK           19     '+modnam+'.lak\n')
    namfile.write('WEL           20     '+modnam+'.wel\n')
    namfile.write('SFR           21     '+modnam+'.sfr\n')
    namfile.write('ZONE           22     '+modnam+'.zon\n')
    namfile.write('MULT           23     '+modnam+'.mlt\n')
    #namfile.write('HOB           22     '+modnam+'.hob\n')
    #namfile.write('DATA          23     output'+'\\'+modnam+'.wrmp\n')
    #namfile.write('DATA          24     output'+'\\'+modnam+'.hobs\n')
    #namfile.write('DATA          26     output'+'\\'+modnam+'.dd\n')
    #namfile.write('DATA          27     output\\'+modnam+'.heds\n')
    #namfile.write('DATA          28     output\\'+modnam+'-prev.heds\n')
    namfile.write('DATA(BINARY)  25     output'+'\\'+modnam+'.bheds\n')
    #namfile.write('DATA(BINARY)  '+str(cbunit)+'     output'+'\\'+modnam+'.cbc\n')
    namfile.write('#tabfiles for streamflow input\n')
    for seg in inseg:#i in zip(inunit, intabs):
        namfile.write('DATA     '+str(seg_dict[seg]['tabfile'][1])+'   intabs\\'+seg_dict[seg]['tabfile'][0]+'\n')
    namfile.write('#tabfiles for main irrigation diversions\n')
    for seg in divseg:#i in zip(divunit,divtabs):
        namfile.write('DATA     '+str(seg_dict[seg]['tabfile'][1])+'   divtabs\\'+seg_dict[seg]['tabfile'][0]+'\n')
    namfile.write('#tabfiles for lake stage-volume-area\n')
    for lak in lak_dict:#zip(lakunit,laktabs):
        namfile.write('DATA     '+str(lak_dict[lak]['tabfile'][1])+'   laktabs\\'+lak_dict[lak]['tabfile'][0]+'\n')
    namfile.write('#stream gage output files\n')
    for sr in gagesegrch:
        namfile.write('DATA     '+str(seg_dict[sr[0]]['ireach'][sr[1]]['gunit'])+'     output'+'\\'+modnam+'-'+seg_dict[sr[0]]['ireach'][sr[1]]['gage'].lower().strip()+'.sgag\n')
    namfile.write('#field diversion gage output files\n')
    for wrid in wr_dict:
        namfile.write('DATA     '+str(wr_dict[wrid]['wrunit'])+'     output'+'\\'+modnam+'-'+wr_dict[wrid]['wrname'].lower().strip()+'.fgag\n')
#write .dis file
with open (modir+'\\'+modnam+'.dis','w+') as disfile:
    disfile.write('# Discretization file for Carson Valley, generated by WK\n')
    disfile.write('         '+str(Llak+nsublay)+'    '+str(nrow)+'    '+str(ncol)+'    '+str(len(sp)-1)+'    4    1    # nsublay, nrow, ncol, nper, days=4, feet=1\n')
    disfile.write('         0    0    0    0    0\n')
    disfile.write('CONSTANT    '+str(rwidth)+'                           #delr\n')
    disfile.write('CONSTANT    '+str(cwidth)+'                           #delc\n')
    for k in range(0,Llak+nsublay+1):
		disfile.write('OPEN/CLOSE     dis\\'+modnam+'-bot'+str(k)+'.lay'+'               1 (FREE)  -1 #bottom of model layer '+str(k)+' altitude\n')
    for i in range(1,len(sp)): #number of stress periods, sp[0] is simstart, sp1 in simulation is from sp[0] to s[[1]
        if i==1: #assume first stress period is steady, use a single day to represent
            sptype='SS'
            disfile.write('1    1    1    '+sptype+'    #perlen, nstp, tsmult: sp '+str(i)+' '+str(sp[i])+'\n')
        else:
            for j,per in enumerate(period):
                if per[0]<=sp[i]<=per[1]:
                    sptype='TR'
                    disfile.write(str((tinterval[j]).days)+'    1    1    '+sptype+'    #perlen, nstp, tsmult: sp '+str(i)+' '+str(sp[i])+'\n')
#write .bas file
with open (modir+'\\'+modnam+'.bas0','w+') as basfile:
	basfile.write('# Basic package file for Carson Valley, generated by WK\n')
	basfile.write('FREE\n')
	for k in range(0,Llak+nsublay): #no layer 0, need k+1
		basfile.write('OPEN/CLOSE     bas\\'+modnam+'-ib'+str(k+1)+'.lay'+'               1 (FREE)  -1 #bottom of model layer '+str(k)+' altitude\n')
	basfile.write('-9999.9     #HNOFLO\n')
	for k in range(0,Llak+nsublay):
		basfile.write('OPEN/CLOSE     dis\\'+modnam+'-inithead.lay'+'               1 (FREE)  -1 #Initial head equal to land surface altitude\n')
#write .upw file
upwparams=True
ftypes=['.upw','.upw.tpl']
ptyp=['HK','VANI']
for ft in ftypes:
    with open (modir+'\\'+modnam+ft,'w+') as upwfile:
        if '.tpl' in ft:
            upwfile.write('ptf @\n')
        upwfile.write('# UPW for Carson Valley, generated by by WK\n')
        upwfile.write('   '+str(-cbunit)+'    -888.0   '+str(len(gelK)*2)+'    0     #Data set 1: unit number, HDRY, NPUPW, IPHDRY\n')
        upwfile.write('    1    1    1    1    1    #Data set 2: laytyp\n')
        upwfile.write('    2    2    2    2    2    #Data set 3: layave\n')
        upwfile.write('    1    1    1    1    1   #Data set 4: chani\n')
        upwfile.write('    1    1    1    1    1    #Data set 5: layvka\n')
        upwfile.write('    0    0    0    0    0    #Data set 6: laywet\n')
        if upwparams:
            for i in range(0,len(gelK)):
                for p in ptyp:
                    pnam=gelnam[i]+str(p)+'mean'
                    if '.tpl' in ft:
                        pval='@     '+pnam+'@'
                    else:
                        pval=gelK[i]

                    #HK
                    upwfile.write('{:<10s} {:>10s} {:>10s} {:>10s} {:>40s}\n'.format(pnam,p,str(pval),str(Llak+nsublay-1),'#Data set 7: PARNAM PARTYP PARVAL NCLU'))
                    for k in range(1,Llak+nsublay):
                        upwfile.write('{:<10s} {:>10s} {:>10s} {:2d}\n'.format(str(k+1),p+'_lay'+str(k+1),'lay'+str(k+1)+'zarr',i+1))
            for i in range(0,len(gelK)*len(ptyp)):
                upwfile.write(str(1)+'\n')
        else:
            for k in range(0,Llak+nsublay): #no layer 0, need k+1
                upwfile.write('OPEN/CLOSE    upw\\'+modnam+'-HK'+str(k+1)+'.lay'+'    1 (FREE)  -1 #Data set 9: HK for model layer '+str(k+1)+'\n')
        for k in range(0,Llak+nsublay):
            if len(sp)>2: #sp[0]=simstart, sp[1]=end of steady, Ss and Sy for transient ONLY
                upwfile.write('OPEN/CLOSE    upw\\'+modnam+'-Ss.lay'+'    1 (FREE)  -1 #Ss\n')
                upwfile.write('OPEN/CLOSE    upw\\'+modnam+'-Sy.lay'+'    1 (FREE)  -1 #Sy\n')


#write uzf file, needed after precip
print('writing .uzf file\n')
with open (modir+'\\'+modnam+'.uzf','w+') as uzffile:
    uzffile.write('#NUZTOP IUZFOPT IRUNFLG IETFLG IUZFCB1 IUZFCB2 NTRAIL2 NSETS2 NUZGAG SURFDEP\n')
    uzffile.write('options\n')
    uzffile.write('SPECIFYTHTR\nSPECIFYTHTI\nSPECIFYSURFK\nSEEPSURFK\nETSQUARE 0.2\n')
    uzffile.write('end\n')
    uzffile.write(' 3      1       1       1    '+str(-cbunit)+'       0     7      75     0      1.0\n') #values came from Middle Carson model (Eric), SURFDEP changed from 5 to 1
    uzffile.write('OPEN/CLOSE   uzf\\'+modnam+'-iuzfbnd.txt'+'  1  (FREE)  -1                       #IUZFBND array file\n')
    uzffile.write('OPEN/CLOSE   uzf\\'+modnam+'-irunbnd.txt'+'  1  (FREE)  -1                       #IRUNBND\n')
    uzffile.write('OPEN/CLOSE   uzf\\'+modnam+'-VKS.txt'+'  1  (FREE)  -1                           #VKS\n')
    uzffile.write('OPEN/CLOSE   upw\CV-wes-9094SS-HK2.lay       0.01        (FREE)   -1        #surfk based on HK of layer 2, 0 if ib[2]==0\n')
    uzffile.write('CONSTANT     3.500                                                               #Brooks-Corey Epsilon\n')
    uzffile.write('OPEN/CLOSE   uzf\\'+modnam+'-THTS.txt  1  (FREE)  -1                             #THTS\n')
    uzffile.write('OPEN/CLOSE   uzf\\'+modnam+'-THTR.txt  1  (FREE)  -1                             #THTR\n')
    uzffile.write('OPEN/CLOSE   uzf\\'+modnam+'-THTI.txt  1  (FREE)  -1                             #THTI\n')
    uzffile.write('1                                                                                #NUZF1 - SS\n')
    uzffile.write('OPEN/CLOSE   uzf\\'+modnam+'-finf-sp1-'+str(sp[1].year)+str(sp[1].month).zfill(2)+str(sp[1].day).zfill(2)+'.finf    '+str(finffact)+'                           (FREE)  -1                   #FINF  - average precip minus estimate of aET '+str(sp[0])+' to '+str(sp[1])+'\n')
    uzffile.write('1                                                                                #NUZF2 - SS\n')
    uzffile.write('OPEN/CLOSE  uzf\\'+modnam+'-pET-sp1-'+str(sp[1].year)+str(sp[1].month).zfill(2)+str(sp[1].day).zfill(2)+'.txt    '+str(np.mean([pEThi,pETlo]))+'               (FREE)    -1    #pET - sp1 '+str(sp[1])+'\n')
    uzffile.write('1                                                                                #NUZF3 - SS\n')
    uzffile.write('OPEN/CLOSE  uzf\\'+modnam+'-extdep.txt    1    (FREE)    -1                      #EXTDP - SS\n')
    uzffile.write('1                                                                                #NUZF4 - SS\n')
    uzffile.write('OPEN/CLOSE  uzf\\'+modnam+'-THTX.txt      1 (FREE)  -1                           #EXTWC - "between THTS-Sy and THTS"\n')
    for i in range(2,len(sp)): # sp[1] is start of transient, len(sp)=2 means steady-state, below is ignored
        uzffile.write('1                                                                            #NUZF1\n')
        uzffile.write('OPEN/CLOSE  uzf\\'+modnam+'-finf-sp'+str(i)+'-'+str(sp[i].year)+str(sp[i].month).zfill(2)+str(sp[i].day).zfill(2)+'.finf  '+str(finffact)+'                (FREE)    -1    #FINF - sp '+str(i)+' '+str(sp[i])+'\n')
        uzffile.write('1                                                                            #NUZF2\n')
        uzffile.write('OPEN/CLOSE  uzf\\'+modnam+'-pET-sp'+str(i)+'-'+str(sp[i].year)+str(sp[i].month).zfill(2)+str(sp[i].day).zfill(2)+'.txt    '+pET[i]+'         (FREE)    -1    #pET - sp '+str(i)+' '+str(sp[i])+'\n')
        uzffile.write('-1                                                                           #EXTDP\n')
        uzffile.write('-1                                                                           #NUZF4\n')
#write oc file
with open (modir+'\\'+modnam+'.oc','w+') as ocfile:
    ocfile.write('HEAD SAVE UNIT 25\n')
    #ocfile.write('HEAD SAVE FORMAT (10F11.4)\n')
    #ocfile.write('HEAD SAVE UNIT 27\n')
    ocfile.write('COMPACT BUDGET AUX\n')
    for s in range(1,len(sp)):
        if s==1:
            ocfile.write('PERIOD '+str(s)+' STEP 1  DDREFERENCE #ending '+str(sp[s])+'\n') #add ddreference
        else:
            ocfile.write('PERIOD '+str(s)+' STEP 1  #ending '+str(sp[s])+'\n')
        ocfile.write('PRINT BUDGET\n')
        #ocfile.write('SAVE BUDGET\n')
        ocfile.write('SAVE HEAD\n')
##        if sp[s].month==10 and 1<=sp[s].day<=7 or sp[s]==sp[-1]:
##            ocfile.write('SAVE DRAWDOWN\n')
#write .gage file
with open (modir+'\\'+modnam+'.gage','w+') as gagefile:
    gagefile.write(str(len(gagesegrch)+len([wr for wr in wr_dict if 'wrunit' in wr_dict[wr]]))+'     #NUMGAGE, headers: GAGESEG, GAGERCH, UNIT, OUTYPE\n') #new gage for each wr field diversion
    for sr in gagesegrch:
        if seg_dict[sr[0]]['ireach'][sr[1]]['stationtype']=='diversion':
            outtype=5
        else:
            outtype=0
        gage=(sr[0],sr[1],seg_dict[sr[0]]['ireach'][sr[1]]['gunit'],outtype)
        gagecom=('     #gage for '+str(seg_dict[sr[0]]['ireach'][sr[1]]['gage'])+'\n')
        gagefile.write('%10i%10i%15s%10i' %gage)
        gagefile.write(gagecom)
    for wrid in wr_dict:
        gage=(wr_dict[wrid]['wrseg'],1,wr_dict[wrid]['wrunit'],5)
        gagecom=('     #gage for '+str(wr_dict[wrid]['wrname'])+'\n')
        gagefile.write('%10i%10i%15s%10i' %gage)
        gagefile.write(gagecom)


#write .lak file
with open (modir+'\\'+modnam+'.lak','w+') as lakfile:
    lakfile.write('TABLEINPUT\n')
    ds1=(len(lak_dict.keys()),-cbunit)
    ds1com=('     #Data Set 1: NLAKES, IlakCB\n')
    lakfile.write('%10i%10i' %ds1)
    lakfile.write(ds1com)
    ds2=(-0.75,100,0.001,0.5)
    ds2com=('     #Data Set 2: THETA,[NSSITR],[SSCNCR],SURFDEP\n')
    lakfile.write('%10.4f%10i%10.4f%10.4f' %ds2)
    lakfile.write(ds2com)
    for i,lak in enumerate(lak_dict):
            ds3=(lak_dict[lak]['maxalt'], lak_dict[lak]['minalt'], lak_dict[lak]['maxalt'], int(lak_dict[lak]['tabfile'][1]))
            ds3com=('    #Data Set 3: ssinitial, SSMN, SSMX, IUNITTAB for '+lak_dict[lak]['name']+'\n')
            lakfile.write('%10.4f %10.4f %10.4f %i'  %ds3)
            lakfile.write(ds3com)
    ds4=(1,1,0)
    ds4com='     #Data Set 4: ITMP,ITMP1,LWRT\n'
    lakfile.write('%10i%10i%10i' %ds4)
    lakfile.write(ds4com)
    lakfile.write('OPEN/CLOSE    lak\\'+modnam+'-lak-array.txt    1    (FREE)    -1    #Data Set 5: lakid layer 1\n')
    for i in range(2,Llak+nsublay+1):
        lakfile.write('CONSTANT 0    #Data Set 5: lakid layer '+str(i)+'\n')
    lakfile.write('OPEN/CLOSE    lak\\'+modnam+'-lak-BDLKNC.txt    1    (FREE)    -1    #Data Set 6: BDLKNC layer 1\n')
    for i in range(2,Llak+nsublay+1):
        lakfile.write('CONSTANT 0    #Data Set 6: BDLKNC layer '+str(i)+'\n')
    lakfile.write('0    #Data Set 7: number of sublakes\n')
    for i in range(1,len(sp)):
        for per in period:
            if per[0]<=sp[i]<=per[1]:
                for lak in lak_dict:
                    if lak in activelak: #active lakes for SS period
                        ds9=(lak_dict[lak]['prcpsp'][i-1],wevap,lak_dict[lak]['rnf'][i-1],0)#0.02 evap about 6mm/day, total guess
                        ds9com=('    #Data Set 9: PRCPlak, EVAPlak, RNF, WTHDRW, SSMN, SSMX: Stress Period '+str(i)+' '+str(sp[i])+' for '+lak_dict[lak]['name']+'\n')
                        lakfile.write('%10.4f%10.4f%10.4f%10.4f' %ds9)
                        lakfile.write(ds9com)
                    else: #inactive lakes
                        ds9=(0,0.0,0,0)
                        ds9com=('    #Data Set 9: PRCPlak, EVAPlak, RNF, WTHDRW, SSMN, SSMX: Stress Period '+str(i)+' '+str(sp[i])+' for '+lak_dict[lak]['name']+'\n')
                        lakfile.write('%10.4f%10.4f%10.4f%10.4f' %ds9)
                        lakfile.write(ds9com)

# Write .sfr file
print('writing .sfr file\n')
ntabs=max(max(inlen),max(divlen))
with open (modir+'\\'+modnam+'.sfr','w+') as sfrfile:
    #header and data set 1
    sfrfile.write('# SFR: Stream-Flow Routing package file created from file generated by Sue Buto\'s sfr toolbox\n')
    sfrfile.write('options\n')
    sfrfile.write('STRHC1KV    '+str(factorkv)+'\n')
    sfrfile.write('LOSSFACTOR  '+str(lossfactor)+'\n')
    sfrfile.write('REACHINPUT\n')
    sfrfile.write('TABFILES    '+str(len(inseg)+len(divseg))+'    '+str(ntabs)+'    #tabfiles, numtab, maxval\n')
    sfrfile.write('end\n')

    ds1c=(nstrm,nss,0,0,128390.4,dleak,-cbunit,0,1,5,5,80) # nsfrsets=30 from Eric MCR, replace -1 with cbunit to write cbc instead of LST
    ds1ccom='     # Data Set 1c: NSTRM NSS NSFRPAR NPARSEG CONST DLEAK ISTCB1 ISTCB2 [ISFROPT NSTRAIL ISUZN NSFRSETS]\n'
    sfrfile.write('%i %i %i %i %.10E %.10E %i %i %i %i %i %i' %ds1c) #### %i %i %i %i
    sfrfile.write(ds1ccom)
    for iseg in isegsort:#data set 2
        for ireach in seg_dict[iseg]['ireach']:
            r=seg_dict[iseg]['ireach'][ireach]['pos'][0]
            c=seg_dict[iseg]['ireach'][ireach]['pos'][1]
            lay=seg_dict[iseg]['ireach'][ireach]['krch']
            ds2=(lay,r,c,iseg,ireach,seg_dict[iseg]['ireach'][ireach]['rchlen'],seg_dict[iseg]['ireach'][ireach]['strtop'],seg_dict[iseg]['ireach'][ireach]['slope'],seg_dict[iseg]['ireach'][ireach]['strthick'],seg_dict[iseg]['ireach'][ireach]['strhc'],THTSarr[r-1][c-1],THTIarr[r-1][c-1],EPS,UHCfact*ib[lay-1][r-1][c-1])
            ds2com=('      # Data Set 2: KRCH IRCH JRCH ISEG IREACH RCHLEN [STRTOP SLOPE STRTHICK STRHC1 THTS THTI EPS UHC]\n')
            sfrfile.write('%i  %i  %i  %i  %i  %.10E %.10E  %.10E  %.4f  %.4f  %.10E  %.10E  %.4f  %.4f' %ds2) ####
            sfrfile.write(ds2com)
    for i,wrid in enumerate(wr_dict):#write information for ghost nodes
        iup=wr_dict[wrid]['iupseg']
        iuplay=seg_dict[iup]['ireach'][1]['krch']
        iuprow=seg_dict[iup]['ireach'][1]['pos'][0]
        iupcol=seg_dict[iup]['ireach'][1]['pos'][1]
        iupalt=seg_dict[iup]['ireach'][1]['strtop']
        ds2div=(iuplay,iuprow,iupcol,wr_dict[wrid]['wrseg'],1,1,iupalt,1.0,1.0,0.0001,THTSarr[r-1][c-1],THTIarr[r-1][c-1],EPS,0.0001)
        ds2divcom=('      # Data Set 2: irrigation diversion ghost node '+wrid+'\n')
        sfrfile.write('%i  %i  %i  %i  %i  %.10E %.10E  %.10E  %.4f  %.4f  %.10E  %.10E  %.4f  %.4f' %ds2div) ####
        sfrfile.write(ds2divcom)
    sfrfile.write(str(nss)+' 0 0 # Data Set 5, Stress period 1: ITMP IRDFLG IPTFLG\n') #"ITMP must be defined = 0 for the first stress period of a simulation."
    for iseg in seg_dict: #data 6, flows and channel characteristics, first stress period only,
        if 'gage' in seg_dict[iseg]['ireach'][1] and (seg_dict[iseg]['ireach'][1]['gage']=='BROCK' or seg_dict[iseg]['ireach'][1]['gage']=='mlic'):
            dflow=1e20 #take it all, see Unger pg 17
        else:
            dflow=0 #overwritten by tabfile where necessary
        if 'iupseg' in seg_dict[iseg] and seg_dict[iseg]['iupseg']>0:
            if 'tabfile' in seg_dict[iseg] and 'c76b-ip3' in seg_dict[iseg]['tabfile'][0]: #Snowshoe 2, intermittently used, prefer to fill Mud Lake in model
                iprior=-3
            else:
                iprior=0
            ds6a=(iseg, 2, seg_dict[iseg]['outseg'], seg_dict[iseg]['iupseg'], iprior, dflow, 0, wevap, 0, manning, manning)
            sfrfile.write('%i  %i  %i  %i  %i  %i  %i  %i  %i  %.3f  %.3f' %ds6a)
        else:
            ds6a=(iseg, 2, seg_dict[iseg]['outseg'], seg_dict[iseg]['iupseg'], dflow, 0, wevap, 0, manning, manning)
            sfrfile.write('%i  %i  %i  %i  %i  %i  %i  %i  %.3f  %.3f' %ds6a)
        ds6acom=('    # Data Set 6a: NSEG ICALC OUTSEG IUPSEG [IPRIOR if iupseg>0] FLOW RUNOFF ETSW PPTSW ROUGHCH ROUGHBK\n')
        sfrfile.write(ds6acom)
        if len(seg_dict[iseg]['xs'])!=len(seg_dict[iseg]['zs']):
            print('doh, cross section is invalid nx != nz\n')
            sys.stdout.flush()
        for pt in range(0,len(seg_dict[iseg]['xs'])):
            sfrfile.write('%.4f  '%seg_dict[iseg]['xs'][pt])
        sfrfile.write(' # Data set 6d1: XCPT1 XCPT2 ... XCPT'+str(len(seg_dict[iseg]['xs']))+'\n')
        for pt in range(0,len(seg_dict[iseg]['zs'])):
            sfrfile.write('%.4f  '%seg_dict[iseg]['zs'][pt])
        sfrfile.write(' # Data set 6d2: ZCPT1 ZCPT2 ... ZCPT'+str(len(seg_dict[iseg]['zs']))+'\n')
    wrstart=max(isegsort)+1 #write information for ghost node, ghost segments, steady state
    for i,wrid in enumerate(wr_dict):
        if wr_dict[wrid]['effsrc'] is not None:
            wr_dict[wrid]['irrate']=0.001 #leave 0.001 cfs in "segment"
            wr_dict[wrid]['iprior']=-3
        elif wrid in ['DVS','DVN']: #Diamond Valley areas, no alpine priority, ever irrigated? Will be when STPUD takes water back
            wr_dict[wrid]['irrate']=0
            wr_dict[wrid]['iprior']=0
        else:
            if irrmeth=='upstream':
                wr_dict[wrid]['iprior']=0 #take all that is available up to irrate
                if 'acres' in wr_dict[wrid]:
                    wr_dict[wrid]['irrate']=wr_dict[wrid]['acres']*annirr#/(12./irrmonths) #divide annirr by 12/months for annual rate
                else:
                    print('no acres reported for water right: '+str(wrid))
            elif irrmeth=='equal': #doesn't work yet, need to calculate what to leave for downstream users with higher priority
                wr_dict[wrid]['iprior']=-3
                source=wr_dict[wrid]['wrsrc']
                wr_dict[wrid]['irrate']=wr_dict[wrid]['acres']/ditchacres[source]
            else:
                print('irrigation method = '+irrmeth+' not defined')
        irrseg=wr_dict[wrid]['iupseg']
        if irrseg>0:
            ds6a=(-(wrstart+i), 1, 0, irrseg, wr_dict[wrid]['iprior'], wr_dict[wrid]['irrate'], 0, wevap, 0, manning)
            sfrfile.write('%i  %i  %i  %i  %i  %8.5E  %i  %i  %i  %.3f' %ds6a)
        else:
            print('no iupseg for water right: '+str(wrid)) #nothing to print if no iupseg
        ds6acom=('    # Data Set 6a: NSEG ICALC OUTSEG IUPSEG [IPRIOR if iupseg>0] FLOW RUNOFF ETSW PPTSW ROUGHCH\n')
        sfrfile.write(ds6acom) #first stress period only
        ds6d1=('7        #Data Set 6d1: Ghost node, wrid='+str(wrid)+', priority='+wr_dict[wrid]['priority']+', acres='+str(int(wr_dict[wrid]['acres']))+'\n')
        ds6d2=('7        #Data Set 6d2: Ghost node, WR: '+str(wrid)+'\n')
        sfrfile.write('%s' %ds6d1)
        sfrfile.write('%s' %ds6d2)
        nirr=len(wr_dict[wrid]['pos']) #number of cells in wr poly
        sfrfile.write(str(nirr)+'  '+str(consumpfact)+'\n')
        for k in range(0,nirr):
            divblock=(wr_dict[wrid]['pos'][k][0],wr_dict[wrid]['pos'][k][1],(1./nirr-0.0001)) #subtract 0.0001 to suppress warning "sums to value greater than 1"
            sfrfile.write(' '+'%i  %i  %.5f\n' %divblock)
    for seg in inseg:# TABFILES
        line=(seg,seg_dict[seg]['tabfile'][2],seg_dict[seg]['tabfile'][1],'    #tabfile for ',seg_dict[seg]['tabfile'][0],'\n')
        sfrfile.write('%10i%10i%10i%s%s%s' %line)
    for seg in divseg:
        line=(seg,seg_dict[seg]['tabfile'][2],seg_dict[seg]['tabfile'][1],'    #tabfile for ',seg_dict[seg]['tabfile'][0],'\n')
        sfrfile.write('%10i%10i%10i%s%s%s' %line)
    for s in range(2,len(sp)): # begin transient field diversions, steady state is sp1
        for per in period:
            if per[0]<=sp[s]<=per[1]:
                sfrfile.write(' '+str(len(wr_dict))+' 0 0 # Data Set 5, Stress period '+str(s)+', ending '+str(sp[s])+': ITMP IRDFLG IPTFLG\n') #cumbersome... writes 0 flow for all non-irrigated periods
                for i,wrid in enumerate(wr_dict):
                    if wr_dict[wrid]['effsrc'] is not None:
                        wr_dict[wrid]['irrate']=0.1 #leave 0.1 cfs in "segment
                        wr_dict[wrid]['iprior']=-3
                    else:
                        if 4<=sp[s].month<=10: #wr diversions only for April-Oct
                            if 'acres' in wr_dict[wrid]:
                                wr_dict[wrid]['irrate']=wr_dict[wrid]['acres']*annirr
                            else:
                                print('no acres reported for water right: '+str(wrid))
                        else:
                            wr_dict[wrid]['irrate']=0
                    if wr_dict[wrid]['iupseg']>0:
                        ds6a=(-(wrstart+i), 1, 0, wr_dict[wrid]['iupseg'], wr_dict[wrid]['iprior'], wr_dict[wrid]['irrate'], 0, wevap, 0, manning)
                        sfrfile.write('%i  %i  %i  %i  %i  %8.5E  %i  %i  %i  %.3f' %ds6a)
                    else:
                        print('no iupseg for water right: '+str(wrid)) #nothing to print if no iupseg
                    ds6acom=('    # Data Set 6a: NSEG ICALC OUTSEG IUPSEG [IPRIOR if iupseg>0] FLOW RUNOFF ETSW PPTSW ROUGHCH\n')
                    sfrfile.write(ds6acom)
                    nirr=len(wr_dict[wrid]['pos']) #number of cells in wr poly
                    sfrfile.write(str(nirr)+'  '+str(consumpfact)+'\n')
                    for k in range(0,nirr):
                        divblock=(wr_dict[wrid]['pos'][k][0],wr_dict[wrid]['pos'][k][1],(1./nirr-0.0001)) #subtract 0.0001 to suppress warning "sums to value greater than 1"
                        sfrfile.write(' '+'%i  %i  %.5f\n' %divblock)

# read yearly pumpage for each well, output from CV-pumps2 in cfd
pmp_fail=[]
with open (apmpnam,'r') as pmpfile:
    data=pmpfile.readlines()
    header=data[0].split('\t')
    for l in data[1:]:
        d=l.split('\t')
        ID=d[header.index('ID')]
        typ=d[header.index('typ')]
        if ID in pmp_dict:
            for yr in header[2:]:
                pmp_dict[ID]['pmpyr'][int(yr)]=int(d[header.index(yr)])
        else:
            print(str(ID)+' in '+apmpnam+' but not in '+pmppts)
            pmp_fail.append(ID)#wells in adjusted pump file but not in model domain
print('\n'+str(len(pmp_fail))+' pumps failed during reading of '+str(apmpnam)+'\n')

# determine stress period pumpage. Calculate daily, then average over each sp
print('determining stress period pumpage... this may take a while\n')
for ID in pmp_dict:
    typ=pmp_dict[ID]['type']
    pmpdate=[]
    pmprate=[]
    sspr=[]
    r=pmp_dict[ID]['pos'][0]
    c=pmp_dict[ID]['pos'][1]
    if len(pmp_dict[ID]['pmpyr'].keys())>0:
        maxyear=np.max(pmp_dict[ID]['pmpyr'].keys())
    else:
        maxyear=9999
        print('no max year for well '+str(ID))
    for pyr in pmp_dict[ID]['pmpyr']:
        if sp[0].year<=pyr<=sp[1].year: #steady state
            pmpdate.append(sp[1])
            pmprate.append(np.mean(pmp_dict[ID]['pmpyr'][pyr]))#in cfd
        else: #transient
            for s in sp:
                if s.year>maxyear: #use last year with data
                    pmpdate.append(s)
                    pmprate.append(pmp_dict[ID]['pmpyr'][maxyear]*365.25*MOUmonthly[typ][s.month-1]/30)
                else:
                    if s.year==pyr:
                        pmpdate.append(s)
                        pmprate.append(pmp_dict[ID]['pmpyr'][pyr]*365.25*MOUmonthly[typ][s.month-1]/30) #date.month=1 for January, MOUmonthly[0] for Jan, calculate monthly average in cfd assuming 30 days per month
    for i in range(1,len(sp)):
        for per in period:
            if per[0]<=sp[i]<=per[1]:
                if len(pmprate)==len(pmpdate): #dum check
                    pmpsp=[p for p,date in zip(pmprate,pmpdate) if date>sp[i-1] and date<=sp[i]]
                else:
                    print('error: pmprate and pmpday different size')
        if len(pmpsp)>0:
            pmp_dict[ID]['pmpsp'].append(np.mean(pmpsp))
        elif modext[r-1][c-1]==0:
            print(ID+' outside model domain\n')
        else:
            pmp_dict[ID]['pmpsp'].append(0)  # no record, assume 0 pumpage
##            print('no value in '+ID+' for sp '+str(i)+'\n')

#septic data
print('processing septic data\n')
for apn in sep_dict:
    for i in range(1,len(sp)):#d in sp:
        if sep_dict[apn]['conyr']>=sp[i].year:
            sep_dict[apn]['flowsp'].append(seprate*int(sep_dict[apn]['nsep']))
        else:
            sep_dict[apn]['flowsp'].append(0)

#               CLEAN UP AND FIX ARRAYS
#clean up arrays
for k in range(0,Llak+nsublay+1):
    Lbot[k]=np.nan_to_num(Lbot[k])
    Lbot[k]=Lbot[k]*modext

#ib=0 for cells where modext=0
for i in range(0,nrow):
    for j in range(0,ncol):
##        if modext[i][j]>0 and surfgeo[i][j]==0:
##            surfgeo[i][j]=gelK[2] #arbitrary
        if modext[i][j]==0:
            ib[:,i,j]=0

iuzfbnd=getiuzfbnd()

# check that all wells are in active cells
def welcheck(dic):
    for id in dic:
        r=dic[id]['pos'][0]
        c=dic[id]['pos'][1]
        if 'lay' in dic[id]:
            lay=dic[id]['lay']
        else:
            print('No layer for '+str(id))
        if ib[lay-1][r-1][c-1]==0:
            print('well '+id+' not in active cell')
welcheck(pmp_dict)
#welcheck(sep_dict)
#welcheck(ssf_dict)
# calculate nssf for flow>0
nssf=0
ssfparam=0
for ssfname in ssf_dict:
    if ssf_dict[ssfname]['aveflow']>0: # or np.sum(ssf_dict[ssfname]['flowsp'])>0
        ssfparam=ssfparam+1
        ssf_dict[ssfname]['ncells']=len(ssf_dict[ssfname]['pos'])
        nssf=nssf+ssf_dict[ssfname]['ncells'] #janky, total number of subsurface flow cells (i.e. injection wells)

# Write .wel file
print('writing .wel file\n')
with open (modir+'\\'+modnam+'.wel','w+') as welfile:
    welfile.write('#WEL: Carson Valley Modflow pmp file generated by Wes Kitlasten python script CVwel.py\n')
    ds1=('PARAMETER',ssfparam,nssf)
    ds1com=('    #Data set 1: PARAMETER, NPWEL, MXL (params for subsurface inflow only)\n')
    welfile.write('%s %10i %10i' %ds1)
    welfile.write(ds1com)
    ds2a=(len(pmp_dict)+len(sep_dict)+nssf,-cbunit)
    ds2acom=('     #Data set 2a: MXACTW, IWELCB\n')
    welfile.write('%10i %10i' %ds2a)
    welfile.write(ds2acom)
    #ds2b=('SPECIFY',0.05,23) #Is this optional?
    #ds2bcom=('    #Data set 2b: SPECIFY,PHIRAMP,IUNITRAMP\n')
    #welfile.write('%10s %10.2f %10i' %ds2b)
    #welfile.write(ds2bcom)
    for ssfname in ssf_dict: #write subsurface inflow params
        if np.sum(ssf_dict[ssfname]['aveflow'])>0:
            parnam=''.join(ssfname.split())[0:9].ljust(10,'Q')
            ds3=(parnam,'Q',ssf_dict[ssfname]['ssfratio'],ssf_dict[ssfname]['ncells'])#,'INSTANCES',len(sp)-1)
            welfile.write('%10s %10s %10.4f %10i' %ds3) #%12s %5i
            welfile.write('    #Data set 3: PARNAM,PARTYP,PARVAL,NLST; PARVAL=ratio of subsurface inflow to WS prcp, assumed constant for given year\n')
            #for s in range(1,len(sp)): #time-varying well input
            #instnam=parnam[0:10] #+'SP'+str(s)
            #welfile.write(instnam+'    #Parameter instance being use for all stress periods\n')#in stress period '+str(s)+' from '+str(sp[s-1])+' to '+str(sp[s])+'\n')
            cellflow=float(ssf_dict[ssfname]['aveflow'])/ssf_dict[ssfname]['ncells']
            for pos in ssf_dict[ssfname]['pos']:
                r=pos[0]
                c=pos[1]
                for l in range(1,len(ib)+1):
                    k=len(ib)-l
                    if ib[k][r-1][c-1]==1:
                        ssf_dict[ssfname]['lay']=k+1 #highest ib
                if 'lay' not in ssf_dict[ssfname] or ssf_dict[ssfname]['lay']<=0:
                    print(ssfname+' SSF cell not in domain (row,col) '+str(r)+','+str(c))
                else:
                    ds4b=(ssf_dict[ssfname]['lay'],r,c,cellflow)
                    welfile.write('%5i %5i %5i   %10.4f' %ds4b)
                    welfile.write(' #Data set 4b: Layer, Row, Col, Qfact for mountain front recharge\n')

    for s in range(1,len(sp)):# simstart=sp[0], first stress period (sp[1]) marks start of transient (simstart+steadyper)
        for per in period:
            if per[0]<=sp[s]<=per[1]:
                itmp=len([p for p in pmp_dict if pmp_dict[p]['pmpsp'][s-1]>0 and 'lay' in pmp_dict[p]])+len([sep for sep in sep_dict if sep_dict[sep]['flowsp'][s-1]>0])
                ds5=(itmp,ssfparam)
                ds5com='     #Data set 5: ITMP, NP: stress period '+str(s)+' '+str(sp[s])+'\n'
                welfile.write('%10i %10i' %ds5)
                welfile.write(ds5com)
                for ID in pmp_dict:
                    if pmp_dict[ID]['pmpsp'][s-1]>0 and 'lay' in pmp_dict[ID]:
                        ds6=(pmp_dict[ID]['lay'],pmp_dict[ID]['pos'][0],pmp_dict[ID]['pos'][1],-(pmp_dict[ID]['pmpsp'][s-1]))
                        ds6com=('     #pmp ID: '+str(ID)+' '+pmp_dict[ID]['type']+'\n')
                        welfile.write('%4i %4i %4i %1.4f' %ds6)
                        welfile.write(ds6com)
                for apn in sep_dict:
                    if sep_dict[apn]['flowsp'][s-1]>0:
                        for pos in sep_dict[apn]['pos']:
                            r=pos[0]
                            c=pos[1]
                            ds6=(abs(iuzfbnd[r-1][c-1]),r,c,sep_dict[apn]['flowsp'][s-1]) #all septic rch to top by iuzfbnd
                            ds6com=('    #Septic for APN '+str(apn)+'\n')
                            welfile.write('%4i %4i %4i %10.4f' %ds6)
                            welfile.write(ds6com)
                for ssfname in ssf_dict: #pname and iname come after each stress period
                    if np.sum(ssf_dict[ssfname]['aveflow'])>0:
                        #for s2 in range(1,len(sp)):
                        parnam=''.join(ssfname.split())[0:9].ljust(10,'Q')
                        #instnam=parnam[0:5]+'SP'+str(s2)
                        ds7=(parnam,'\n')#instnam,
                        welfile.write('%10s %s' %ds7)#%10s

#determine initial head array
##tarr=np.where(Lbot[0]>0,Lbot[0],9999)
##inithead=modext*np.min(tarr) #50' below lowest surface point in model
#secant method fails, likely due to stream bed issues?
inithead=modext*Lbot[0] #top of lakes
for i in range(0,nrow):
    for j in range(0,ncol):
        if lakid[i][j] in activelak:
            BDLKNC[i][j]=bdlknc#UHCfact*LHK[2][i][j] # conductivity under lakes
        else:
            BDLKNC[i][j]=0
        if lakid[i][j]==6 or lakid[i][j]==7:
            BDLKNC[i][j]=0 #low conductance for Bently, NVWWTP lined effluent storage
#               WRITE ARRAYS
print('writing arrays\n')
#write new layer altitude arrays
for k in range(0,Llak+nsublay+1):
	np.savetxt(dd['disdir']+'\\'+modnam+'-bot'+str(k)+'.lay',Lbot[k],fmt='%.1f',delimiter='  ') #bottom of layer 0=top of layer 1, etc
np.savetxt(dd['disdir']+'\\'+modnam+'-inithead.lay',inithead,fmt='%.1f',delimiter='  ')
#write layer ibound arrays
for k in range(0,Llak+nsublay): #no layer 0, need k+1
	np.savetxt(dd['basdir']+'\\'+modnam+'-ib'+str(k+1)+'.lay',ib[k],fmt='%i',delimiter='  ')
#write lkarr array
np.savetxt(dd['lakdir']+'\\'+modnam+'-lak-BDLKNC.txt',BDLKNC,fmt='%.8f',delimiter='  ')
np.savetxt(dd['lakdir']+'\\'+modnam+'-lak-array.txt',lakid,fmt='%i',delimiter='  ')
#write layer upw arrays
np.savetxt(dd['upwdir']+'\\'+modnam+'-Ss.lay',Ssarr[k]*modext,fmt='%.5e',delimiter='  ')
np.savetxt(dd['upwdir']+'\\'+modnam+'-Sy.lay',Syarr[k]*modext,fmt='%.5e',delimiter='  ')
np.savetxt(dd['upwdir']+'\\'+modnam+'-HK1.lay',BDLKNC,fmt='%2.1f',delimiter='  ')
np.savetxt(dd['upwdir']+'\\'+modnam+'-VANI1.lay',BDLKNC,fmt='%2.1f',delimiter='  ')
for k in range(1,Llak+nsublay): #no layer 0, need k+1
    np.savetxt(dd['upwdir']+'\\'+modnam+'-HK'+str(k+1)+'.lay',ib[k]*modext,fmt='%2.1f',delimiter='  ')
    for i in range(0,nrow):
        for j in range(0,ncol):
            if zone[k][i][j]==1: #fluvial
                VANI[k][i][j]=VANIfluv*ib[k][i][j]
            elif zone[k][i][j]==2: #alluv
                VANI[k][i][j]=VANIalluv*ib[k][i][j]
            else:
                VANI[k][i][j]=1.0*ib[k][i][j] #no difference in HK and VK for other geology
    np.savetxt(dd['upwdir']+'\\'+modnam+'-VANI'+str(k+1)+'.lay',VANI[k]*modext,fmt='%2.1f',delimiter='  ')

#write VKS array
for i in range(0,nrow):
    for j in range(0,ncol):
        k=abs(iuzfbnd[i][j])-1 #index of layer at surface
        VKS[i][j]=modext[i][j]*VKSfact
np.savetxt(dd['uzfdir']+'\\'+modnam+'-VKS.txt',VKS,fmt='%2.1f',delimiter='  ')

#write uzf arrays
for i in range(0,nrow):
    for j in range(0,ncol):
        cthick=Lbot[abs(iuzfbnd[i][j])-1][i][j]-Lbot[abs(iuzfbnd[i][j])][i][j]
        if cthick<minthick and cthick>0:
            extd[i][j]=0.8999*cthick
        else:
            extd[i][j]=extdepth
np.savetxt(dd['uzfdir']+'\\'+modnam+'-extdep.txt',modext*extd,fmt='%.4f',delimiter='  ')
np.savetxt(dd['uzfdir']+'\\'+modnam+'-THTS.txt',THTSarr,fmt='%.8E',delimiter='  ')
np.savetxt(dd['uzfdir']+'\\'+modnam+'-THTR.txt',THTRarr,fmt='%.8E',delimiter='  ')
np.savetxt(dd['uzfdir']+'\\'+modnam+'-THTX.txt',THTXarr,fmt='%.8E',delimiter='  ')
np.savetxt(dd['uzfdir']+'\\'+modnam+'-THTI.txt',THTRarr,fmt='%.8E',delimiter='  ')
np.savetxt(dd['uzfdir']+'\\'+modnam+'-irunbnd.txt',irunbnd,fmt='%i',delimiter='  ')
##if uzfET==0: #-iuzfbnd means no uzf ET, handled by aETfact instead
##    iuzfbnd=-iuzfbnd
np.savetxt(dd['uzfdir']+'\\'+modnam+'-iuzfbnd.txt',iuzfbnd,fmt='%i',delimiter='  ')
#write et array, CONSTANT used for steady state.
#fake ET arrays, improve with Justin's METRIC data
##for s in range(1,len(sp)):
##    if  len(sp)==2: #steady state len(sp)==2
##        for i in range(0,nrow):
##            for j in range(0,ncol):
##                    aET[i][j]=modext[i][j]*pET[i][j]
##    elif sp[s-1].month>=4 and sp[s-1].month<=9:
##        aET=modext*pEThi #about 4feet in 4 months for growing season
##    else: aET=modext*pETlo
ETarr=hiET
#ETarr=modext
##for s in range(1,len(sp)):
##    if sp[s].month>=10 or sp[s].month<=3: #low ET months
##        pET=ETarr*pETlo #pEThi equivalent to 3.65ft/yr
##    else:
##        pET=ETarr*pEThi #pEThi equivalent to 3.65ft/yr
np.savetxt(dd['uzfdir']+'\\'+modnam+'-pET-sp'+str(s)+'-'+str(sp[s].year)+str(sp[s].month).zfill(2)+str(sp[s].day).zfill(2)+'.txt',ETarr,fmt='%.8f',delimiter='  ')

#write finf array
finflist=[]
for s in range(1,len(sp)): # prcp[0] is for sp[1]
    for i in range(0,nrow):
        for j in range(0,ncol):
            finf[i][j]=prcp[s-1][i][j]
    finf=finf*modext*np.abs(lakext-1)
    finflist.append(finf)
    finf=finf.clip(min=0) #negative finf clipped to very small in MF
    np.savetxt(dd['uzfdir']+'\\'+modnam+'-finf-sp'+str(s)+'-'+str(sp[s].year)+str(sp[s].month).zfill(2)+str(sp[s].day).zfill(2)+'.finf',finf,fmt='%.8f',delimiter='  ')

#External budget components not used in modflow simulation
###write ssf total inflows
##with open (os.path.join(modir,'output',modnam+'-ssf.tot'),'w+') as ssff:
##    for ssfnam in ssf_dict:
##        line=(ssfnam,ssf_dict[ssfnam]['aveflow']*ssf_dict[ssfnam]['ssfratio'],' #average annual flow in cfd\n')
##        ssff.write('%22s  %10.4f  %s' %line)
###write prcpET (1-aETfact)*prcp, amount of prcp lost to ET when uzfET not simulated
##with open (os.path.join(modir,'output',modnam+'-prcpET.tot'),'w+') as prcpETf:
##    for s in range(1,len(sp)): # prcp[0] is for sp[1]
##        prcpET=np.sum(prcp[s-1])*rwidth*cwidth*(1-aETfact)
##        line=(s,prcpET,' #flow for sp '+str(s)+' ending '+str(sp[s])+'\n')
##        prcpETf.write('%4s  %10.4f  %s' %line)
###write prcp
##with open (os.path.join(modir,'output',modnam+'-prcp.tot'),'w+') as prcpETf:
##    for s in range(1,len(sp)): # prcp[0] is for sp[1]
##        prcpET=np.sum(prcp[s-1])*rwidth*cwidth
##        line=(s,prcpET,' #prcp for sp '+str(s)+' ending '+str(sp[s])+'\n')
##        prcpETf.write('%4s  %10.4f  %s' %line)

#zone bound (all layers) as mask for pilot points instead of ibound, due to zones in multiple layers
zbnd=np.zeros((len(gelK),nrow,ncol)) #7 zones including null
for k in range(0,len(zone)):
    for i in range(0,nrow):
        for j in range(0,ncol):
            if zone[k][i][j]*ib[k][i][j]==1: #fluv
                zbnd[0][i][j]=1
            elif zone[k][i][j]*ib[k][i][j]==2: #alluv
                zbnd[1][i][j]=1
            elif zone[k][i][j]*ib[k][i][j]==3: #Tert sediment
                zbnd[2][i][j]=1
            elif zone[k][i][j]*ib[k][i][j]==4: #Tert volcanic
                zbnd[3][i][j]=1
            elif zone[k][i][j]*ib[k][i][j]==5: #intrusive
                zbnd[4][i][j]=1
            elif zone[k][i][j]*ib[k][i][j]==6: #metamorphic
                zbnd[5][i][j]=1
            elif zone[k][i][j]*ib[k][i][j]==7: #null
                zbnd[6][i][j]=1

#get surface obs sites
sob_dict={}
for seg in seg_dict:
    for rch in seg_dict[seg]['ireach']:
        if 'gage' in seg_dict[seg]['ireach'][rch] and seg_dict[seg]['ireach'][rch]['gage'] is not None:
            sob_dict[seg]={}
            sob_dict[seg]['gage']=seg_dict[seg]['ireach'][rch]['gage']
            sob_dict[seg]['pos']=seg_dict[seg]['ireach'][rch]['pos']
            r=sob_dict[seg]['pos'][0]
            c=sob_dict[seg]['pos'][1]
            cid=cellid[r-1][c-1]
            sob_dict[seg]['zone']=int(zone[Llak][r-1][c-1])
            sob_dict[seg]['lay']=Llak+1 #always
            sob_dict[seg]['utm']=cell_utm[cid]

#import additional utilities
sys.path.append(os.path.join(root,r'CarsonValley\wespythoncode\modules'))
import points2pp

#write files to import into Keith's PP generator
pppath=os.path.join(modir,'pilotpoints')
if not os.path.exists(pppath):
    os.makedirs(pppath)
for z in range(0,len(zbnd)):
    np.savetxt(pppath+'\\'+modnam+'-zbnd'+str(z+1)+'.txt',zbnd[z],fmt='%i',delimiter='\t')
points2pp.obs2pp(pppath,[hob_dict,sob_dict],sp) #trans_dict,
points2pp.cell2pp(pppath,cell_utm,cellid) #just grid specifications

#   PEST STUFF
parg_dict = {'F':'Kfl','A':'Kag','S':'Kts','V':'Ktv','G':'Kig','M':'Kmv'}
pestpath=os.path.join(modir,'PEST')
#write zone arrays
if not os.path.exists(pestpath):
    os.makedirs(pestpath)
for k in range(0,Llak+nsublay): #no layer 0, need k+1
    zn=zone[k]*ib[k]
    np.savetxt(pestpath+'\\'+modnam+'-lay'+str(k+1)+'.zon',zn,fmt='%i',delimiter='  ')

# write grid specification and settings.fig file
with open(os.path.join(pestpath,'CV-gridspec.txt'),'w') as gridspec:
    gridspec.write('{:5}{:5}\n'.format(nrow,ncol))
    gridspec.write('{:.3f}{:15.3f}{:6.3f}\n'.format(cell_utm[1][0]-rwidth/2/3.28084,cell_utm[1][1]+cwidth/2/3.28084,0))
    gridspec.write('{}*{:.3f}\n'.format(ncol,550/3.28084))
    gridspec.write('{}*{:.3f}\n'.format(nrow,550/3.28084))
with open(os.path.join(pestpath,'settings.fig'),'w') as setting:
    setting.write('colrow=no\n')
    setting.write('date=mm/dd/yyyy')

# add h=strtop for all gages that are not inflows (inflows affected by HNOFLO)
for seg in seg_dict:
    for rch in seg_dict[seg]['ireach']:
        if 'gage' in seg_dict[seg]['ireach'][rch]:
            if seg_dict[seg]['ireach'][rch]['stationtype']!='inflow' and seg_dict[seg]['ireach'][rch]['gage']!='10311000': #no obs for inflow or outflow
                if len(seg_dict[seg]['ireach'][rch]['gage'])>8: #mod2obs has limit of 10 characters
                    hob='fh'+seg_dict[seg]['ireach'][rch]['gage'][-8:]
                else:
                    hob='fh'+str(seg_dict[seg]['ireach'][rch]['gage'])
                hob_dict[hob]={}
                i=seg_dict[seg]['ireach'][rch]['pos'][0]-1
                j=seg_dict[seg]['ireach'][rch]['pos'][1]-1
                hob_dict[hob]['lay']=seg_dict[seg]['ireach'][rch]['krch']
                hob_dict[hob]['utm']=cell_utm[cellid[i,j]]
                hob_dict[hob]['hobss']=seg_dict[seg]['ireach'][rch]['strtop']
                hob_dict[hob]['hobalt']=seg_dict[seg]['ireach'][rch]['strtop'] #head at surface for all flow obs, wt=0 if flow=0
# determine SS obs
hlist=sorted(hob_dict.keys())
for hob in hlist:
    if 'fh' not in hob[0:2]: #only do for wells
        altlist=[]
        for date in hob_dict[hob]['date']:
            if sp[0]<=date<=sp[1]: #steady state
                altlist.append(hob_dict[hob]['hobalt'])
        hob_dict[hob]['hobss']=np.mean(altlist)
#    write mod2obs files and PEST instruction file
with open(os.path.join(pestpath,modnam+'-obslisting.txt'),'w') as hfile:
    for hob in hlist:
        hfile.write('{}\n'.format(hob))
with open(os.path.join(pestpath,modnam+'-obswellcoord.txt'),'w') as hfile:
    for hob in hlist:
        hfile.write('{:<14s}{:>14.1f}{:>14.1f}{:>4d}\n'.format(hob,hob_dict[hob]['utm'][0],hob_dict[hob]['utm'][1],hob_dict[hob]['lay']))
with open(os.path.join(pestpath,modnam+'-headobs.txt'),'w') as hfile:
    for hob in hlist:
        hfile.write('{:<14s}{:%m/%d/%Y %H:%M:%S}{:>14.5f}\n'.format(hob,sp[1],hob_dict[hob]['hobss']))
with open(os.path.join(pestpath,modnam+'-headsim.txt.ins'),'w') as hfile:
    hfile.write('pif @\n')
    for hob in hlist:
        hfile.write('{} [{}]{}\n'.format('l1',hob,'38:48'))

#Find nearest points to be used in obs2obs utility
ndist=1000.0
for hob1 in hlist:
    hob_dict[hob1]['nearest']=[]
    for hob2 in hlist:
        if hob1!=hob2:
            x1=hob_dict[hob1]['utm'][0]
            y1=hob_dict[hob1]['utm'][1]
            x2=hob_dict[hob2]['utm'][0]
            y2=hob_dict[hob2]['utm'][1]
            dist=np.sqrt((x2-x1)**2+(y2-y1)**2)
            if dist<=ndist:
                if 'nearest' in hob_dict[hob2] and hob1 not in hob_dict[hob2]['nearest']:
                    hob_dict[hob1]['nearest'].append(hob2)
# define equations
dhlist=[]
i=0
for hob1 in hlist:
    for hob2 in hob_dict[hob1]['nearest']:
        i=i+1
        hdifname='hdif'+str(i)
        hob_dict[hdifname]={}
        dhlist.append(('hdif'+str(i),hob1,hob2))
        hob_dict[hdifname]['hobss']=hob_dict[hob1]['hobss']-hob_dict[hob1]['hobss']
# append headobs file
with open(os.path.join(pestpath,modnam+'-headobs.txt'),'a') as hfile:
    for eq in dhlist:
        hfile.write('{:<14s}{:%m/%d/%Y %H:%M:%S}{:>14.5f}\n'.format(eq[0],sp[1],hob_dict[eq[1]]['hobss']-hob_dict[eq[2]]['hobss']))
#write obs2obs file
with open(os.path.join(pestpath,modnam+'-obs2obs.txt'),'w') as ofile:
    ofile.write('* model output\n')
    ofile.write(modnam+'-headsim.txt.ins    ../output/'+modnam+'-headsim.txt\n')
    ofile.write('* equations\n')
    for eq in dhlist:
        ofile.write(eq[0]+'='+eq[1]+'-'+eq[2]+'\n')
    ofile.write('* output\n')
    for j in range(1,i+1):
        ofile.write('hdif'+str(j)+'\n')
##    for hob in hlist:
##        ofile.write(hob+'\n')
