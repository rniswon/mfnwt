# Make control file from pilot point tpl files, hob file, etc

import os

root=r'S:\CarsonValley\MODFLOW'
modir=os.path.join(root,'CV-wes-94SS')
pestdir=os.path.join(modir,'PEST')

group={'F':'Kfl','A':'Kag','S':'Kts','V':'Ktv','G':'Kig','M':'Kmv'}
p_dict={}

# read pilot points from tpl file
for f in os.listdir(pestdir):
    if '.tpl' in f and 'lay' in f:
        dex=f.index('lay') #start of string 'lay'
        lay=f[dex+3] #get layer number
        with open(os.path.join(pestdir,f),'r') as tpl:
            while True:
                line=tpl.readline() #get current line
                data=line.strip().split() #split line into string
                if not line: break #stop if there is not line

                for d in data: #loop through all strings in list
                    if '@' in d and len(d)>2: #ignore @ in first line
                        pname=d.replace('@','') #get rid of @ symbols
                        p_dict[pname]={} #new sub dictionary {}
                        p_dict[pname]['group']=group[pname[-1]] #group defined by last letter in pname

