# write data from dic to tab delim file to import into Keith's PP
# called from model build, with or without trans dict

import os
import numpy as np

def obs2pp(pppath,dics,sp=[],zn=6):
    data={} #dict of data for each dic entry
    for dic in dics:
        for ID in dic:
            if 'date' in dic[ID]: #hobs have dates, aqtests and sobs don't
                for d in dic[ID]['date']:
                    if ID not in data:
                        if len(sp)==0 or sp[0]<=d<=sp[-1]: #base pp on all records [len(sp)==0] or duration of simulation
                            if 'zone' in dic[ID]:
                                data[ID]=(str(dic[ID]['USGSsite']),str(ID),dic[ID]['utm'][0],dic[ID]['utm'][1],dic[ID]['lay'],dic[ID]['zone'],'\n')
                            else:
                                print('no zone data for '+str(ID))
            else: #aqtests keep, in zone 2 for now (alluv) and surface obs should always be in top layer (not Llak)
                if ID not in data:
                    if 'gage' in dic[ID]: #stream gage
                        data[ID]=(str(dic[ID]['gage']),'sgag_'+str(ID),dic[ID]['utm'][0],dic[ID]['utm'][1],dic[ID]['lay'],dic[ID]['zone'],'\n')
                    elif dic[ID]['type']=='TRANS': #transmissivity, ID=well log number
                        data[ID]=('log_'+str(ID),'log_'+str(ID),dic[ID]['utm'][0],dic[ID]['utm'][1],dic[ID]['lay'],dic[ID]['zone'],'\n')
                    elif 'USGSsite' in dic[ID]: #NWIS data
                        data[ID]=(str(dic[ID]['USGSsite']),str(ID),dic[ID]['utm'][0],dic[ID]['utm'][1],dic[ID]['lay'],dic[ID]['zone'],'\n')

    for z in range(1,(zn+1)):
        print('Obs points for zone '+str(z))
        hobout=os.path.join(pppath,'hob_data_zone_'+str(z)+'.txt')
        with open (hobout,'w+') as hf:
            header=('USGS_site','site_name','UTMx','UTMy','layer','zone\n')
            hf.write('%20s %12s %12s %12s %5s %5s' %header)
            for ID in data:
                if data[ID][5]==z:
                    hf.write('%20s %12s %12.2f %12.2f %5i %s %s' %data[ID])
#print out grid data
def cell2pp(pppath,cell,cellid):
    gridout=os.path.join(pppath,'cell_center_loc.txt')
    with open(gridout,'w+') as cf:
        data=('cell_ID','cell_UTMx','cell_UTMy\n')
        cf.write('%10s %12s %12s' %data)
        for ID in cell:
            pos=np.where(cellid==ID)
            r=int(pos[0]+1)
            c=int(pos[1]+1)
            data=(ID,cell[ID][0],cell[ID][1],r,c,'\n')
            cf.write('%10i %12.2f %12.2f %5s %5s %s' %data)