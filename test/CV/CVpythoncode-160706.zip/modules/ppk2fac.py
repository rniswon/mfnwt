# create pilot point factor files using ppk2fac

from subprocess import Popen, PIPE
import os

root='S:\\'
pestdir=os.path.join(root,'CarsonValley\\MODFLOW\\CV-wes-94SS\\PEST')
ppk2facdir=os.path.join(pestdir,'ppk2fac')
ppk2fac=os.path.join(ppk2facdir,'ppk2fac.exe')

gridspec = 'CV-wes-94SS-gridspecification.txt'
ppfile = '..\\PP_lay2.txt'

##with Popen([ppk2fac], stdin=PIPE, stdout=PIPE) as proc:
##    for line in proc.stdout:
##        print(line)

proc=Popen((ppk2fac,'\\n'), cwd=ppk2facdir, stdin=PIPE, stdout=PIPE)
print( proc.stdout.flush())

while proc.poll()==None: #while not terminated
    for line in proc.stdout.readline():
        print(line)