#-------------------------------------------------------------------------------
# Name:        gethob
# Purpose:      Problem getting Lbot,nrow,ncol,etc recognized as global.
#               Module works fine if part of main script but not when imported.
#
# Author:      wkitlasten
#
# Created:     29/12/2015
# Copyright:   (c) wkitlasten 2015
# Licence:     <your licence>
#-------------------------------------------------------------------------------
import arcpy
import numpy as np

# Get GIS data for grid
def getgrid(gridpts):
    lines = arcpy.SearchCursor(gridpts)
    for l in lines:
        Lbot[0][l.row-1][l.col-1]=l.L1_Top #altitude of bottom of layer 0=top of layer 1
        Lbot[Llak][l.row-1][l.col-1]=l.L1_Top #altitude of bottm of lake layer, Lbot[0] if no lakes
        ib[Llak][l.row-1][l.col-1]=l.ibsurf #ibound for top layer, ib[0]=0 when lakes present
        d2bd[l.row-1][l.col-1]=l.d2bd_151215
        surfgeo[l.row-1][l.col-1]=l.geo_surf
        modext[l.row-1][l.col-1]=l.model_ext
        ewprcp[l.row-1][l.col-1]=l.EWprcp
        cellid[l.row-1][l.col-1]=l.OBJECTID
        WHSF[l.row-1][l.col-1]=l.WofHSF
        metabase[l.row-1][l.col-1]=l.meta_basement
        if l.model_ext>0:
            irunbnd[l.row-1][l.col-1]=int(l.irunbnd)
    del l
    del lines

# Get GIS data for subsurface recharge (underflow)
def getssflow(ssfpts):
    dic={}
    lines = arcpy.SearchCursor(ssfpts)
    for l in lines:
        if l.ssf_name not in dic:
            dic[l.ssf_name]={}
            dic[l.ssf_name]['area']=l.area_ft2
            dic[l.ssf_name]['alt']=l.mean_alt_ft
            dic[l.ssf_name]['cells']=[]
            dic[l.ssf_name]['flowsp']=[]
        dic[l.ssf_name]['cells'].append((l.Row-1,l.Col-1))
    del l
    del lines
    return(dic)

# Get septic data from GIS
def getseptic(seppts):
    dic={}
    lines = arcpy.SearchCursor(seppts)
    for l in lines:
        if l.DWELLINGS>0 and l.SEPTICS>0:
            if l.APN not in dic:
                dic[l.APN]={}
                dic[l.APN]['conyr']=int(l.CON_YEAR)
                dic[l.APN]['nsep']=l.SEPTICS #number of septic systems
                dic[l.APN]['cells']=[]
                dic[l.APN]['flowsp']=[]
                dic[l.APN]['cells'].append((l.Row-1,l.Col-1))
    del l
    del lines
    return(dic)

# get lake cell data from GIS
def getlak(lakpts):
    dic={}
    lakext=np.zeros((nrow,ncol))
    lakid=np.zeros((nrow,ncol))
    lines = arcpy.SearchCursor(lakpts)
    for l in lines:
        if l.LAKid not in dic:
            dic[l.LAKid]={}
            dic[l.LAKid]['name']=l.LAKnam
            dic[l.LAKid]['cells']=1
            dic[l.LAKid]['stage']=[]
            dic[l.LAKid]['prcpsp']=[]
            dic[l.LAKid]['rnf']=[]
            dic[l.LAKid]['area']=[]
            dic[l.LAKid]['vol']=[]
        else:
            dic[l.LAKid]['cells']=dic[l.LAKid]['cells']+1
        if l.LAKid>0:
            lakext[l.Row-1][l.Col-1]=1
            lakid[l.Row-1][l.Col-1]=l.LAKid
        else: lakext[l.Row-1][l.Col-1]=0
    del l
    del lines
    return(dic,lakext,lakid)


# get water rights data from GIS
def getwr(wrpts):
    lines = arcpy.SearchCursor(wrpts)
    for l in lines:
        wrid=str(l.wt_rt_id)
        if wrid not in wr_dict: #cells with no wr are blank
            wr_dict[wrid]={}
            wr_dict[wrid]['pos']=[]
            wr_dict[wrid]['alt']=[]
        wr_dict[wrid]['wrsrc']=l.Model_src #name of supplying stream
        #    wr_dict[wrid]['effsrc']=l.Effluent_src #none if supplying effluent pond
        wr_dict[wrid]['wryr']=l.Alp_priority
        wr_dict[wrid]['alpacres']=l.Alp_acres
        wr_dict[wrid]['acres']=l.Acres
        wr_dict[wrid]['alt'].append(l.L1_top)
        wr_dict[wrid]['pos'].append((l.Row,l.Col))
    del l
    del lines

# get pmp data from GIS, generic depth by type if none exists
def getpmp(dic,moex=True): #moex=true only get pmp within maximum model extent
    dic={}
    lines = arcpy.SearchCursor(pmppts)
    for l in lines:
        proc=0
        r=l.Row
        c=l.Col
        if moex==True:
            if modext[l.Row-1][l.Col-1]==1:
                proc=1
        else:
            proc=1
        if proc==1:
            ID=str(l.wellID)
            if ID not in dic:
                dic[ID]={}
                dic[ID]['type']=str(l.w_Type)
                dic[ID]['pos']=(r,c)
                dic[ID]['pou']=[] #to be a list of (row,col)
                dic[ID]['pmpyr']={}
                dic[ID]['pmpsp']=[]
                if l.w_LowerZ>0: #prefer lowerZ to allow pumping max depth
                    dic[ID]['scralt']=l.w_LowerZ
                    dic[ID]['depth']=Lbot[0][r-1][c-1]-l.w_LowerZ
                elif  l.w_HigherZ>0:
                    dic[ID]['scralt']=l.w_HigherZ
                    dic[ID]['depth']=Lbot[0][r-1][c-1]-l.w_HigherZ
                else:
                    dic[ID]['scralt']=0 #to be corrected after DWR data read
                    dic[ID]['depth']=0
    del l
    del lines
    #make consistent types
    for ID in pmp_dict:
        try:
            s=['-','_','&',''] #various symbols used in same MOU abbreviations
            if 'DOM' in pmp_dict[ID]['type']:
                pmp_dict[ID]['type']='DOM'
            elif pmp_dict[ID]['type']=='IRR' or pmp_dict[ID]['type'] in ['I'+i+'D' for i in s]: # or pmp_dict[ID]['type']=='REC'
                pmp_dict[ID]['type']='IRR'
            elif pmp_dict[ID]['type'] in ['Q'+i+'M' for i in s] or pmp_dict[ID]['type']=='MUN':
                pmp_dict[ID]['type']='MUN'
            elif 'COM' in pmp_dict[ID]['type']:
                pmp_dict[ID]['type']='COM'
            elif pmp_dict[ID]['type'] in ['S'+i+'D' for i in s] or pmp_dict[ID]['type'] in ['I'+i+'S' for i in s] or pmp_dict[ID]['type']=='STK':
                pmp_dict[ID]['type']='STK'
            else:
                pmp_dict[ID]['type']='OTH'
        except:
            print('cannot convert type for: '+ID+' in '+pumpfile+'\n')
    return(dic)

# get hobs data from GIS, generic depth by type if none exists
def gethob(hobpts,surf,sp=[]): #sp=[list of stress periods as datetime], only gets hobs within range of stress periods
    dic={}
    lines = arcpy.SearchCursor(hobpts)
    for l in lines:
        proc=0
        if len(sp)>0:
            if l.LEV_DT.date()>=sp[0] and l.LEV_DT.date()<=sp[-1]:
                proc=1
        else:
            proc=1
        if proc==1:
            ID=str(l.short_name) #short name=simple sequence, agency code - site, e.g.:USGS-384554119504201, gets cut off
            if ID not in dic: #type and location shouldn't change
                dic[ID]={}
                dic[ID]['date']=[]
                dic[ID]['hobbgs']=[]
                dic[ID]['hobsalt']=[]
                dic[ID]['type']='OBS'
            r=l.Row
            c=l.Col
            dic[ID]['pos']=(r,c)
            #dic[ID]['type']=str(l.WATER_USE_1_CD)
            dic[ID]['roff']=0 #364224*(l.cell_lat-l.DEC_LAT_VA)/cwidth #convert from decimal degrees to ft: negative to N, positive to south
            dic[ID]['coff']=0 #284207*(l.DEC_LONG_VA-l.cell_long)/rwidth #convert from decimal degrees to ft: negative to west, positive to east
            dic[ID]['date'].append(l.LEV_DT.date())
            try:
                dic[ID]['depth']=float(l.WELL_DEPTH_VA) #considered top of screen, subtract from cell elevation. ~5% of NWIS wells in area have no depth determined
                dic[ID]['scralt']=surf[r-1][c-1]-dic[ID]['depth']
            except:
                dic[ID]['depth']=0 #set to maximum measured water depth (hobbgs) further down
                dic[ID]['scralt']=0
            try:
                lev=float(l.LEV_VA)
                dic[ID]['hobbgs'].append(lev)
                dic[ID]['hobsalt'].append(surf[r-1,c-1]-lev)
            except: #assumes l.LEV_VA cannot be converted due to space between '-' and '#'
                lev=float(l.LEV_VA.split()[0]+l.LEV_VA.split()[1])
                dic[ID]['hobbgs'].append(lev)
                dic[ID]['hobsalt'].append(surf[r-1,c-1]-lev)
            if l.LEV_ACY_CD=='0': #0=foot, 1=1/10 foot, 2=1/100 foot, 9=not to nearest foot
                dic[ID]['acy']=1
            elif l.LEV_ACY_CD=='1':
                dic[ID]['acy']=1./10
            elif l.LEV_ACY_CD=='2':
                dic[ID]['acy']=1./100
            else: #junk data
                dic[ID]['acy']=10
    del l
    del lines
    return(dic)

# get POU data associated with each well from GIS
def getpou(pmppoupts):
    lines = arcpy.SearchCursor(pmppoupts)
    for l in lines:
        ID = l.wellID
        if ID in pmp_dict:
            pmp_dict[ID]['pou'].append((l.Row,l.Col))
            d8=datetime.date(l.prior_dt)
            if d8.year!=pmp_dict[ID]['conyr']: #issue warning for inconsistent dates
                print('different conyr and priyr for '+ID)

# Get SFR data from GIS
def getsfr(sfrpts):
    lines = arcpy.SearchCursor(sfrpts)
    ngage=0
    nstrm=0
    for l in lines:
        if l.iseg not in seg_dict:
            seg_dict[l.iseg]={}
            seg_dict[l.iseg]['outseg']=l.OutSeg
            seg_dict[l.iseg]['iupseg']=l.iUpSeg
            seg_dict[l.iseg]['streamtype']=l.streamtype
            seg_dict[l.iseg]['width']=l.s_WIDTH1
            seg_dict[l.iseg]['name']=l.nameLong
            seg_dict[l.iseg]['ireach']={}
        if l.iReach not in seg_dict[l.iseg]['ireach']:
            seg_dict[l.iseg]['ireach'][l.iReach]={}
            seg_dict[l.iseg]['ireach'][l.iReach]['krch']=l.kRch
            seg_dict[l.iseg]['ireach'][l.iReach]['pos']=(l.iRch,l.jRch)
            seg_dict[l.iseg]['ireach'][l.iReach]['rchlen']=l.rchlen
            seg_dict[l.iseg]['ireach'][l.iReach]['strtop']=l.StrTop_ft
            if l.slope>minsfrslope:
                seg_dict[l.iseg]['ireach'][l.iReach]['slope']=l.slope
            else:
                seg_dict[l.iseg]['ireach'][l.iReach]['slope']=minsfrslope
            seg_dict[l.iseg]['ireach'][l.iReach]['strthick']=l.strThick
            seg_dict[l.iseg]['ireach'][l.iReach]['strhc1']=l.strHC1
            seg_dict[l.iseg]['ireach'][l.iReach]['gage']=l.StationID #gages can be any reach
            seg_dict[l.iseg]['ireach'][l.iReach]['stationname']=l.StationName
            seg_dict[l.iseg]['ireach'][l.iReach]['stationtype']=l.station_type
        try:
            if 'inflow' in l.station_type:
                seg_dict[l.iseg]['intab']=l.StationID.strip()
        except: pass #no infow for segment
        try: #diversions apply to entire segment, not individual reaches
            if 'diversion' in l.station_type:
                seg_dict[l.iseg]['divtab']=l.StationID.lower().strip()
        except: pass #no diversion for segment
        if l.StationID>0:
            ngage=ngage+1
        nstrm=nstrm+1 #total number of stream reaches
    del l
    del lines