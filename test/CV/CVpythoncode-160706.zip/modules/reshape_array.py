a=np.zeros((5,258,206))
##base=r'S:\CarsonValley\PEST runs\CV-wes-9094SS-326-5\upw\CV-wes-9094SS-HK'
##for i in range(0,5):
##    a[i]=np.loadtxt(base+str(i+1)+'.lay')

b=np.zeros((5,258,206))
fbase=r'S:\CarsonValley\PEST runs\CV-wes-9094SS\upw\CV-wes-9094SS-HK'
for i in range(0,5):
    dum=[]
    with open(fbase+str(i+1)+'.lay','r') as kfile:
        data=kfile.readlines()
    for d in data:
        line=d.strip().split()
        for v in line:
            dum.append(float(v))
    data=np.array(dum)
    b[i]=data.reshape((258,206))

for k in range(0,5):
    plt.imshow(b[k])
    plt.colorbar()
    plt.show()