import numpy as np
import os

#sort data based on periods
def tssort(dic,period,datekey='date',flowkey='flow',output=False):
    '''sort timeseries data by period and date
    should handle period[0] after period[1] for climate reconstructions'''
    for fid in dic:
        if output==True:
            print('sorting based on periods for {0}\n'.format(fid))
        dates=[]
        newflist=[]
        for per in period:
            datelist=[] #list of dates in period per
            for d,f in zip(dic[fid][datekey],dic[fid][flowkey]):
                if per[0]<=d<=per[1] and d not in dates:
                    datelist.append(d)
            persort=sorted(datelist)
            dates=dates+persort #in order defined by periods, not linear time
        for d in dates:
            ddex=dic[fid][datekey].index(d)
            newflist.append(dic[fid][flowkey][ddex])
        dic[fid]['sortdate']=dates
        dic[fid]['sortflow']=newflist

#convert dictionary ts to sp averages within period
def ts2period(dic,sp,period,datekey='date',flowkey='flow',minvals=4,output=False):
    '''sort timeseries data by period and dat (call tssort)
    calculate stress period average
    assuming minvals=4, accomodates 2@0 and 2@aveflow'''
    tssort(dic,period,datekey=datekey,flowkey=flowkey)
    for fid in dic:
        if output==True:
            print('calculating period averages for {}\n'.format(fid))
        for d in dic[fid]['sortdate']:
            if sp[0]<=d<=sp[1]: # assume first two sp are for steady state
                dt=sp[1]-sp[0] #time interval required for SS average
                newsp0=sp[0]
                cumflow=[]
                availvals=[d8 for d8,f in zip(dic[fid]['sortdate'],dic[fid]['sortflow']) if (sp[0]<=d8<=sp[0]+dt)] #flows within SS period
                availvals.sort()
                if len(availvals)<minvals:
                    print('WARNING: not enough values in timeseries to calculate SS average for {0}, searching for new period\n'.format(fid))
                    sp0back=sp[0]-dt
                    sp0forward=sp[0]+dt
                    while np.abs((sp[0]-sp0back).days)<365*100 and np.abs((sp[0]-sp0forward).days)<365*100: #limit search to 100 years
                        if len([d8 for d8 in dic[fid]['sortdate'] if sp0back<=d8<=sp0back+dt])<minvals:
                            newsp0=sp0back-dt #go back dt in time
                            sp0back=newsp0 #kick out of while loop if enough values found in range
                        if len([d8 for d8 in dic[fid]['sortdate'] if sp0forward<=d8<=sp0forward+dt])<minvals:
                            newsp0=sp0forward+dt #go forward dt in time
                            sp0forward=sp0forward #kick out of while loop if enough values found in range
                    print('new period found for {0}: {1} to {2}\n'.format(fid,newsp0,newsp0+dt))
                t1=newsp0
                t2=newsp0+dt
                for k in range(0,len(dic[fid]['sortflow'])-1):
                    if t1<=dic[fid]['sortdate'][k]<=t2:
                        cumflow.append(np.mean([dic[fid]['sortflow'][k+1],dic[fid]['sortflow'][k]])*(dic[fid]['sortdate'][k+1]-dic[fid]['sortdate'][k]).days)
                ssflow=np.sum(cumflow)/(t2-t1).days
                fsort=[ssflow,ssflow]
                dsort=[t1,t2]
            else: #transient, let MF average tabfiles, need something for non tabfile inputs
                sdex=dic[fid]['sortdate'].index(d)
                fsort.append(dic[fid]['sortflow'][sdex])
                dsort.append(d)
        if output==True:
            print('SS range for {2}: {0} to {1}\n'.format(t1,t2,fid))
        dic[fid]['sortdate']=dsort
        dic[fid]['sortflow']=fsort


# Get simulation days, for use in tabfiles only, let MF interpolate
def simdays(dic,sp,period,tinterval,datekey='sortdate'):
    '''generate values for each simulation day'''
    for fid in dic:
        dic[fid]['simday']=[]
        for i,per in enumerate(period):
            if i==0: #SS
                dic[fid]['simday']=[0,1] #start and end of first period is day 0 and 1
            else:
                dlist=[d for d in dic[fid][datekey] if per[0]<=d<=per[1]]
                for date in dlist:
                    if date==per[0]:
                        if i>1:
                            perstart=(sp.index(date)-1)*tinterval[i-1].days+1 #day that period i starts
                        else:
                            perstart=(sp.index(date)-1)*tinterval[i].days+1
                    day=(date-per[0]).days+perstart
                    dic[fid]['simday'].append(int(day))

# write a flow dictionary to TSPROC "site sample file" format
# include comments for regressed, interpolated, monthly mean, etc
def dic2ssf(dic,tsfile,flowkey='flow',datekey='date',suffix=''):
    with open(tsfile,'w+') as tsfile:
        for site in dic:
            if flowkey in dic[site] and datekey in dic[site]:
                tsfile.write('# Flow record for %s for use in TSPROC\n' %dic[site]['name'])
                tsfile.write('# date format is dd/mm/yyyy\n')
                if 'fcomment' in dic[site]: #file level comment
                    tsfile.write('# %s\n' %dic[site]['fcomment'])
                for i in range(0,len(dic[site][datekey])):
                    if 'rcomment' in dic[site] and len(dic[site]['rcomment'])==len(dic[site][flowkey]) and dic[site]['rcomment']!='': #record level comment
                        tsfile.write('# %s applies to the following line\n' %dic[site]['rcomment'][i])
                    d8=str(dic[site][datekey][i].day)+'/'+str(dic[site][datekey][i].month)+'/'+str(dic[site][datekey][i].year)
                    data=(site,d8,'12:00:00',dic[site][flowkey][i],'\n')
                    tsfile.write('%s     %10s %10s  %10.4f  %s' %data)
        else:
            print('no flowkey={0} or datekey={1} in dictionary {2}'.format(flowkey,datekey,site))

#add simday d.01 after day d, copy next flow value
def add01(dic,day):
    for ID in dic:
        for d in day:
            dex=dic[ID]['simday'].index(d)+1 #inserts before dex, thus +1
            dic[ID]['simday'].insert(dex,d+0.01)
            dic[ID]['perdate'].insert(dex,dic[ID]['perdate'][dex])
            dic[ID]['perflow'].insert(dex,dic[ID]['perflow'][dex])