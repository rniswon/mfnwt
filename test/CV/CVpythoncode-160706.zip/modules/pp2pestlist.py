# Read UTMx,UTMy for each PP in a zone generated from Keith's spreadsheets
# ID is PP+str(cellid in 2D)
# Determine layer by cellid and zone arrays
# Write to new file: UTMx,UTMy,zone,@PPID@

import os,xlrd
import numpy as np

root=r'S:/CarsonValley\MODFLOW\CV-wes-9094SS'
gelK=[10.,5.,2.,1.,0.1,0.1]
gelnam=['F','A','S','V','G','M']

#get all pp based on zone, output from Keith's spreadsheets
pp_dict={}
lay_dict={}
pppath=os.path.join(root,'pilotpoints')
pestpath=os.path.join(root,'PEST')
if not os.path.exists(pestpath):
    os.makedirs(pestpath)
ppfiles = [f for f in os.listdir(pppath) if 'PP_zone' in f and '.xlsx' in f] #files output from Keith's workbooks
for pf in ppfiles:
    zn=int(pf[pf.index('.xlsx')-1])
    ppwb=xlrd.open_workbook(os.path.join(pppath,pf))
    ppsheet=ppwb.sheet_by_index(0)
    for r in range(ppsheet.nrows):
        if len(ppsheet.cell_value(r,1))>0 and type(ppsheet.cell_value(r,2))==float:
            ID=ppsheet.cell_value(r,1).replace('PP_',gelnam[zn-1]+'K_') #GROUPLETTER_ plus cellid in 2D
            if ID not in pp_dict:
                pp_dict[ID]={}
                pp_dict[ID]['utm']=(ppsheet.cell_value(r,2),ppsheet.cell_value(r,3))
                pp_dict[ID]['zone']=zn
                pp_dict[ID]['lay']=[]

#get zone arrays for each layer
zfiles=[os.path.join(pestpath,f) for f in os.listdir(pestpath) if '.zon' in f]
nrow=np.shape(np.loadtxt(zfiles[0]))[0]#for size only
ncol=np.shape(np.loadtxt(zfiles[0]))[1]
layzone=np.zeros((len(zfiles),nrow,ncol))
for f in zfiles:
    zn=int(f[f.index('.zon')-1])
    layzone[zn-1]=np.loadtxt(os.path.join(pppath,f))

#cellid to array index
fail=[]
for ID in pp_dict:
    cell=int(ID.split('_')[1])
    i=(cell-1)/ncol
    j=cell-i*ncol-1 #-1 for 0 indexing
    pp_dict[ID]['pos']=(i+1,j+1) #row,col
    #build list of PP and zone for each layer
    for k in range(0,len(layzone)):
        if pp_dict[ID]['zone']==layzone[k][i][j]: #PP is in zone in this layer
            pp_dict[ID]['lay'].append(k+1)
    if len(pp_dict[ID]['lay'])==0:
        fail.append(ID)
print('layer and/or zone failed to match for '+str(len(fail))+' pilot points')

# write zone list and template files
# identifier (ID) 10 characters or less
for k in range(1,len(layzone)): #no lay1, lakes only in lay1
    for d in [pestpath,pppath]: # in pestpath for fac2real, in pppath for ppk2fac
        fnam=os.path.join(d,'PP_lay'+str(k+1)+'.txt')
        with open(fnam,'w+') as f:
            for ID in pp_dict:
                if k+1 in pp_dict[ID]['lay']:
                    data=(ID,pp_dict[ID]['utm'][0],pp_dict[ID]['utm'][1],pp_dict[ID]['zone'],gelK[pp_dict[ID]['zone']-1],'\n')
                    f.write('%s  %10.4f  %10.4f  %i  %10.4f%s' %data)
    fnam=os.path.join(pestpath,'PP_lay'+str(k+1)+'.txt') #tpl only needed in pestpath
    with open(fnam+'.tpl','w+') as f:
        f.write('ptf @\n')
        for ID in pp_dict:
            if k+1 in pp_dict[ID]['lay']:
                data=(ID,pp_dict[ID]['utm'][0],pp_dict[ID]['utm'][1],pp_dict[ID]['zone'],'@'+ID+'@\n')
                f.write('%s  %10.4f  %10.4f  %i  %s' %data)
#write zone files to generate covariance matrix using PPCOV
for z in range(1,7):
    fnam=os.path.join(pppath,'PP_zone'+str(z)+'.txt')
    with open(fnam,'w+') as f:
        for ID in pp_dict:
            if z==pp_dict[ID]['zone']:
                data=(ID,pp_dict[ID]['utm'][0],pp_dict[ID]['utm'][1],pp_dict[ID]['zone'],gelK[pp_dict[ID]['zone']-1],'\n')
                f.write('%s  %10.4f  %10.4f  %i  %10.4f%s' %data)