#! Convert MODFLOW sfr file to MODSIM network
#! MS nodes defined by endpoints, links defined by segment number
#! if link already exists in cell, shift node 0.1
root=r'S:/'

import os
import numpy as np

modnam='CV-wes-94SS'
modir=os.path.join(root,r'CarsonValley\MODFLOW',modnam)

xyname=os.path.join(modir,modnam+'-MODSIM.xy')



#read segment info from sfr file
sfrname =os.path.join (modir,modnam+".sfr")
seg_dict={}
wr_dict={}
#get data set 1, nstrm, nss
with open(sfrname,"r") as sfrfile:
    for l in range(0,4): #assume nss and nstrm in 4th line of sfr file
        line=sfrfile.readline().lower()
        if 'nstrm' in line.lower() and 'nss' in line.lower():
            data=line.strip().split()
            nstrm=int(data[0])
            nss=int(data[1])
            netsegs=nss #change immediately below
            nsfrpar=int(data[2])
    while True:
        line=sfrfile.readline().lower()
        if not line: break
        if '-' in line:
            data=line.strip().split()
            if '-' in data[0]: #indicates diversion to field, distribution to finf
                netsegs=netsegs-1
# data set 2, locations of reach 1 for each segment
with open(sfrname,"r") as sfrfile:
    for l in range(0,4): #skip header, already got it above
        line=sfrfile.readline().lower()
    for rch in range(0,nstrm): #assume rch info immediately follows nstrm and nss line
        line=sfrfile.readline().lower()
        data=line.strip().split()
        row=int(data[1])
        col=int(data[2])
        seg=int(data[3])
        reach=int(data[4])
        pos=(row,col)
        if seg not in seg_dict:
            seg_dict[seg]={}
            seg_dict[seg]['ireach']={}
            seg_dict[seg]['flow']=[]
            seg_dict[seg]['name']='CV_seg_'+str(seg)
            seg_dict[seg]['desc']='seg_'+str(seg)
        seg_dict[seg]['ireach'][reach]={}
        seg_dict[seg]['ireach'][reach]['pos']=pos
    #data set 5
    line=sfrfile.readline().lower()
    data=line.strip().split()
    itmp=int(data[0]) #number of segments in ds6, includes diversion ghost segments
    #data set 6, define network connections, diversions
    for s in range(0,itmp):
        line=sfrfile.readline().lower()
        data=line.strip().split()
        seg=int(data[0])
        icalc=int(data[1])
        outseg=int(data[2])
        iupseg=int(data[3])
        flow=float(data[5])
        if seg>0: #not a field diversion
            seg_dict[seg]['flow'].append(flow) # flow for stress period
            seg_dict[seg]['iupseg']=iupseg
            seg_dict[seg]['outseg']=outseg
            if icalc==2 or icalc==1: # ICALC==1 or ==2, two lines follow... icalc other??
                for i in range(0,2):
                    line=sfrfile.readline().lower()
        else: #field diversion
            seg_dict[-seg]['iupseg']=iupseg
            seg_dict[-seg]['flow'].append(flow)
            if icalc==2 or icalc==1: # ICALC==1 or ==2, two lines follow... icalc other??
                for i in range(0,2):
                    line=sfrfile.readline().lower()
                    data=line.strip().split()
                    for d in data:
                        if 'wrid=' in d:
                            wrid=d.replace('wrid=','').replace(',','')
                        if 'priority=' in d:
                            priority=d.replace('priority=','').replace(',','')
                        if 'acres=' in d:
                            acres=int(d.replace('acres=','').replace(',',''))
            if wrid not in wr_dict:
                wr_dict[wrid]={}
                wr_dict[wrid]['seg']=-seg #ghost segment leading to field
                wr_dict[wrid]['wryr']=priority
                wr_dict[wrid]['acres']=acres
            #field diversion cells
            line=sfrfile.readline().lower()
            data=line.strip().split()
            ncells=int(data[0])
            rlist=[]
            clist=[]
            for c in range(0,ncells):
                line=sfrfile.readline().lower()
                data=line.strip().split()
                rlist.append(int(data[0]))
                clist.append(int(data[1]))
            wr_dict[wrid]['pos']=(int(round(np.mean(rlist))),int(round(np.mean(clist))))
#calculate new positions as (mean(row),mean(col))
for seg in seg_dict:
    rlist=[]
    clist=[]
    for reach in seg_dict[seg]['ireach']:
        rlist.append(seg_dict[seg]['ireach'][reach]['pos'][0])
        clist.append(seg_dict[seg]['ireach'][reach]['pos'][1])
    seg_dict[seg]['avepos']=(np.mean(rlist),np.mean(clist))
    print(rlist,clist,seg_dict[seg]['avepos'])
###find shared nodes and shift if necessary
##poslist=[seg_dict[seg]['pos'] for seg in seg_dict] #list of all positions
##for seg in seg_dict:
##    if poslist.count(seg)>1: #more than 1 seg in cell
##        for j in range(0,poslist.count(seg)):
##            seg_dict[seg]['segshare'].append(seg_dict.keys()[p])
##            seg_dict[seg]['pos']=(row+j*shift,col-j*shift) #down and left


# Demand nodes
dem=5 #acre-ft/acre per year
fracdem=[0.0,0.0,0.0,0.19,0.34,0.21,0.15,0.07,0.04,0.0,0.0,0.0] #Jan-Dec demand fractions
with open(wrname,"r") as wrfile:
    while True:
        data=wrfile.readline()
        if not data: break
        line=data.strip().split()
        if len(line)>0:
            if 'IUPSEG' in data:
                seg=line[0]
                wryr=line[2]
                acres=line[3]
                iupseg=line[4]
                wrid=line[5]
                #define demand based on acres
                anndem=numpy.multiply(dem,float(acres)) #yearly demand
                modemarr=numpy.multiply(anndem,fracdem)
                modem=numpy.array(modemarr).tolist()
                #define location based on ave of i pairs of row, col
                irows=0 #reset for each irrigation diversion
                icols=0
                irrcells=0
                data=wrfile.readline()
                line=data.strip().split()
                while '#row;' in data: #sum up all rows and cols
                    irows=irows+int(line[0])
                    icols=icols+int(line[1])
                    irrcells=irrcells+1
                    data=wrfile.readline().lower()
                    line=data.strip().split()
                airows=irows/irrcells #average rows and cols for newloc, should be int
                aicols=icols/irrcells
                #MODFLOW trick to take diversions between model boundary and USGS gage out of model
                #Must be dealt with better depending on upper WS model
                if airows<3 and aicols<3:
                    airows=202
                    aicols=40 #make new location right of WFCR node for now
                demandloc=(str(airows),str(aicols))

                # make new irrigation entries in loc_dict
                if demandloc not in loc_dict:
                    loc_dict[demandloc]={}
                    loc_dict[demandloc]['segto']=[seg]
                    loc_dict[demandloc]['segfrom']=[] #no segfrom for demand node, iupseg append to diversion node
                    loc_dict[demandloc]['segshare']=[seg]
                    loc_dict[demandloc]['ntype']='3'
                    loc_dict[demandloc]['name']='wrid_'+str(wrid)
                    loc_dict[demandloc]['desc']=acres
                    loc_dict[demandloc]['wryr']=wryr
                    loc_dict[demandloc]['demand']=modem
                    loc_dict[demandloc]['flow']=[]

                else:# cell loc exists, occupied by previous segments of various types, shift if not already irr by this seg
                    if seg not in loc_dict[demandloc]['segshare']: # change location if (irr) seg not already processed
                        loc_dict[demandloc]['segshare'].append(seg)
                        segsatloc=len(loc_dict[demandloc]['segshare'])
                        newdloc=(str(float(airows)+segsatloc*shift),str(float(aicols)-segsatloc*shift))
                        #print('sharing violation: segment ',seg,' serving irrigated parcel at ', demandloc,' shifted to ',newdloc)
                        loc_dict[newdloc]={} #add new node if irrigated by >1 seg
                        loc_dict[newdloc]['segto']=[seg]
                        loc_dict[newdloc]['segfrom']=[]
                        loc_dict[newdloc]['segshare']=[seg]
                        loc_dict[newdloc]['ntype']='3'
                        loc_dict[newdloc]['name']='wrid_'+str(wrid)
                        loc_dict[newdloc]['desc']=acres
                        loc_dict[newdloc]['wryr']=wryr
                        loc_dict[newdloc]['demand']=modem
                        loc_dict[newdloc]['flow']=[] #initialize
                for loc in loc_dict: # connect new nodes to network
                    if iupseg in loc_dict[loc]['segto'] and seg not in loc_dict[loc]['segfrom']:
                        loc_dict[loc]['segfrom'].append(seg)

# Make node_dict first level node_num (i), start at i=1 for MS
node_dict = {}
for nodenum,loc in enumerate(loc_dict,start=1):#MS nodenums positive integers
    node_dict[nodenum]={}
    node_dict[nodenum]['loc']=loc
    node_dict[nodenum]['segto']=loc_dict[loc]['segto']
    node_dict[nodenum]['segfrom']=loc_dict[loc]['segfrom']
    node_dict[nodenum]['flow']=loc_dict[loc]['flow']
    node_dict[nodenum]['ntype']=loc_dict[loc]['ntype']
    node_dict[nodenum]['fromlinks']=[] #must initialize fromlink and inlink
    node_dict[nodenum]['tolinks']=[]
    node_dict[nodenum]['name']=loc_dict[loc]['name']
    node_dict[nodenum]['desc']=loc_dict[loc]['desc']
    node_dict[nodenum]['wryr']=loc_dict[loc]['wryr']
    node_dict[nodenum]['demand']=loc_dict[loc]['demand']

# Make link_dict with first level linknum
link_dict = {}
linknum=0
for n1 in node_dict:
    for n2 in node_dict:
        for st in node_dict[n2]['segto']:
            if st in node_dict[n1]['segfrom']: # 2 nodes create link, including terminal
                linknum=linknum+1
                link_dict[linknum]={}
                link_dict[linknum]['name']=node_dict[n1]['name'] #seg name and desc by default
                link_dict[linknum]['desc']=node_dict[n1]['desc']
                link_dict[linknum]['fromnode']=n1
                link_dict[linknum]['tonode']=n2
                node_dict[n1]['fromlinks'].append(linknum)
                node_dict[n2]['tolinks'].append(linknum)
                if int(st)>nss: #diversion links
                    iupsegs=node_dict[n1]['segfrom'].remove(st)
                    link_dict[linknum]['name']='UC_seg_'+str(st) #change name and desc if diversion
                    link_dict[linknum]['desc']='div_from_seg_'+node_dict[n1]['segfrom'][0]+'_to_'+node_dict[n2]['segfrom'][0]
                if networksegs<int(st)<=nss: #irrigation links
                    link_dict[linknum]['name']=node_dict[n2]['name'] #change name and desc if irrigation
                    link_dict[linknum]['desc']=node_dict[n2]['desc']
                    link_dict[linknum]['wryr']=node_dict[n2]['wryr']

##with open(path+'\\wrid_iupseg.txt',"w") as wrid_file:
##    for i in node_dict:
##        if 'wrid_' in node_dict[i]['name']:
##            for j in range(0,len(node_dict[i]['segto'])):
##                name=node_dict[i]['name'].strip('wrid_')
##                iupseg=node_dict[i]['segto'][j]
##                wrid_file.write(str(name)+','+str(iupseg)+'\n')
# #################################################################
scale=25
xmin=0
ymin=0
xmax=2000
ymax=2000
accuracy=2

# Write header at position 0
header='''xyVersion 8.4.0
n_links ''' + str(len(link_dict)) + '''
n_nodes ''' + str(len(node_dict)) + '''
n_lags 5
ExtManualStorageRightActive False
ExtStorageRightActive False
ExtWaterRightsActive True
ExtLastFillRentActive False
NonstorageNodeSize 100
DemandNodeSize 100
ReservoirNodeSize 100
LinkSize 100
BackgroundImageLocation
BackgroundImageSize 0
WRInitialPriority -10000
DefaultFlowUnits acre-ft/month
DefaultStorageUnits acre-ft\n'''
with open(xyname,"w") as xyfile:
    xyfile.seek(0,0)
    xyfile.write(header)
    header_end=xyfile.tell()

# write node data at header_end position
with open(xyname,"a") as xyfile:
    xyfile.seek(header_end,0)
    for nodenum in (node_dict):# write node block
        xyfile.write('node\n')
        xyfile.write('name '+ str(node_dict[nodenum]['name']) +'\n')
        xyfile.write('desc '+ str(node_dict[nodenum]['desc']) +'\n')
        xyfile.write('num '+ str(nodenum) +'\n')
        xyfile.write('ntype '+ str(node_dict[nodenum]['ntype'])+'\n')
        for in_num in range(0,len(node_dict[nodenum]['tolinks'])): #write in links
            xyfile.write('in '+ str(node_dict[nodenum]['tolinks'][in_num]) + '\n')
        for out_num in range(0,len(node_dict[nodenum]['fromlinks'])): #write out links
            xyfile.write('out '+ str(node_dict[nodenum]['fromlinks'][out_num]) + '\n')
        try: #west fork flow
            if node_dict[nodenum]['name']=='UC_seg_1':
                xyfile.write('tsinflow\nvariesbyyear True\n')
                for i, flow in enumerate(node_dict[nodenum]['flow']):
                    yr=1970+(i+3)/4 # water year
                    quart=[10,1,4,7] #quarterly stress periods from Yager
                    month=quart[int(math.fmod(i,4))]
                    xyfile.write(str(month)+'''/01/'''+str(yr)+''' 00:00:00  '''+str(numpy.multiply(flow,10**accuracy))+'''\n''')
        except: pass

        try: #east fork flow
            if node_dict[nodenum]['name']=='UC_seg_44':
                xyfile.write('tsinflow\nvariesbyyear True\n')
                for i, flow in enumerate(node_dict[nodenum]['flow']):
                        yr=1970+(i+3)/4 # water year
                        quart=[10,1,4,7] #quarterly stress periods from Yager
                        month=quart[int(math.fmod(i,4))]
                        xyfile.write(str(month)+'''/01/'''+str(yr)+''' 00:00:00  '''+str(numpy.multiply(flow,10**accuracy))+'''\n''')
        except: pass

        try: #indian creek flow
            if node_dict[nodenum]['name']=='UC_seg_103':
                xyfile.write('tsinflow\nvariesbyyear True\n')
                for i, flow in enumerate(node_dict[nodenum]['flow']):
                    yr=1970+(i+3)/4 # water year
                    quart=[10,1,4,7] #quarterly stress periods from Yager
                    month=quart[int(math.fmod(i,4))]
                    xyfile.write(str(month)+'''/01/'''+str(yr)+''' 00:00:00  '''+str(numpy.multiply(flow,10**accuracy))+'''\n''')
        except: pass
        xyfile.write('pos\n')
        xyfile.write('0 '+ str(numpy.multiply(scale,float(node_dict[nodenum]['loc'][1]))) +'\n')
        xyfile.write('1 '+ str(numpy.multiply(scale,float(node_dict[nodenum]['loc'][0]))) +'\n')
        xyfile.write('labelpos\n')
        xyfile.write('0 '+ str(numpy.multiply(scale,float(node_dict[nodenum]['loc'][1]))) +'\n')
        xyfile.write('1 '+ str(numpy.multiply(scale,float(node_dict[nodenum]['loc'][0]))) +'\n')
        if len(node_dict[nodenum]['demand'])>1: #monthly demand
            xyfile.write('pcapUnits acre-ft/month\n')
            xyfile.write('tsdemand\n')
            xyfile.write('multicolumn True\n')
            xyfile.write('units acre-ft/month\n')
            for month,dem in enumerate(node_dict[nodenum]['demand'],start=1):
                xyfile.write(str(month)+'/01/1970  00:00:00  '+str(numpy.multiply(dem,10**accuracy))+'  '+str(numpy.multiply(dem,10**accuracy))+'  '+str(numpy.multiply(dem,10**accuracy))+'\n')
    ##        xyfile.write('tsinfiltration\n')
    ##        xyfile.write('10/01/1970    00:00:00     0.3000\n')
    node_end=xyfile.tell()

# write link data at node_end position
# MS link name is MF segment
# cost to be determined through WR extension in GUI
with open(xyname,"a") as xyfile:
    xyfile.seek(node_end,0)
    for linknum in link_dict:
        xyfile.write('''link
lname '''+str(link_dict[linknum]['name'])+'''
ldescription '''+str(link_dict[linknum]['desc'])+'''
lnum '''+str(linknum)+'\n')
        try:
            xyfile.write('fromnum '+str(link_dict[linknum]['fromnode'])+'\n')
        except: pass
        try:
            xyfile.write('tonum '+str(link_dict[linknum]['tonode'])+'\n')
        except: pass
        try:
            xyfile.write('WaterRightDate 01/01/'+link_dict[linknum]['wryr']+' 00:00:00 \n')
        except: pass

# write footer data at  end of file
footer='''ially 0 # Conditional_Rules
iplot 1
iprd Monthly
iut 0
n_years 12
rdim
0 '''+str(numpy.multiply(scale,xmin))+'''
1 '''+str(numpy.multiply(scale,ymin))+'''
2 '''+str(numpy.multiply(scale,xmax))+'''
3 '''+str(numpy.multiply(scale,ymax))+'''
title '''+modnam+'''
uselags 1
maxit 100
gw_cp 0
flowth_cp 0
infeasrestart 0
relxacrul 0
dataStartDate 10/01/1970 00:00:00
dataEndDate 10/01/2005 00:00:00
startingDate 10/01/1970 00:00:00
endingDate 10/01/2005 00:00:00
accrualDate 01/01/1900 00:00:00
seasCapDate 01/01/1900 00:00:00
accuracy '''+str(accuracy)+'''
defaultMaxCap 9999999999
res_output -1
dws_rel -1
elev_end -1
evp_loss -1
evp_rate -1
gwater -1
head_avg -1
hydra_Cap -1
powr_avg -1
powr_pk -1
pump_in -1
pump_out -1
pwr_2nd -1
seepage -1
spills -1
stor_beg -1
stor_end -1
stor_trg -1
unreg_in -1
ups_rel -1
dem_output -1
dem_sht -1
demand -1
gw_in -1
surf_in -1
acc_flow -1
acc_output -1
acrl -1
stgl -1
flo_flow -1
flo_output -1
loss -1
natflow -1
fromgwtono -1
gw_output -1
noTimeStepsInMemorygwinfiltra -1
spcl_rpts 0
part_flows 0
ver7OutputFiles 0
ver8MSDBOutputFiles -1
DeleteTempVer8OutputFiles -1
noTimeStepsInMemory 12
hydroStateOUT -1
nonStorage_output -1
l_MaxOUT -1
l_MinOUT -1
Flow_ThruOUT -1
Rout_RetOUT -1
InflowOUT -1
nomaxmesg 0
constsysst 0
IsBackRoutingActive 0
IsStorageAccountWithRouting 0'''
xyfile= open(xyname,"a")
xyfile.seek(0,2)
xyfile.write(footer)
xyfile.close()