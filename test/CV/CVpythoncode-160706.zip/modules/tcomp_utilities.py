#create stratigraphy based on model layers
#zone is a (nlay,nrow,ncol) array
#Lbot is a (nlay+1,nrow,ncol) array

import numpy as np

tcomplogs=r'S:\CarsonValley\MODFLOW\CV-wes-9094SS\PEST\tcomp\model_logs.txt'
modprops=r'S:\CarsonValley\MODFLOW\CV-wes-9094SS\PEST\tcomp\model_hyd_props.txt'
tcompscr=r'S:\CarsonValley\MODFLOW\CV-wes-9094SS\PEST\tcomp\model_scr.txt'
tcomplsa=r'S:\CarsonValley\MODFLOW\CV-wes-9094SS\PEST\tcomp\model_lsa.txt'
def mod2logs(dic,zone,Lbot,gelK,gelkey):
    for ID in dic:
        dic[ID]['log']=[]
        i=dic[ID]['pos'][0]
        j=dic[ID]['pos'][1]
        dic[ID]['name']='wl_'+str(ID)
        for k in range(1,len(Lbot)):
            d=Lbot[0][i][j]-Lbot[k][i][j] #surface - top of next layer
            if d==0: #first entry, top layer, depth=0
                geoldex=int(zone[k][i][j])-1 #geology of next layer
                dic[ID]['log']=[(d,gelkey[geoldex])]
            elif k==len(Lbot)-1: #last entry, depth=max
                geoldex=int(zone[k-1][i][j])-1 #geology of previous layer
                dic[ID]['log'].append((d,gelkey[geoldex]))
            else:
                geoldex=int(zone[k-1][i][j])-1
                dic[ID]['log'].append((d,gelkey[geoldex]))

mod2logs(trans_dict,zone,Lbot,gelK,gelkey)

translist=sorted(trans_dict.keys())
with open(tcomplogs,'w+') as flog:
    for ID in translist:
        for data in trans_dict[ID]['log']:
            flog.write('%10s %10i %5s\n' %(trans_dict[ID]['name'],data[0],data[1]))
with open(tcompscr,'w+') as fscr:
    for ID in translist:
        i=trans_dict[ID]['pos'][0]-1
        j=trans_dict[ID]['pos'][1]-1
        z1=Lbot[0][i][j]-trans_dict[ID]['scrint'][0]
        z2=Lbot[0][i][j]-trans_dict[ID]['scrint'][1]
        fscr.write('%10s %10s %10s %5i\n' %(str(ID),trans_dict[ID]['name'],trans_dict[ID]['name'],z1))
        fscr.write('%10s %10s %10s %5i\n' %(str(ID),trans_dict[ID]['name'],trans_dict[ID]['name'],z2))
with open(tcomplsa,'w+') as flsa:
    for ID in translist:
        i=trans_dict[ID]['pos'][0]-1
        j=trans_dict[ID]['pos'][1]-1
        lsa=Lbot[0][i][j]
        flsa.write('%10s %10.4f\n' %(trans_dict[ID]['name'],lsa))
with open(modprops,'w+') as fprops:
    for i,g in enumerate(gelkey):
        fprops.write('%10s %10.4f %4.3f %10.9f %4.2f\n' %(g,gelK[i],Sy[i],Sstorage[i],1.0))