#-------------------------------------------------------------------------------
# Name:        gridarrays
# Purpose:
#
# Author:      wkitlasten
#
# Created:     29/12/2015
# Copyright:   (c) wkitlasten 2015
# Licence:     <your licence>
#-------------------------------------------------------------------------------

def gridarrays():
    Lbot=np.zeros((nsublay+Llak+1,nrow,ncol)) #nsublay+Llak+1 surfaces for nsublay layers, bottom alt for layer
    ib=np.zeros((nsublay+Llak,nrow,ncol))
    zone=np.zeros((nsublay+Llak,nrow,ncol))
    LHK=np.zeros((nsublay+Llak,nrow,ncol))
    WHSF=np.zeros((nrow,ncol))