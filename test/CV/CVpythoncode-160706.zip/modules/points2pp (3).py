# write data from dic to tab delim file to import into Keith's PP

import os
import numpy as np

root=r'D:/'
pppath=os.path.join(root,r'CarsonValley\MODFLOW\CV-wes-1991ss-151228\pilotpoints')
if not os.path.exists(pppath):
    os.makedirs(pppath)

def obs2pp(dics,sp=[],zn=6):
    data={} #dict of data for each dic entry
    for dic in dics:
        for ID in dic:
            if 'date' in dic[ID]: #hobs have dates, aqtests don't
                for d in dic[ID]['date']:
                    if len(sp)==0 or d>=sp[0] and d<sp[-1]: #base pp on all records [len(sp)==0] or duration of simulation
                        if ID not in data:
                            if 'zone' in dic[ID]:
                                data[ID]=(str(dic[ID]['USGSsite']),str(ID),dic[ID]['utm'][0],dic[ID]['utm'][1],dic[ID]['zone'],'\n')
                            else:
                                print('no zone data for '+str(ID))
            else: #aqtests keep in zone 2 for now (alluv) and surface obs should always be in top layer (not Llak)
                if ID not in data:
                    if 'gage' in dic[ID]: #stream gage
                        data[ID]=(str(dic[ID]['gage']),str(ID),dic[ID]['utm'][0],dic[ID]['utm'][1],dic[ID]['zone'],'\n')
                    else:
                        data[ID]=(str(dic[ID]['wellnum']),str(ID),dic[ID]['utm'][0],dic[ID]['utm'][1],dic[ID]['zone'],'\n')
    print(zn)
    for z in range(1,(zn+1)):
        print('Obs points for zone '+str(z))
        hobout=os.path.join(pppath,'hob_data_zone_'+str(z)+'.txt')
        with open (hobout,'w+') as hf:
            header=('USGS_site','site_name','UTMx','UTMy','zone\n')
            hf.write('%20s %12s %12s %12s %5s' %header)
            for ID in data:
                if data[ID][4]==z:
                    hf.write('%20s %12s %12.2f %12.2f %5i %s' %data[ID])

def cell2pp(cell,cellid):
    gridout=os.path.join(pppath,'grid_data.txt')
    with open(gridout,'w+') as cf:
        data=('cell_ID','cell_UTMx','cell_UTMy\n')
        cf.write('%10s %12s %12s' %data)
        for ID in cell:
            pos=np.where(cellid==ID)
            r=int(pos[0]+1)
            c=int(pos[1]+1)
            data=(ID,cell[ID][0],cell[ID][1],r,c,'\n')
            cf.write('%10i %12.2f %12.2f %5s %5s %s' %data)