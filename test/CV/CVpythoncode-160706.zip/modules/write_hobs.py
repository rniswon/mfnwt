#the following writes the hob file and PEST instruction file for reading hobs

###get total number of head observations
##print('determining number of head observations\n')
##tnobs=0
##for ID in hob_dict:
##    hob_dict[ID]['obsdate']=[]
##    for per in period:
##        obsdate=[]
##        if per==period[0]: # steady state
##            hoblist=[h for d,h in zip(hob_dict[ID]['date'],hob_dict[ID]['hobalt']) if per[0]<d<=per[1] and 'lay' in hob_dict[ID]]
##            if len(hoblist)>0:
##                obsdate.append(per[1]) #end of SS
##                hob_dict[ID]['hobss']=np.mean(hoblist) #mean value for SS
##                hob_dict[ID]['acyss']=np.std(hoblist)
##        else: # multiple hob for each location during a given stress period
##            for d in hob_dict[ID]['date']:
##                if per[0]<d<=per[1] and 'lay' in hob_dict[ID]:
##                    obsdate.append(d)
##        hob_dict[ID]['obsdate']=hob_dict[ID]['obsdate']+obsdate
##    tnobs=tnobs+len(hob_dict[ID]['obsdate'])
##
###write .hob file
##print('writing hob file\n')
##with open (modir+'\\'+modnam+'.hob','w+') as hobfile:
##    hobfile.write('# HOB file generated for Carson Valley model - wk\n')
##    ds1=(tnobs,0,0,24,-999)
##    #ds1com=('    #Data Set 1: NH, MOBS, MAXM, IUHOBSV, HOBDRY\n')
##    hobfile.write('%i %i %i %i %i\n' %ds1)
##    #hobfile.write(ds1com)
##    ds2=(1)
##    #ds2com=('    #Data Set 2: TOMULTH\n')
##    hobfile.write('%i\n' %ds2)
##    #hobfile.write(ds2com)
##    for ID in hob_dict:
##        obsdate=hob_dict[ID]['obsdate']
##        if len(obsdate)>0 and 'lay' in hob_dict[ID]:
##            r=hob_dict[ID]['pos'][0]
##            c=hob_dict[ID]['pos'][1]
##            ds3=(ID,hob_dict[ID]['lay'],r,c,-(len(obsdate)),0,0,0,0) #toffset,roff,coff,hobs ignored if irefsp (-), see ds6
##            #ds3com=('    #Data Set 3: OBSNAM,LAYER,ROW,COL,IREFSP,TOFFSET,ROFF,COFF,HOBS\n')
##            hobfile.write('%s %i %i %i %i %i %i %i %i\n' %ds3)
##            #hobfile.write(ds3com)
##            hobfile.write('1\n')    #Data Set 5: ITT\n')
##            for i,d in enumerate(obsdate):
##                for per in period:
##                    if per[0]<d<=per[1]:
##                        if per==period[0] and 'hobss' in hob_dict[ID]: #steady state
##                            hob=hob_dict[ID]['hobss']
##                            acy=hob_dict[ID]['acyss']
##                            d8=str(d.year) #only use year in name
##                            irefsp=1
##                            toffset=0 #irefsp=1, toffset=0
##                        else:
##                            hdex=hob_dict[ID]['date'].index(d)
##                            hob=hob_dict[ID]['hobalt'][hdex]
##                            acy=hob_dict[ID]['acy'][i]
##                            d8=hob_dict[ID]['date'] #else use actual date
##                            irefsp=sp.index(per[0])
##                            toffset=d-(per[0]) #days from beginning of period per
##                            toffset=toffset.days
##                        obsnam=str(ID).translate(None,'ob_')+'_'+str(d8).translate(None,'-')
##                        ds6=(obsnam,irefsp,toffset,hob,acy,0,1,1)
##                        #ds6com=('    #Data Set 6: OBSNAM,IREFSP,TOFFSET,HOBS,STATh,STATdd,STAT-FLAG,PLOT-SYMBOL\n')
##                        hobfile.write('%s %i %i %10.4f %10.4f %i %i %i\n' %ds6)
##                        #hobfile.write(ds6com)


###write hob instruction file
##with open (os.path.join(pestpath,modnam+'.hobs.ins'),'w+') as hobins:
##    hobins.write('pif @\n@NAME@\n')
##    for ID in hob_dict:
##        obsdate=hob_dict[ID]['obsdate']
##        for i,d in enumerate(obsdate):
##            if 'hobss' in hob_dict[ID]: #steady state, only use year
##                d8=d.year
##            else: #use actual date
##                d8=d
##            obsnam=str(ID).translate(None,'ob_')+'_'+str(d8).translate(None,'-')
##            hobins.write('l1 ['+obsnam+']1:21\n')