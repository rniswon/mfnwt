import numpy as np
import datetime

#sort data
def periodsort(dic,period,datekey='date',flowkey='flow'):
    '''sort date and flow data by period
    first two dates (0,1) are steady state (period 1)'''
    for fid in dic:
        dsort=[]
        for i,per in enumerate(period):
            datelist=[]
            flow=[]
            for d,f in zip(dic[fid][datekey],dic[fid][flowkey]):
                if per[0]<=d<=per[1] and d not in dsort:
                    datelist.append(d)
                    flow.append(f)
            if i==0: #steady state average
                ssflow=np.mean(flow)
                datelist=[sp[0],sp[1]]
            persort=sorted(datelist)
            dsort=dsort+persort
        fsort=[]
        for d in dsort:
            if d==sp[0] or d==sp[1]:
                fsort.append(ssflow)
            else:
                sdex=dic[fid][datekey].index(d)
                fsort.append(dic[fid][flowkey][sdex]) #in cfd
        dic[fid]['sortdate']=dsort
        dic[fid]['sortflow']=fsort

#get simulation days based on periods
def simdays(dic,period,datekey='date'):
    for fid in dic:
        dic[fid]['simday']=[]
        for i,per in enumerate(period):
            if i==0:
                dic[fid]['simday']=[0,1]
                perlen=[2]
            else:
                dlist=[d for d in dic[fid][datekey] if per[0]<=d<=per[1]]
                for date in dlist:
                    if per[0]<=date<=per[1]:
                        day=(date-per[0]).days+np.sum(perlen)+tinterval[i].days-1 # perlen calculated after
                        dic[fid]['simday'].append(int(day))
                perlen.append((per[1]-per[0]).days)