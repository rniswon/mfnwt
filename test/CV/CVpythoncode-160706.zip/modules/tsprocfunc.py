# write a flow dictionary to TSPROC "site sample file" format
# include comments for regressed, interpolated, monthly mean, etc
import os

def dic2ssf(dic,tsdir,flowkey='flow',datekey='date',suffix=''):
    for site in dic:
        if flowkey in dic[site] and datekey in dic[site]:
            with open(os.path.join(tsdir,site+str(suffix)+'.tspssf'),'w+') as tsfile:
                tsfile.write('# Flow record for %s for use in TSPROC\n' %dic[site]['name'])
                tsfile.write('# date format is dd/mm/yyyy\n')
                if 'fcomment' in dic[site]:
                    tsfile.write('# %s\n' %dic[site]['fcomment'])
                for i in range(0,len(dic[site][datekey])):
                    if 'rcomment' in dic[site] and len(dic[site]['rcomment'])==len(dic[site][flowkey]) and dic[site]['rcomment']!='': #if comment exists, should be same size as date and flow
                        tsfile.write('# %s applies to the following line\n' %dic[site]['rcomment'][i])
                    d8=str(dic[site][datekey][i].day)+'/'+str(dic[site][datekey][i].month)+'/'+str(dic[site][datekey][i].year)
                    data=(site,d8,'12:00:00',dic[site][flowkey][i],'\n')
                    tsfile.write('%s     %10s %10s  %10.4f  %s' %data)
        else:
            print('no flowkey={0} or datekey={1} in dictionary {2}'.format(flowkey,datekey,site))