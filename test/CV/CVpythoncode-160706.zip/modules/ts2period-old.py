#sort data based on periods
def ts2period(dic,period,datekey='date',flowkey='flow'):
    '''sort date and flow data by period
    first two dates period[0][0:1] are steady state'''
    print('sorting based on periods\n')
    for fid in dic:
        dates=[]
        for per in period:
            datelist=[]
            for d,f in zip(dic[fid][datekey],dic[fid][flowkey]):
                if per[0]<=d<=per[1] and d not in dates:
                    datelist.append(d)
            persort=sorted(datelist)
            dates=dates+persort
        #get flows based on dates
        print('calculating period averages\n')
        for d in dates:
            if sp[0]<=d<=sp[1]: #steady state
                cumflow=[]
                if len([f for d,f in zip(dic[fid][datekey],dic[fid][flowkey]) if sp[0]<d<=sp[1]])<2: #not enough data for annual average, use sp[1] to sp[1]+tinterval[0]
                    t1=sp[1] #use data from following tinterval[0] days
                    t2=sp[1]+tinterval[0]
                else:
                    t1=sp[0]
                    t2=sp[1]
                for k in range(0,len(dic[fid][flowkey])-1):
                    if t1<dic[fid][datekey][k]<=t2:
                        cumflow.append(np.mean([dic[fid][flowkey][k+1],dic[fid][flowkey][k]])*(dic[fid][datekey][k+1]-dic[fid][datekey][k]).days)
                ssflow=np.sum(cumflow)/(t2-t1).days
                fsort=[ssflow,ssflow]
                dsort=[sp[0],sp[1]]
            else:
                sdex=dic[fid][datekey].index(d)
                fsort.append(dic[fid][flowkey][sdex])
                dsort.append(d)
        dic[fid]['sortdate']=dsort
        dic[fid]['sortflow']=fsort