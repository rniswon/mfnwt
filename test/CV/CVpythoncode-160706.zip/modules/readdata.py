# read in streamflow values from text files contained in folder
import os
import datetime

def readstreamtxt(streamdir,sitelist=[]):
    if sitelist==[]:
        for s in os.listdir(streamdir):
            site=s.split()[0] #assumes site number is first entry in file name
            if site!='CV':
                sitelist.append(site)
    dic={}
    for f in os.listdir(streamdir):
        for site in sitelist:
            if site not in dic and site in f:
                dic[site]={}
                dic[site]['name']=f.replace(site,'').replace('.txt','').strip()
                dic[site]['flow']=[]
                dic[site]['date']=[]
                with open(os.path.join(streamdir,f),'r') as obsf:
                    while True:
                        line=obsf.readline() #get current line
                        data=line.strip().split('\t') #split line into string
                        if not line: break #stop if there is not line
                        if 'measurement_dt' in data: #field data
                            ddex=data.index('measurement_dt')
                            fdex=data.index('discharge_va')
                        elif 'datetime' in data: #standard data
                            ddex=data.index('datetime')
                            fdex=ddex+1
                        elif 'peak_dt' in data: #standard data
                            ddex=data.index('peak_dt')
                            fdex=ddex+2 #+1 is time, +12 is flow value
                            dic[site]['fcomment']='Peak flow records'
                        if '#' not in data and site in data and len(data)>=4: #skips missing values
                            if float(data[fdex])>0: #only read date if value exists
                                if '-' in data[ddex]: #year-month-day time
                                    d8=data[ddex].split('-')
                                    yr=d8[0]
                                    mo=d8[1]
                                    day=d8[2].split(' ')[0]
                                elif '\\' in data[ddex]:
                                    d8=data[ddex].split('\\')
                                    mo=d8[0]
                                    day=d8[1]
                                    yr=d8[2].split(' ')[0]
                                if mo=='00' and day=='00': #used for peak flows meaning no flow that year
                                    date=datetime.date(int(yr)-1,10,01) #first day of water year
                                    dic[site]['date'].append(date)
                                    dic[site]['flow'].append(float(data[fdex])*86400) #convert from cfs to cfd
                                    date=datetime.date(int(yr),9,30) #last day of water year
                                    dic[site]['date'].append(date)
                                    dic[site]['flow'].append(float(data[fdex])*86400) #convert from cfs to cfd
                                else:
                                    date=datetime.date(int(yr),int(mo),int(day))
                                    dic[site]['flow'].append(float(data[fdex])*86400) #convert from cfs to cfd
                                    dic[site]['date'].append(date)

    return(dic)