# Make control file from pilot point tpl files, hob file, etc

root=r'S:\CarsonValley'

import os,xlrd,datetime,sys
import numpy as np
if 'modules' not in sys.path:
    sys.path.append(os.path.join(root,r'wespythoncode\modules'))
import readdata as rd
import tsfunc as ts

modnam='CV-wes-9094SS'
modir=os.path.join(root,'MODFLOW',modnam)
pestdir=os.path.join(modir,'PEST')
obsdir = os.path.join(root,r'flows\carsonstreamflow\obs')
outdir=os.path.join(modir,'output')
if not os.path.exists(pestdir):
    os.makedirs(pestdir)

# Stress period information
if 'SS' in modnam:
    period=[(datetime.date(1989,10,1),datetime.date(1994,9,30))]
    tinterval=[period[0][1]-period[0][0]]
elif 'historical' in modnam:
    if 'short' in modnam:
        # stress period information for historicalshort
        period=[(datetime.date(1998,10,1),datetime.date(1999,9,30)),
                (datetime.date(1999,10,1),datetime.date(2013,10,1))]
        tinterval=[period[0][1]-period[0][0],
                    datetime.timedelta(days=7)]
    else:
        # stress period information for historical
        period=[(datetime.date(1985,10,1),datetime.date(1986,9,30)),
                (datetime.date(1986,10,1),datetime.date(2015,10,1))]
        tinterval=[period[0][1]-period[0][0],
                    datetime.timedelta(days=7)]
elif 'drought' in modnam:
    # Stress period information for megadrought, build tabfiles for PRMS or data driven
    period=[(datetime.date(2010,10,1),datetime.date(2011,9,30)),
            (datetime.date(2011,10,1),datetime.date(2015,10,1)),
            (datetime.date(1986,10,1),datetime.date(1995,10,1))]
    tinterval=[period[0][1]-period[0][0],
                datetime.timedelta(days=7),
                datetime.timedelta(days=7)]
nsp=[]
for per in range(0,len(period)):
    nsp.append((period[per][1]-period[per][0]).days/tinterval[per].days)
sp=[]#period[0][0]] #first date is start of steady state, index 0
for per in range(0,len(period)):
    for dt in range(0,nsp[per]+1):
        sp.append(period[per][0]+datetime.timedelta(days=(dt)*tinterval[per].days))
print('start date: '+str(sp[0])+
    '\nend date: '+str(sp[-1]))
steadyper=period[0][1]-period[0][0]
print('\nsteady-state stress period of: '+str(steadyper.days)+' days'+
    '\nfrom: '+str(sp[0])+' to '+str(sp[1]))
for per in range(0,len(period)):
    print('\nperiod '+str(per+1)+':\n'+str(period[per][0])+' to '+str(period[per][1])+'\n    '+str(nsp[per])+' stress priods of: '+str(tinterval[per].days)+' days\n')
sys.stdout.flush()

par_dict={}

obslist=['1030909020',
'1030909042',
'1030909046',
'1030909048',
'1030909055',
'1030909060',
'1030909070',
'1030909075',
'1030909080',
'1030909085',
'1030909095',
'1030909710',
'10309110',
'10309113',
'10309117',
'10311000',
'10309010',
'10309030',
'10309035',
'10309050',
'10309070',
'10309100',
'10310355',
'10310358',
'10310402',
'10310403',
'10310407',
'10310447',
'10310448']

#read stream data for obslist
print('reading stream observations\n')
#flob_dict=rd.readstreamtxt(os.path.join(obsdir,'DATA'),obslist)
#convert to period timeseries
print('converting stream observations to periods\n')
#ts.ts2period(flob_dict,sp,period)
#ts.dic2ssf(flob_dict,os.path.join(obsdir,'TSPROC',modnam+'.ssf'),flowkey='sortflow',datekey='sortdate')

# write flow instruction files
for ID in flob_dict: #new ins file for each site. Should update to read from TSPROC?
    with open (os.path.join(pestdir,modnam+'-'+str(ID)+'.sgag.ins'),'w+') as flowins:
        flowins.write('pif @\n@Flow@\n')
        for d in flob_dict[ID]['sortdate']:
            if d!=sp[0]:
                #obsnam=ID+'_'+str(d).translate(None,'-')
                flowins.write('l1 ['+ID+']37:51\n')

#check for div_dict
try:
    if type(div_dict) is dict:
        pass #div_dict already in memory from FWM2tab-moave-periods.py
except:
    print('run FWM2tab-moave-periods.py first')
#write diversion instruction files
for div in div_dict:
    if 'ip-3' not in div:
        with open (os.path.join(pestdir,modnam+'-'+str(div_dict[div]['site'])+'.sgag.ins'),'w+') as divins:
            divins.write('pif @\n@Flow@\n')
            for d in div_dict[div]['sortdate']:
                if d!=sp[0]:
                    #obsnam=ID+'_'+str(d).translate(None,'-')
                    divins.write('l1 ['+div_dict[div]['site']+']53:67\n')


# read parameters from og file using tpl file
for filename in os.listdir(pestdir):
    if '.tpl' in filename:
        with open(os.path.join(pestdir,filename),'r') as tpl:  #open the template file to be read
            lines=tpl.readlines()
        for i,line in enumerate(lines):
            if 'ptf' not in line: #skip first line
                if '@' in line: #convention: pilot points=AK_###; BCname=otherwise
                    lnum=i
                    atdex=line.index('@')+1
                    subline=line[atdex:-1]
                    satdex=subline.index('@')
                    pname=subline[0:satdex].strip()
                    initfile=filename.replace('.tpl','')
                    if 'K_' in pname or 'VA_' in pname: #pilot point, get UTMs
                        if pname not in par_dict:
                            par_dict[pname]={}
                        par_dict[pname]['pargroup']=pname.split('_')[0] #group name is last character
                        # get initial values on line lnum-1 of parameter file, accounts for 'ptf @' line
                        with open(os.path.join(pestdir,initfile),'r') as finit:  #open corresponding file w initial values
                            initline=finit.readlines()[lnum-1]
                            data=initline.strip().split()
                            par_dict[pname]['initval'] = float(data[4])
                            par_dict[pname]['UTM']=(float(data[1]),float(data[2]))
                    else:
                        if pname not in par_dict:
                            par_dict[pname]={}
                        if 'mean' in pname:
                            par_dict[pname]['pargroup']='meanK'
                        elif 'Q' in pname or 'finf' in pname or 'pET' in pname:
                            par_dict[pname]['pargroup']='BC'

                        else:
                            par_dict[pname]['pargroup']='otherK'
                        #assume initial values with input files in modir
                        with open(os.path.join(modir,initfile),'r') as finit:  #open corresponding file w initial values
                            initline=finit.readlines()[lnum-1]
                        if 'ANI' in pname:
                            par_dict[pname]['initval'] = 1.0
                        else:
                            par_dict[pname]['initval'] = float(initline[atdex-1:].strip().split()[0])
# get list of parameter groups
pglist=[]
for p in par_dict:
    if par_dict[p]['pargroup'] not in pglist:
        pglist.append(par_dict[p]['pargroup'])
pglist.sort()
pglist.append(pglist.pop(pglist.index('otherK'))) #move 'otherK' to end
pglist.append(pglist.pop(pglist.index('BC'))) #move 'BC' to end
# order parameters in list by group
parlist=[]
for pg in pglist:
    temp=[par for par in par_dict if par_dict[par]['pargroup']==pg]
    parlist=parlist+sorted(temp)

###Find nearest points
##nearpts=-1 #any number other than 1 requires reformulation of covariance matrices
##for pg in pglist:
##    if 'BC' not in pg:
##        temp=[]
##        for pname in par_dict:
##            if 'K_' in pname: # K pilot points only
##                if par_dict[pname]['pargroup']==pg: #all params in that group
##                    temp.append(pname)
##        for t1 in temp:
##            par_dict[t1]['ndist']=[]
##            par_dict[t1]['nearest']=[]
##            for t2 in temp:
##                if t1!=t2:
##                    x1=par_dict[t1]['UTM'][0]
##                    y1=par_dict[t1]['UTM'][1]
##                    x2=par_dict[t2]['UTM'][0]
##                    y2=par_dict[t2]['UTM'][1]
##                    dist=np.sqrt((x2-x1)**2+(y2-y1)**2)
##                    if len(par_dict[t1]['ndist'])<nearpts and len(par_dict[t1]['nearest'])<nearpts:
##                        par_dict[t1]['ndist'].append(dist)
##                        par_dict[t1]['nearest'].append(t2)
##                    elif dist<np.max(par_dict[t1]['ndist']):
##                        ndex=par_dict[t1]['ndist'].index(np.max(par_dict[t1]['ndist']))
##                        par_dict[t1]['ndist'].pop(ndex)
##                        par_dict[t1]['nearest'].pop(ndex)
##                        par_dict[t1]['ndist'].append(dist)
##                        par_dict[t1]['nearest'].append(t2)
###make tuples for regularisation equations of nearest points
##uneq=[]
##keepdup=True
##for par in par_dict:
##    if 'K_' in par:
##        for near in par_dict[par]['nearest']:
##            dum=sorted([par,near])
##            tup=(dum[0],dum[1]) #min of pair first
##            if keepdup:
##                uneq.append(tup)
##            elif tup not in uneq:
##                uneq.append(tup)
##uneq.sort()


#prior information groups and nprior
##priorgp=[]
##nprior=0
##for pname in par_dict:
##    if 'K_' in pname:
##        gp=pname.split('_')[0]
##    else:
##        gp='BC'
##    if 'regul_'+gp not in priorgp:
##        priorgp.append('regul_'+gp)
##bceq=[p for p in par_dict if 'K_' not in p]


# read observations from mod2obs file and create head obs dictionary
print('getting head observations from obs2obs\n')
if type(hob_dict) is not dict:
    hob_dict={}
for filename in os.listdir(pestdir):
    if 'headobs' in filename:
        with open(os.path.join(pestdir,filename),'r') as fhead:
            while True:
                line=fhead.readline() #get current line
                data=line.strip().split() #split line into list of strings
                if not line:
                    break #stop if there is not line
                data=line.strip().split() #split line into list of strings
                if data[0] not in hob_dict:
                    print('adding hob: '+data[0]+'\n')
                    hob_dict[data[0]]={}
                    hob_dict[data[0]]['hobalt']=float(data[3]) #fill head obs dictionary with obs name as key and obs data as value
                    hob_dict[data[0]]['hobss']=float(data[3])
                    hob_dict[hob]['hobstd']=5.0 #default value, sketchy
                if 'hobstd' not in hob_dict[data[0]] or 'hobss' not in hob_dict[data[0]]:
                    hob_dict[data[0]]['hobstd']=5.0 #default value, sketchy
                    hob_dict[data[0]]['hobss']=float(data[3])
for hob in hob_dict:
    if 'hdif' in hob:
        hob_dict[hob]['group']='hdif'
    elif 'fh' in hob:
        hob_dict[hob]['group']='flowhead'
    else:
        hob_dict[hob]['group']='head'

# list of observation groups
oglist=['head','flow','div','hdif','flowhead']

#get tpl and ins files
ntpl = 0
nins = 0
tpllist=[]
inslist=[]
for filename in os.listdir(pestdir):
    if filename.endswith('.tpl'):
        tpllist.append(filename)
    if filename.endswith('.ins') and 'ip3' not in filename:
        inslist.append(filename)

#default values for PEST control, can be changed by user
#build PEST control file
#pcf=open('pcf.pst', 'w') #open file for writing
hobwtmult=1.
flobwtmult=1.
with open(os.path.join(pestdir,'pcf.pst'), 'w') as pcf:
    pcf.write('pcf\n')
    pcf.write('* control data\n') #section header
    pcf.write('restart  estimation\n') #RSTFLE and PESTMODE
    pcf.write('{:5d}  {:9d}  {:9d}  {:9d}  {:9d}\n'.format(len(par_dict),len(hob_dict)+len([f for f in flob_dict if '-ip3' not in f])+len([d for d in div_dict if '-ip3' not in d]),len(pglist),0,len(oglist))) #-1 to leave out BC, prior info goes in obs groups, add 'len(uneq)+len(bceq),' in 2nd to last for prior
    pcf.write('{:5d}  {:9d}  {:>9s}  {:>9s}  {:9d}  {:9d}  {:9d}\n'.format(len(tpllist),len(inslist),'single','point',1,0,0))
    pcf.write('{:5d}  {:9d}  {:9.3f}  {:9.3f}  {:9d}\n'.format(10,-3,0.3,0.01,1))   #write rlambda1, rlamfac, phiratsuf, phiredlam, numlam
    pcf.write('{:4.2f}  {:9d}  {:9.3f}\n'.format(0.2,10,0.001))
    pcf.write('{:5.3f}\n'.format(0.1))
    pcf.write('{:5d}  {:9.3f}  {:9d}  {:9d}  {:9.3f}  {:9d}\n'.format(0,0.005,4,3,0.01,3))
    pcf.write('{:5d}  {:9d}  {:9d}\n'.format(0,0,0))
    pcf.write('* singular value decomposition\n') #this is in the example control file but not in the manual
    pcf.write('{:5d}\n'.format(1))
    pcf.write('{:5d}  {:12.1e}\n'.format(len(par_dict),5.0E-7))
    pcf.write('{:5d}\n'.format(0))
    pcf.write('* parameter groups\n')
    for pg in pglist:
        pcf.write('{:5s}  {:>9s}  {:9.3f}  {:12.2e}  {:>9s}  {:9d}  {:>9s}\n'.format(pg,'relative',0.01,0.00001,'switch',2,'parabolic'))
    pcf.write('* parameter data\n')
    for pname in parlist:
        if par_dict[pname]['pargroup']=='BC':
            llim=0.001
            ulim=0.5
            partrans='none'
            parchglim='relative'
        else:
            llim=0.0001
            ulim=1000.0
            partrans='log'
            parchglim='factor'
        pcf.write('{:20s}  {:>9s}  {:>9s}  {:9.4f}  {:9.4f}  {:9.1f}  {:>9s}  {:9d}  {:9d}  {:9d}\n'.format(pname,partrans,parchglim,par_dict[pname]['initval'],llim,ulim,par_dict[pname]['pargroup'],1,0,1))
    pcf.write('* observation groups\n')
    for og in oglist:
        pcf.write('{:10s}\n'.format(og))
##    for pgp in priorgp:
##        pcf.write('{:10s}'.format(pgp))
##        if 'BC' not in pgp: #add covariance matrix from PPCOV utility
##            pcf.write(' {:10s}\n'.format(pgp+'_cov.mat'))
##        else:
##            pcf.write('\n')
    pcf.write('* observation data\n')
    for hob in hob_dict:
        if hob_dict[hob]['hobstd']>0:
            hobwt=(1/hob_dict[hob]['hobstd'])*hobwtmult
        else:
            hobwt=1/10.0 #max std=5, max wt=0.2, weight single obs as 1/2 those with std=5
        pcf.write('{:20s} {:20.7f}  {:20.10f}  {:10s}\n'.format(hob,hob_dict[hob]['hobss'],hobwt,hob_dict[hob]['group']))
    for flob in flob_dict:
        if flob_dict[flob]['sortflow'][1]>0 and '-ip3' not in flob:
            flobwt=(1/(0.1*flob_dict[flob]['sortflow'][1]))*flobwtmult #1 / 10% of flow value
        else:
            flobwt=2.0e-6 #1/5cfs
        pcf.write('{:20s}  {:20.10f}  {:20.10f}  {:6s}\n'.format(flob,flob_dict[flob]['sortflow'][1],flobwt,oglist[1]))
    for div in [d for d in div_dict if '-ip3' not in d]:
        if 'ip-3' not in div:
            if div_dict[div]['sortflow'][1]>0:
                divwt=(1/(0.1*div_dict[div]['sortflow'][1]))*flobwtmult #1 / 10% of flow value
            else:
                divwt=2.0e-6
            pcf.write('{:20s}  {:20.10f}  {:20.10f}  {:6s}\n'.format(div_dict[div]['site'],div_dict[div]['sortflow'][1],divwt,oglist[2]))
    pcf.write('* model command line\n')
    pcf.write('{:9s}\n'.format('CV_process_run.bat'))
    pcf.write('* model input/output\n')
    for tpl in tpllist:
        if 'PP_' in tpl:
            pcf.write('{:20s}    {:20s}\n'.format(tpl,tpl.replace('.tpl','')))
        else: #assume tpl is one directory up
            ofile='..\\'+tpl.replace('.tpl','')
            pcf.write('{:20s}    {:20s}\n'.format(tpl,ofile))
    for ins in inslist:# all results in output folder
        ofile='..\\output\\'+ins.replace('.ins','')
        pcf.write('{:20s}    {:20s}\n'.format(ins,ofile))
##    pcf.write('* prior information\n')
##    for i,ue in enumerate(uneq):
##        rgp=ue[0].split('_')[0]
##        eq='pi_'+str(i)+' 1.0 * log('+ue[0]+') - 1.0 * log('+ue[1]+') = 0 1.0 regul_'+rgp+'\n'
##        pcf.write(eq)
##    for i,bc in enumerate(bceq):
##        eq='pi_BC'+str(i)+' 1.0 * log('+bc+') = '+str(par_dict[bc]['initval'])+' 1.0 regul_BC\n'
##        pcf.write(eq)
##    pcf.write('* regularisation\n')
##    pcf.write('1.0e-5 1.1e-5 0.1\n')
##    pcf.write('0.1 1.0e-10 1.0e10\n')
##    pcf.write('1.3 1.0e-2 1\n')
    pcf.write('''\n++# The following is associated with PEST++ input and
++# is parsed using key words that can be specified in any order
++# MAX_N_SUPER(1) SUPER_EIGTHRES(1.0e-7)
++# N_ITER_BASE(1) N_ITER_SUPER(0)
++# SVD_PACK(PROPACK)
++# AUTO_NORM(4)
++# MAX_SUPER_FRZ_ITER(5) MAX_REG_ITER(3)
++# MAT_INV(JTQJ)
++# SUPER_RELPARMAX(20)
++# MAX_RUN_FAIL(3)
++# LAMBDAS(0.05,0.1,0.5,1,1.5,10)
++# ITERATION_SUMMARY(TRUE)
++# UNCERTAINTY(FALSE)
++# FORECASTS(OneMinusVE)
++# DER_FORGIVE(TRUE)''')






