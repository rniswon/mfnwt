#Read PEST output file with .rec extention
# extract phi and plot

import os
import numpy as np
from matplotlib import pyplot as plt

ddir=r'S:\CarsonValley\PEST runs\CV-wes-9094SS\PEST'
runname=r'pcf_r7_w'

#get residuals
phi=[]
hphi=[]
fphi=[]
divphi=[]
hdphi=[]
fhphi=[]
with open(os.path.join(ddir,runname+'.rec')) as f:
    lines=f.readlines()
    for line in lines:
        if ('Starting phi for this iteration' in line or 'Final phi' in line ) and 'Total' in line: #pest++ syntax
            data=line.strip().split()
            phi.append(float(data[-1]))
        if 'Contribution to phi from observation group' in line and '"head"' in line:
            data=line.strip().split()
            hphi.append(float(data[-1]))
        if 'Contribution to phi from observation group' in line and '"flow"' in line:
            data=line.strip().split()
            fphi.append(float(data[-1]))
        if 'Contribution to phi from observation group' in line and '"div"' in line:
            data=line.strip().split()
            divphi.append(float(data[-1]))
        if 'Contribution to phi from observation group' in line and '"hdif"' in line:
            data=line.strip().split()
            hdphi.append(float(data[-1]))
        if 'Contribution to phi from observation group' in line and '"flowhead"' in line:
            data=line.strip().split()
            fhphi.append(float(data[-1]))

#get pp values
par_dict={}
bc_dict={}
for fn in os.listdir(ddir):
    if '.par' in fn and runname in fn:
        try:
            it=int(fn.split('.par')[1])
            with open(os.path.join(ddir,fn)) as f:
                lines=f.readlines()
            for line in lines[1:]:
                data=line.strip().split()
                if 'p_' in data:
                    group=data[0].split('_')[2]
                    if data[0] not in par_dict:
                        par_dict[data[0]]={}
                        par_dict[data[0]]['it']=[]
                        par_dict[data[0]]['val']=[]
                        par_dict[data[0]]['group']=group
                    par_dict[data[0]]['it'].append(it)
                    par_dict[data[0]]['val'].append(float(data[1]))
                else:
                    group='bc'
                    if data[0] not in par_dict:
                        par_dict[data[0]]={}
                        par_dict[data[0]]['it']=[]
                        par_dict[data[0]]['val']=[]
                        par_dict[data[0]]['group']=group
                    par_dict[data[0]]['it'].append(it)
                    par_dict[data[0]]['val'].append(float(data[1]))
        except:
            print(fn+' is not a parameter iteration file\n')


#get simulate values
sim_dict={}
ob_dict={}
for fn in os.listdir(ddir):
    if '.rei' in fn and runname in fn:
        try:
            it=int(fn.split('.rei')[1])
            with open(os.path.join(ddir,fn)) as f:
                lines=f.readlines()
            for line in lines[4:]:
                data=line.strip().split()
                group=data[1]
                if data[0] not in sim_dict:
                    sim_dict[data[0]]={}
                    sim_dict[data[0]]['it']=[]
                    sim_dict[data[0]]['val']=[]
                    sim_dict[data[0]]['group']=group
                    ob_dict[data[0]]={}
                    ob_dict[data[0]]['it']=[]
                    ob_dict[data[0]]['val']=[]
                    ob_dict[data[0]]['group']=group
                sim_dict[data[0]]['it'].append(it)
                sim_dict[data[0]]['val'].append(float(data[3]))
                ob_dict[data[0]]['it'].append(it)
                ob_dict[data[0]]['val'].append(float(data[2]))
        except:
            print(fn+' is not an observation iteration file\n')
#arrange vals for each iteration for each observation and param
for ob in ob_dict:
    dums=[]
    dumo=[]
    s=sorted(ob_dict[ob]['it'])
    for i in s:
        dex=ob_dict[ob]['it'].index(i)
        dums.append(sim_dict[ob]['val'][dex])
        dumo.append(ob_dict[ob]['val'][dex])
    sim_dict[ob]['val']=dums
    sim_dict[ob]['it']=s
    ob_dict[ob]['val']=dumo
    ob_dict[ob]['it']=s
for par in par_dict:
    dump=[]
    s=sorted(par_dict[par]['it'])
    for i in s:
        dex=par_dict[par]['it'].index(i)
        dump.append(par_dict[par]['val'][dex])
    par_dict[par]['val']=dump
    par_dict[par]['it']=s

###plot simulated obs with iteration
##for ob in sim_dict:
##    if sim_dict[ob]['group']=='head':
##        res=[]
##        for o,r in zip(ob_dict[ob]['val'],sim_dict[ob]['val']):
##            res.append(o-r)
##        plt.plot(sim_dict[ob]['it'],res)
##plt.show()

# plot simulated vs observed
obgroup='head'
for i in range(0,len(ob_dict[ob_dict.keys()[0]]['it'])):
    simlist=[]
    oblist=[]
    reslist=[]
    for ob in ob_dict:
        if ob_dict[ob]['group']==obgroup:
            simlist.append(sim_dict[ob]['val'][i])
            oblist.append(ob_dict[ob]['val'][i])
            reslist.append(sim_dict[ob]['val'][i]-ob_dict[ob]['val'][i])
    mxsmo=max([max(simlist),max(oblist)])
    mnsmo=min([min(simlist),min(oblist)])
    plt.plot(simlist,oblist,'or')
    plt.plot([mnsmo,mxsmo],[mnsmo,mxsmo],'-b')
    plt.title('Simulated vs. Observed '+obgroup+': iteration '+str(i))
    plt.xlabel('Simulated head (ft)')
    plt.ylabel('Observed head (ft)')
    plt.text(mnsmo,mxsmo,'mean residual: '+str(np.mean(reslist))+'\nmax residual: '+str(np.max(reslist)))
    plt.show()

# plot parameter trends for largest params
for par in par_dict:
    if abs(max(par_dict[par]['val'])-min(par_dict[par]['val']))>200*(par_dict[par]['val'][0]):
        plt.plot(par_dict[par]['it'],par_dict[par]['val'])
plt.legend(par_dict.keys())
plt.show()

# report and plot residual with iteration
print('%10s %10s %10s %10s %10s %10s' %('phi total','phi head','phi stream','phi div','phi hdiff','phi fheads'))
for i in range(0,len(phi)):
    print('%10.1f %10.1f %10.1f %10.1f %10.1f %10.1f' %(phi[i],hphi[i],fphi[i],divphi[i],hdphi[i],fhphi[i]))
plt.plot(phi,label='total phi')
plt.plot(hphi,label='phi head')
plt.plot(fphi,label='phi streamflow')
plt.plot(divphi,label='phi diversions')
plt.plot(hdphi,label='phi head differences')
plt.plot(fhphi,label='phi flow heads')
plt.legend()
plt.title('Phi: Carson Valley')
plt.xlabel('iteration')
plt.ylabel('residual')
plt.show()
plt.savefig(os.path.join(ddir,runname+'.png'))