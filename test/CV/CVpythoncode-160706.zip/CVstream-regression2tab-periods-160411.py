# play with stations (xflowID and xprcpID), lag, maybe weights
#removed prcp data due to missing values and crappy regression


# reads in stream flow data from excel file downloaded from NWIS
# reads in precip data from excel file downloaded from NOAA
# list of flowID to find regressions for (endogenous data)
# list of xflowID and xprcpID to use in the regression (exogenous data)
# date formats are different, convert both to 3 tuple
# find all common dates for regression (considers lag)
# use statsmodels to do multivariate ordinary linear regression
# plot measured vs predicted
root=r'S:/'

import os,xlrd,datetime,sys
#from dateutil.relativedelta import relativedelta
import jdcal
import matplotlib.pyplot as plt
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
if 'modules' not in sys.path:
    sys.path.append(os.path.join(root,r'CarsonValley\wespythoncode\modules'))
import tsfunc as ts

effdir = r'S:\CarsonValley\lakes\effluent'
flowdir=r'S:\CarsonValley\flows'
flow_loc = os.path.join(flowdir,'carsonstreamflow\\USGS_streamflow_uppercarson_for_regression.xlsx')

modnam='CV-wes-9094SS'
modir=os.path.join(root,r'CarsonValley\MODFLOW',modnam)
if not os.path.exists(modir):
    os.makedirs(modir)

if 'SS' in modnam:
    period=[(datetime.date(1989,10,1),datetime.date(1994,9,30))]
    tinterval=[period[0][1]-period[0][0]]
elif 'trans' in modnam:
    if 'short' in modnam:
        # stress period information for historicalshort
        period=[(datetime.date(1998,10,1),datetime.date(1999,9,30)),
                (datetime.date(1999,10,1),datetime.date(2013,10,1))]
        tinterval=[period[0][1]-period[0][0],
                    datetime.timedelta(days=7)]
    else:
        # stress period information for historical calibration
        period=[(datetime.date(1981,10,1),datetime.date(1982,9,30)),
                (datetime.date(1982,10,1),datetime.date(1983,9,30)),
                (datetime.date(1983,10,1),datetime.date(1999,10,1))]
        tinterval=[period[0][1]-period[0][0],
                    datetime.timedelta(days=30),
                    datetime.timedelta(days=7)]
elif 'drought' in modnam:
    # Stress period information for megadrought, build tabfiles for PRMS or data driven
    period=[(datetime.date(2010,10,1),datetime.date(2011,9,30)),
            (datetime.date(2011,10,1),datetime.date(2015,10,1)),
            (datetime.date(1986,10,1),datetime.date(1995,10,1))]
    tinterval=[period[0][1]-period[0][0],
                datetime.timedelta(days=7),
                datetime.timedelta(days=7)]
nsp=[]
for per in range(0,len(period)):
    nsp.append((period[per][1]-period[per][0]).days/tinterval[per].days)
sp=[]#period[0][0]] #first date is start of steady state, index 0
for per in range(0,len(period)):
    for dt in range(0,nsp[per]+1):
        sp.append(period[per][0]+datetime.timedelta(days=(dt)*tinterval[per].days))
print('start date: '+str(sp[0])+
    '\nend date: '+str(sp[-1]))
steadyper=period[0][1]-period[0][0]
print('\nsteady-state stress period of: '+str(steadyper.days)+' days'+
    '\nfrom: '+str(sp[0])+' to '+str(sp[1]))
for per in range(0,len(period)):
    print('\nperiod '+str(per+1)+':\n'+str(period[per][0])+' to '+str(period[per][1])+'\n    '+str(nsp[per])+' stress priods of: '+str(tinterval[per].days)+' days\n')
sys.stdout.flush()

#get effluent flows
efflist=['STPUD','DCSID','IVGID']
eff_dict={}
for eff in efflist:
    efffile=os.path.join(effdir,eff,eff+'-effluent.xlsx')
    flowwb=xlrd.open_workbook(efffile) #no need to close with xlrd.open_workbook
    flowsheet=flowwb.sheet_by_name('annual')
    eff_dict[eff]={}
    eff_dict[eff]['name']=str(flowsheet.cell(0,0))
    for c in range(0,flowsheet.ncols):
        if 'year' in flowsheet.col_values(c):
            ydex=flowsheet.col_values(c).index('year')
            recyr=(flowsheet.col_values(c)[ydex+1:flowsheet.nrows])
        if 'total cubic feet' in flowsheet.col_values(c):
            fdex=flowsheet.col_values(c).index('total cubic feet')
            flowann=(flowsheet.col_values(c)[fdex+1:flowsheet.nrows]) #in cubic feet
    #monthly ratios of annual flows
    moyr=[]
    flowrat=[]
    mflowrat=[]
    flowsheet=flowwb.sheet_by_name('mratio')
    for c in range(0,flowsheet.ncols):
        if 'mo\yr' in flowsheet.col_values(c):
            yrdex=flowsheet.col_values(c).index('mo\yr')
    for c in range(0,flowsheet.ncols): #move through columns, along row
        try:
            yr=int(flowsheet.col_values(c)[yrdex])
            for m in range(1,13): #months must be ordered Jan-Dec in col with 'mo/yr'
                moyr.append(datetime.date(yr,m,1))
                flowrat.append(flowsheet.col_values(c)[yrdex+m])
        except:
            if flowsheet.col_values(c)[yrdex]=='Mean': #get mean value for missing data
                for m in range(1,13):
                    mflowrat.append(flowsheet.col_values(c)[yrdex+m])
    #montly effluent
    #calc flows, fill in missing values w average monthly
    for i,s in enumerate(sp):
        for my,fr in zip(moyr,flowrat):
            if my.month==s.month and my.year==s.year:
                fratio=fr
            else:
                fratio=mflowrat[s.month-1] #mflowrat[0]=Jan, s.month=1 if s in Jan
        try: #use value recorded for year if exists
            ydex=recyr.index(s.year)
            flow=flowann[ydex]
        except: #mean annual
            flow=np.mean(flowann)
        if i<=2: #sp[0] gets sp[1] value
            eff_dict[eff]['date']=[period[0][0],period[0][1]]
            eff_dict[eff]['flow']=[flow/365.25,flow/365.25]
        else:
            if s.month==12: #establish next month
                nm=1
                ny=s.year+1
            else:
                nm=s.month+1
                ny=s.year
            mofirst=datetime.date(s.year,s.month,1)
            molast=datetime.date(ny,nm,1)-datetime.timedelta(days=1)
            if mofirst not in eff_dict[eff]['date']:
                eff_dict[eff]['date'].append(mofirst) #first day of month
                eff_dict[eff]['flow'].append(flow*fratio/(molast-mofirst).days)
            if molast not in eff_dict[eff]['date']:
                eff_dict[eff]['date'].append(molast) #last day of month
                eff_dict[eff]['flow'].append(flow*fratio/(molast-mofirst).days)



# Site IDs from NWIS for sites to be predicted
#flowID=['10311200','10310500','10310400','10309025','10310300','10310350']# Ash, Clear, Daggett (first 3 need regression here to support Maurer et al 2005 regression), Fredricksburg, Miller, Indian Creek obsolete since late 1980's
flowID=['10309025',
        '10310350',
        '10310500',
        '10310400',
        '10310300',
        '10310430',
        '10310425',
        '10310415',
        '10310410',
        '10310385',
        '10310380',
        '10310375',
        '10310370',
        '10310360',
        '10310330',
        '10310300']
#exogenous stream flow data used for regression
xflowID=['10309000','10310000'] #EF Carson'10309000',,WF Carson='10310000', all "future scenario" data will rely solely on flow from these streams
#exogenous precip data used for regression

#Carson range streams with regression in Maurer et al: no regression for Miller Springs and Fredricksburg Canyon in Maurer et al 2004, therefore also included in flowID.  Convert from acre-ft/yr to cfd
##cr_dict={'10310430':{'name':'Water Canyon','aveflow':1900*119.263328},
##        '10310425':{'name':'James Canyon','aveflow':1300*119.263328},
##        '10310415':{'name':'Sierra Canyon','aveflow':1500*119.263328},
##        '10310410':{'name':'Genoa Canyon','aveflow':960*119.263328},
##        '10310385':{'name':'Mott Canyon','aveflow':1700*119.263328},
##        '10310380':{'name':'Monument Creek','aveflow':2600*119.263328},
##        '10310375':{'name':'Stutler Canyon','aveflow':450*119.263328},
##        '10310370':{'name':'Sheridan Creek','aveflow':1300*119.263328},
##        '10310360':{'name':'Jobs Canyon','aveflow':1700*119.263328},
##        '10310350':{'name':'Miller Springs','aveflow':632*119.263328},
##        '10310330':{'name':'Luther Creek','aveflow':2200*119.263328},
##        '10310300':{'name':'Fredericksburg Canyon','aveflow':2890*119.263328}} #flows in acre feet per year from Maurer et al 2004
lagper=[0 for xfid in xflowID]
lag=[]
for i in range(0,len(xflowID)):
    lag.append(datetime.timedelta(days=lagper[i]))#,datetime.timedelta(days=0)] #lag for xflowID. len(xflowID) must be <=len(lag), len(lag) maybe > len(xflowID)


##########################################
segin=[]
flow_dict={}
ffail_dict={}
for ID in flowID:
	flow_dict[ID]={}
	flow_dict[ID]['date']=[]
	flow_dict[ID]['flow']=[]
for ID in xflowID:
	flow_dict[ID]={}
	flow_dict[ID]['date']=[]
	flow_dict[ID]['flow']=[]

#get stream flow data from xl worksheet downloaded from NWIS
flowwb=xlrd.open_workbook(flow_loc) #no need to close with xlrd.open_workbook
flowsheet=flowwb.sheet_by_index(0)
dmode=flowwb.datemode

for r in range(flowsheet.nrows):
    for c in range(0,flowsheet.ncols):
        #fdex=3
        #ddex=2
        if flowsheet.cell_value(r,c)=='discharge_va' or flowsheet.cell_value(r,c)=='02_00060_00003': #codes for flow, different data structures
            fdex=c
        if flowsheet.cell_value(r,c)=='measurement_dt' or flowsheet.cell_value(r,c)=='datetime': #codes for dates
            ddex=c
    try: #don't remember why I thought I needed these tries
        ID=str(int(flowsheet.cell_value(r,1))) #int to prevent decimal, str for dict key
    except: ID='pass' #if fail... just move along
    if ID in flowID or ID in xflowID:
        try: #should not append value if flow cannot convert to float, e.g. "99_Ice"
            float(flowsheet.cell_value(r,fdex))
            fdatetup=xlrd.xldate_as_tuple(flowsheet.cell_value(r,ddex),dmode)
            fdate=datetime.date(fdatetup[0],fdatetup[1],fdatetup[2])
            if fdate not in flow_dict[ID]['date']: #ignore second entry, could average if desired
                flow_dict[ID]['date'].append(fdate)
                flow_dict[ID]['flow'].append(flowsheet.cell_value(r,fdex)*86400) #convert immediately
        except:
			if ID not in ffail_dict:
				ffail_dict[ID]={}
				ffail_dict[ID]['date']=[flowsheet.cell_value(r,ddex)]
				ffail_dict[ID]['flow']=[flowsheet.cell_value(r,fdex)*86400] #convert immediately
			else:
				ffail_dict[ID]['date'].append(flowsheet.cell_value(r,ddex))
				ffail_dict[ID]['flow'].append(flowsheet.cell_value(r,fdex)*86400) #convert immediately

# get stream flow site names
hrows=0 #header rows counter
line=flowsheet.cell_value(hrows,0)
while 'Data for the following' not in line:
	hrows=hrows+1
	line=flowsheet.cell_value(hrows,0)
sites=int(line.split()[5]) #number of sites listed in [5] th string
for r in range(hrows+1,hrows+sites+1):
	for ID in flowID:
		if '#' in flowsheet.cell_value(r,0) and str(ID) in flowsheet.cell_value(r,0):
			print(flowsheet.cell_value(r,0)+': '+str(len(flow_dict[ID]['flow']))+' endogenous data values')
			name=flowsheet.cell_value(r,0).split()
			flow_dict[ID]['name']=' '.join(name[3:len(name)])
			if ID in ffail_dict:
				ffail_dict[ID]['name']=' '.join(name[3:len(name)])
	for ID in xflowID:
		if '#' in flowsheet.cell_value(r,0) and str(ID) in flowsheet.cell_value(r,0):
			print(flowsheet.cell_value(r,0)+': '+str(len(flow_dict[ID]['flow']))+' exogenous data values')
			name=flowsheet.cell_value(r,0).split()
			flow_dict[ID]['name']=' '.join(name[3:len(name)])
			if ID in ffail_dict:
				ffail_dict[ID]['name']=' '.join(name[3:len(name)])

#################################################

################################
regmeth='params' #full or params
if regmeth=='full':
    # get common dates (consider lag) for exogenous data sets, use in calculation of endo
    # consider possibility of lag
    if max(lagper)>0:
        for i,xfid in enumerate(xflowID):
            flow_dict[xfid]['lagdate']=[flow_dict[xfid]['date'][d]-lag[i] for d in range(lagper[i],len(flow_dict[xfid]['date']))]
    else:
        for i,xfid in enumerate(xflowID):
            flow_dict[xfid]['lagdate']=flow_dict[xfid]['date']

    comdate={}
    for yid in flowID:
        comdate[yid]=[]
    for i,yid in enumerate(flowID):
        if comdate[yid]==[]:
            comdate[yid]=flow_dict[yid]['date']
        #else:
        #    comdate[yid]=set(comdate[yid]).intersection(flow_dict[yid]['date'])
        for i,xfid in enumerate(xflowID):
            comdate[yid]=set(comdate[yid]).intersection(flow_dict[xfid]['lagdate']) #lagdate common with comdate from precip and previously determined (lagged) flows

        comdate[yid]=list(comdate[yid])
        comdate[yid].sort() #above scrambles the order
        print(str(len(comdate[yid]))+' common dates for '+flow_dict[yid]['name']+': '+yid+' '+str(min(comdate[yid]))+' to '+str(max(comdate[yid])))

    #remove 1997 rain on snow event for regression
    for yid in flowID:
        try:
    	   oldex=comdate[yid].index(datetime.date(1997,01,01)) #index of outlier
    	   comdate[yid].pop(oldex)
        except:pass

    ####################################
    reg_dict={}
    for yid in flowID: #set up dictionary for dates and values specifically used in regression
        print('processing '+flow_dict[yid]['name'])
        if yid not in xflowID: #no regression for exogenous variables
            reg_dict[yid]={}
            reg_dict[yid]['eflow']=[f for f,d in zip(flow_dict[yid]['flow'],flow_dict[yid]['date']) if d in comdate[yid]]
            for xfid in xflowID:
                reg_dict[yid][xfid]={}
                reg_dict[yid][xfid]['xflow']=[f for f,d in zip(flow_dict[xfid]['flow'],flow_dict[xfid]['date']) if d in comdate[yid]]
    for yid in flowID: #regression for flows listed in flowID
        print('regression for '+flow_dict[yid]['name'])
        if yid not in xflowID: #no regression for exogenous variables
            X=np.ones(len(reg_dict[yid][xflowID[0]]['xflow'])) #constants added first
            for xfid in xflowID:
                X=np.r_['0,2',X,reg_dict[yid][xfid]['xflow']]
            X=np.array(X).T
            y=np.array(reg_dict[yid]['eflow']).T #better fit without log transformation?
            Xlog=np.log10(X)
            ylog=np.log10(y)
            reg_dict[yid]['results']=sm.OLS(endog=ylog,exog=Xlog).fit()
            flow_dict[yid]['simflow']=10**reg_dict[yid]['results'].predict() #only for comdate in regression, in cfs

    #Write regression results (parameters) to file
    regspace = r'S:\CarsonValley\flows\carsonstreamflow\regression\params'
    params={}
    #make sure workspace directory exists
    if not os.path.exists(regspace):
        os.makedirs(regspace)
    for yid in flowID:
        regname=os.path.join(regspace,'CV-regression-'+str(yid)+'-'+str(flow_dict[yid]['name'])+'.txt')
        params[yid]=reg_dict[yid]['results'].params
        with open (regname,'w+') as regfile:
            regfile.write('#Regression results for '+flow_dict[yid]['name']+' '+str(yid)+' using exogenic data:\n')
            regfile.write('#Parameters are in the following order:\n\n#CONSTANTS\n')
            for xfid in xflowID:
                regfile.write('#'+flow_dict[xfid]['name']+str(xfid)+'\n')
            for i in range(0,len(params[yid])):
                regfile.write(str(params[yid][i])+',')
elif regmeth=='params':
    # get regression results from file
    params={}
    regspace = r'S:\CarsonValley\flows\carsonstreamflow\regression\params'
    for yid in flowID:
        regname=os.path.join(regspace,'CV-regression-'+str(yid)+'-'+str(flow_dict[yid]['name'])+'.txt')
        with open (regname,'r') as regfile:
            while True:
                line=regfile.readline()
                data=line.split(',')
                if not line: break
                if '#' not in data and len(data)>0:
                    params[yid]=data



# Calculate regressed flows for all dates contained in exogenic dataset
xcomdate=flow_dict[xflowID[0]]['date']
for i,xfid in enumerate(xflowID[1:]):
    xcomdate=set(xcomdate).intersection(flow_dict[xfid]['date'])
    xcomdate=list(xcomdate)
    xcomdate.sort() #above scrambles the order
    print(str(len(xcomdate))+' common dates used for regression to generate TSPROC files\n')
#calculate endo
for fid in flowID+xflowID:
    print('calculating values for :'+str(fid)+'\n')
    if fid in flowID:
        flow_dict[fid]['fcomment']='values from linear regression using sites '+', '.join(i for i in xflowID)+' with coefficients'+', '.join(str(i) for i in params[fid][1:])
        flow_dict[fid]['regflow']=[]
        flow_dict[fid]['regdate']=[]
        for date in xcomdate: #common simulation day shared by all exo, don't calculate if no common exo date
            xdex=[flow_dict[xfid]['date'].index(date) for xfid in xflowID]
            xflow=[flow_dict[xfid]['flow'][xdex[i]] for i,xfid in enumerate(xflowID)]
            #expand if necessary to accomodate n exo and n+1 params, constants first
            flow_dict[fid]['regflow'].append(10**(float(params[fid][0])+float(params[fid][1])*np.log10(xflow[0])+float(params[fid][2])*np.log10(xflow[1])))
            flow_dict[fid]['regdate'].append(date)
    elif fid in xflowID:
        flow_dict[fid]['fcomment']='data from NWIS'
        flow_dict[fid]['regflow']=flow_dict[fid]['flow']
        flow_dict[fid]['regdate']=flow_dict[fid]['date']
#writes entire data set to TSPROC file for use with any period in range
#ts.dic2ssf(flow_dict,os.path.join(flowdir,'TSPROC',modnam+'-regression.ssf'),flowkey='regflow',datekey='regdate',suffix='-regression')
#ts.dic2ssf(flow_dict,os.path.join(flowdir,'TSPROC',modnam+'.ssf'),flowkey='flow',datekey='date')
# xflowID give warning that no flowkey named "regflow" exists since no regression


###Calculate tabfile information
###populate exogenic for each day for each record in exo
##for xfid in xflowID: #exo, assume data exists in sim period
##    flow_dict[xfid]['dataflow']=[]
##    flow_dict[xfid]['simflow']=[]
##    flow_dict[xfid]['simdate']=[]
##    for date,flow in zip(flow_dict[xfid]['date'],flow_dict[xfid]['flow']):
##        flow_dict[xfid]['dataflow'].append(flow) #same value for exogenic
##        flow_dict[xfid]['simflow'].append(flow) #same value for exogenic
##        flow_dict[xfid]['simdate'].append(date)
###find simulation days common to all exo data
##xcomdate=flow_dict[xflowID[0]]['simdate']
##for i,xfid in enumerate(xflowID[1:]):
##    xcomdate=set(xcomdate).intersection(flow_dict[xfid]['simdate'])
##    xcomdate=list(xcomdate)
##    xcomdate.sort() #above scrambles the order
##    print(str(len(xcomdate))+' common dates for all exogenic data in simulation\n')
###calculate endo
##for fid in flowID:
##    flow_dict[fid]['simflow']=[]
##    flow_dict[fid]['simdate']=[]
##    for d,simdate in enumerate(xcomdate): #common simulation day shared by all exo, don't calculate if no common exo date
##        xdex=[flow_dict[xfid]['simdate'].index(simdate) for xfid in xflowID]
##        xflow=[flow_dict[xfid]['dataflow'][xdex[i]] for i,xfid in enumerate(xflowID)]
##        #expand if necessary to accomodate n exo and n+1 params, constants first
##        flow_dict[fid]['simflow'].append(10**(float(params[fid][0])+float(params[fid][1])*np.log10(xflow[0])+float(params[fid][2])*np.log10(xflow[1])))
##        flow_dict[fid]['simdate'].append(simdate)

#convert dictionary ts to period averages
print('converting to period averages\n')
ts.ts2period(flow_dict,sp,period,datekey='regdate',flowkey='regflow')
ts.ts2period(eff_dict,sp,period,datekey='date',flowkey='flow')

#get simulation days based on periods
print('getting simulation days\n')
ts.simdays(flow_dict,sp,period,tinterval,datekey='sortdate')
ts.simdays(eff_dict,sp,period,tinterval)

#add simday d.01 after day d, copy next flow value
#ts.add01(flow_dict,[1])

#write files for all flows
indir=os.path.join(modir,'intabs')
if not os.path.exists(indir):
    os.makedirs(indir)
for fid in flow_dict:
    if True in np.isnan(flow_dict[fid]['sortflow']): #use annual average is any values in sortflow are nan
        print('no regression available, writing annual average tabfiles for :'+str(fid)+'\n')
        tabname=os.path.join(indir,'CV-regression-stream-'+str(fid)+'-'+str(flow_dict[fid]['name'].replace(' ','').replace(',',''))+'-'+str(sp[0]).translate(None,'-')+'-'+str(sp[-1]).translate(None,'-')+'.txt')
        with open(tabname,'w+') as tabfile:
            for simday,date in zip(flow_dict[fid]['simday'],flow_dict[fid]['sortdate']):
                line=(simday,np.mean(flow_dict[fid]['flow']),'    # '+str(date)+' avearage annual value, regression had nan\n')
                tabfile.write('%s  %12.2f %s' %line)
    else:
        print('writing regression tabfiles for :'+str(fid)+'\n')
        if fid!='10310350': # not Miller Springs
            tabname=os.path.join(indir,'CV-regression-stream-'+str(fid)+'-'+str(flow_dict[fid]['name'].replace(' ','').replace(',',''))+'-'+str(sp[0]).translate(None,'-')+'-'+str(sp[-1]).translate(None,'-')+'.txt')
            with open(tabname,'w+') as tabfile:
                for simday,date,flow in zip(flow_dict[fid]['simday'],flow_dict[fid]['sortdate'],flow_dict[fid]['sortflow']):
                    line=(simday,flow,'    # '+str(date)+'\n')
                    tabfile.write('%s  %12.2f %s' %line)
        else: #Miller Springs, split flow into N and S channels
            tabname=os.path.join(indir,'CV-regression-stream-'+str(fid)+'N-'+str(flow_dict[fid]['name'].replace(' ','').replace(',',''))+'-'+str(sp[0]).translate(None,'-')+'-'+str(sp[-1]).translate(None,'-')+'.txt')
            with open(tabname,'w+') as tabfile:
                for simday,date,flow in zip(flow_dict[fid]['simday'],flow_dict[fid]['sortdate'],flow_dict[fid]['sortflow']):
                    line=(simday,flow/2,'    # '+str(date)+'\n')
                    tabfile.write('%s  %12.2f %s' %line)
            tabname=os.path.join(indir,'CV-regression-stream-'+str(fid)+'S-'+str(flow_dict[fid]['name'].replace(' ','').replace(',',''))+'-'+str(sp[0]).translate(None,'-')+'-'+str(sp[-1]).translate(None,'-')+'.txt')
            with open(tabname,'w+') as tabfile:
                for simday,date,flow in zip(flow_dict[fid]['simday'],flow_dict[fid]['sortdate'],flow_dict[fid]['sortflow']):
                    line=(simday,flow/2,'    # '+str(date)+'\n')
                    tabfile.write('%s  %12.2f %s' %line)
for fid in eff_dict:
    tabname=os.path.join(indir,'CV-effluent-'+'-'+str(fid)+'-'+str(sp[0]).translate(None,'-')+'-'+str(sp[-1]).translate(None,'-')+'.txt')
    with open(tabname,'w+') as tabfile:
        for simday,date,flow in zip(eff_dict[fid]['simday'],eff_dict[fid]['date'],eff_dict[fid]['flow']):
            line=(simday,flow,'    # '+str(date)+'\n')
            tabfile.write('%s  %12.2f %s' %line)


#make pretty pictures
##for i,yid in enumerate(flow_dict):
##    if yid not in xflowID:
##        plt.plot(flow_dict[yid]['date'], flow_dict[yid]['flow'],'-b')
##        plt.plot(sort_dict[yid]['simdate'], sort_dict[yid]['simflow'],'+-r')
##        plt.legend(['flow data','OLS model'])
##        plt.title(flow_dict[yid]['name'])
##        plt.xlabel('date')
##        plt.ylabel('stream flow (cfs)')
##        plt.show()
#print summary
##for fid in flow_dict:
##    flow_dict[fid]['spdata']=[]
##    flow_dict[fid]['spsim']=[]
##    flow_dict[fid]['perr']=[]
##for i in range(1,len(sp)): #only those dates for which regression was valid (i.e. all exo data existed)
##    for fid in flow_dict:
##        spflow=np.mean([flow for date,flow in zip(flow_dict[fid]['simdate'],flow_dict[fid]['simflow']) if sp[i-1]<date<=sp[i]])
##        flow_dict[fid]['spsim'].append(spflow)
##        spdata=np.mean([flow for date,flow in zip(flow_dict[fid]['date'],flow_dict[fid]['flow']) if sp[i-1]<date<=sp[i]])
##        flow_dict[fid]['spdata'].append(spdata)
##        perr=100*(spflow-spdata)/spdata
##        flow_dict[fid]['perr'].append(perr)
##
##for i in range(1,len(sp)):
##    header=('stress period '+str(i)+ ' ending '+str(sp[i]),'   Name         Regression      Data       Percent error\n')
##    print('%s  %60s' %header)
##    for fid in flow_dict:
##        vals=(flow_dict[fid]['name'],flow_dict[fid]['spsim'][i],flow_dict[fid]['spdata'][i],flow_dict[fid]['perr'][i])
##        print('%50s %12.2f %12.2f %12.2f' %vals)