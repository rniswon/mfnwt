# Read FWM records from tabular .asc files.
# Read monthly average information from Unger Table
# Use monthly average when daily/weekly data is missing
# Create tabfiles for SFR input
root=r'S:/'

import datetime, os, shutil, sys, xlrd, calendar
import numpy as np
import statsmodels.api as sm
if 'modules' not in sys.path:
    sys.path.append(os.path.join(root,r'CarsonValley\wespythoncode\modules'))
import tsfunc as ts

sflow=5 #assumed minimum stock water flow when S found in column, in cfs
ereport=False

modnam='CV-wes-8194trans'
modir=os.path.join(root,r'CarsonValley\MODFLOW',modnam)
if not os.path.exists(modir):
    os.makedirs(modir)

if 'SS' in modnam:
    period=[(datetime.date(1989,10,1),datetime.date(1994,9,30))]
    tinterval=[period[0][1]-period[0][0]]
elif 'trans' in modnam:
    if 'short' in modnam:
        # stress period information for historicalshort
        period=[(datetime.date(1998,10,1),datetime.date(1999,9,30)),
                (datetime.date(1999,10,1),datetime.date(2013,10,1))]
        tinterval=[period[0][1]-period[0][0],
                    datetime.timedelta(days=7)]
    else:
        # stress period information for historical calibration
        period=[(datetime.date(1980,10,1),datetime.date(1982,9,30)),
                (datetime.date(1982,10,1),datetime.date(1983,9,30)),
                (datetime.date(1983,10,1),datetime.date(1994,10,1))]
        tinterval=[period[0][1]-period[0][0],
                    datetime.timedelta(days=30),
                    datetime.timedelta(days=7)]
elif 'drought' in modnam:
    # Stress period information for megadrought, build tabfiles for PRMS or data driven
    period=[(datetime.date(2010,10,1),datetime.date(2011,9,30)),
            (datetime.date(2011,10,1),datetime.date(2015,10,1)),
            (datetime.date(1986,10,1),datetime.date(1995,10,1))]
    tinterval=[period[0][1]-period[0][0],
                datetime.timedelta(days=7),
                datetime.timedelta(days=7)]
nsp=[]
for per in range(0,len(period)):
    nsp.append((period[per][1]-period[per][0]).days/tinterval[per].days)
sp=[]#period[0][0]] #first date is start of steady state, index 0
for per in range(0,len(period)):
    for dt in range(0,nsp[per]+1):
        sp.append(period[per][0]+datetime.timedelta(days=(dt)*tinterval[per].days))
print('start date: '+str(sp[0])+
    '\nend date: '+str(sp[-1]))
steadyper=period[0][1]-period[0][0]
print('\nsteady-state stress period of: '+str(steadyper.days)+' days'+
    '\nfrom: '+str(sp[0])+' to '+str(sp[1]))
for per in range(0,len(period)):
    print('\nperiod '+str(per+1)+':\n'+str(period[per][0])+' to '+str(period[per][1])+'\n    '+str(nsp[per])+' stress priods of: '+str(tinterval[per].days)+' days\n')
sys.stdout.flush()

FWMloc = root+r'CarsonValley\flows\FWM-records\00asc'
diversions=os.listdir(FWMloc)

# get estimated values for major ungaged from Unger
ungaged_dict={}
f=root+r'CarsonValley\flows\FWM-records\ungaged\ungaged.xls'
flowwb=xlrd.open_workbook(f) #no need to close with xlrd.open_workbook
flowsheet=flowwb.sheet_by_index(0)
for r in range(1,flowsheet.nrows):
    if '*' not in flowsheet.row_values(r)[0] and '#' not in flowsheet.row_values(r)[0] and flowsheet.row_values(r)[0]!='':
        ungaged_dict[str(flowsheet.row_values(r)[0])]=flowsheet.row_values(r)[2]

# get monthly mean flows from Unger
# assumes flowsheet.row_values(1) contains months Mar-Oct (other values = 0)
# and year is contained in first column
unger_dict={}
for div in diversions:
    unger_dict[div]={}
    mdex=[]
    records=os.listdir(FWMloc+'\\'+div)
    for rec in records:
        if 'xls' in rec and 'unger' in rec: # unger data
            try:
                f=FWMloc+'\\'+div+'\\'+rec
                flowwb=xlrd.open_workbook(f) #no need to close with xlrd.open_workbook
                flowsheet=flowwb.sheet_by_index(0)
                dmode=flowwb.datemode
                for r in range(flowsheet.nrows):
                    try:
                        year=int(flowsheet.row_values(r)[0])
                        unger_dict[div][year]=[0 for i in range(0,12)] #zeros for Jan, Feb, Nov, Dec
                        for c in range(1,9): #columns for mar-oct only
                            if flowsheet.row_values(r)[c] =='': #blank values
                                unger_dict[div][year][c+1]=0 #c+1 to line march (c=1) up with unger_dict[div][year][2], zero indexing
                            else:
                                unger_dict[div][year][c+1]=flowsheet.row_values(r)[c]
                    except: pass
            except: print('error opening '+f)

# Get diversion information from ascii files
div_dict={}
for div in diversions:
    div_dict[div]={} #use folder name
    div_dict[div]['site']=''
    div_dict[div]['flow']=[]
    div_dict[div]['date']=[]
    div_dict[div]['comment']=''
    data=''
    records=os.listdir(FWMloc+'\\'+div)
    for i,rec in enumerate(records):
        if '.asc' in rec:
            fpre=(rec.split('.')[0].lower())
            site=fpre.split('-')[0]
            fyear=fpre.split('-')[1]
            with open(FWMloc+'\\'+div+'\\'+rec) as f:
                #print('processing '+div+' for year '+str(fyear))
                dex=[]
                w=[]
                fstats=os.stat(FWMloc+'\\'+div+'\\'+rec)
                if fstats.st_size > 4000 and fstats.st_size < 10000: #avoid no data files or combined files
                    while '-----------' not in data:
                        data=f.readline().lower()
                        if site in data and div_dict[div]['site']=='':
                            div_dict[div]['site']=site
                        if 'discharge' in data: #assume this contains year
                            for b in data.split():
                                try:
                                    tyear=int(b)
                                except:
                                    tyear=0
                        if 'day' in data and 'apr' in data and 'oct' in data: #assume proper line is captured by these entries
                            for c in data.split(): #get index of each column
                                dex.append(data.index(c))
                            if len(dex)<12 and ereport==True:
                                print('error reading month index')
                                sys.exit()
                            for c in range(0,len(dex)): #determine width of column
                                w.append(dex[c]-dex[c-1])

                    while 'total' not in data:
                        data=f.readline().lower()
                        day=''
                        try:
                            day=int(data[0:dex[0]+w[c]/2])
                        except:
                            if len(day.strip())>0 and ereport==True:
                                print('cannot convert day '+str(data[startdex:enddex])+' to int')
                            day=''
                        for c in range(1,len(dex)): #get flow values, month = index c
                            startdex=dex[c]-w[c]/2
                            enddex=np.min([dex[c]+w[c]/2,len(data)])
                            try:
                                d8=datetime.date(tyear,c,day)
                            except:
                                if ereport==True and (type(day)==int or len(day.strip())>0):
                                    print('cannot convert '+str(tyear)+' '+str(c)+' '+str(day)+' to date')
                                d8=''
                            if 's' not in data[startdex:enddex]:
                                try:
                                    val=float(data[startdex:enddex].translate(None,',').translate(None,'e')) #text within plus or minus width/2
                                except:
                                    if len(data[startdex:enddex].strip())>0 and ereport==True:
                                        print('cannot convert value '+str(data[startdex:enddex])+' to float')
                                    val=''
                            else:
                                try:
                                    val=float(data[startdex:enddex].strip('s').strip().translate(None,','))
                                except:
                                    val=sflow
                            if d8!='' and val!='' and d8 not in div_dict[div]['date']:
                                div_dict[div]['flow'].append(val)
                                div_dict[div]['date'].append(d8)
                            #else:
                                #print('parsing failed')

# calculate average monthly diversion rate from data
mm_dict={}
for div in div_dict:
    mm_dict[div]=[]
    for mo in range(1,13): #months
        modiv=[]
        for date,flow in zip(div_dict[div]['date'],div_dict[div]['flow']):
            if date.month==mo:
                modiv.append(flow)
        if len(modiv)>0:
            mm_dict[div].append(np.mean(modiv))
        else:
            mm_dict[div].append(0)

# append monthly averages (Unger or data) where no data exists for that month, or 0 for sp
print('appending monthly averages where needed\n')
for div in div_dict:
    modate=[]
    moflow=[]
    for divyear in range(sp[0].year,sp[-1].year+1): #+1 for zero indexing
        for divmo in range(1,13): #divmo is month (Jan=1), divmo-1 is index for dicts
            lastday=calendar.monthrange(divyear,divmo)[1] #calendar.monthrange(year,month) returns (weekday of first day, number of days in month)
            rdate=[]
            for d in div_dict[div]['date']:
                if divyear==d.year and divmo==d.month: #month has records for that year
                    rdate.append(d)

            if len(rdate)==0: #no record for month
                modate.append(datetime.date(divyear,divmo,1)) #first day of the month
                modate.append(datetime.date(divyear,divmo,lastday)) #last day of the month
                if 4<=divmo<=10: #append monthly means
                    if divyear in unger_dict[div]: #append Unger mean
                        moflow.append(unger_dict[div][divyear][divmo-1]) #value for first day
                        moflow.append(unger_dict[div][divyear][divmo-1]) #value for last day
                    else: #append calculated monthly mean if no other option
                        moflow.append(mm_dict[div][divmo-1]) #value for first day
                        moflow.append(mm_dict[div][divmo-1]) #value for last day
                else: #append 0 flow for Nov-March
                    moflow.append(0) #value for first day
                    moflow.append(0) #value for last day
            else: #records in that month
                if divmo<=3: #make value before first record 0 if March or earlier
                    modate.append(np.min(rdate)-datetime.timedelta(days=1))
                    moflow.append(0)
                elif divmo>=10: #make value after last record 0 if Oct or later
                    modate.append(np.max(rdate)+datetime.timedelta(days=1))
                    moflow.append(0)
    div_dict[div]['date']=modate+div_dict[div]['date']
    div_dict[div]['flow']=moflow+div_dict[div]['flow']

# add in ungaged diversions
print('adding ungaged diversions\n')
for udiv in ungaged_dict:
    if '-' in udiv:
        uname=udiv.split('-')[0] #drops -spring or -winter
    else:
        uname=udiv
    div_dict[uname]={}
    div_dict[uname]['site']=uname
    div_dict[uname]['date']=[]
    div_dict[uname]['flow']=[]
    div_dict[uname]['comment']=''
    if uname=='mldiv': #rates for winter and summer fillings of Mud Lake
        simyears=list(set([s for s in range(sp[0].year,sp[1].year+1)])) #gets unique years
        for year in simyears:
                div_dict[uname]['date'].append(datetime.date(year,9,30))
                div_dict[uname]['flow'].append(0)
                div_dict[uname]['date'].append(datetime.date(year,10,1))
                div_dict[uname]['flow'].append(ungaged_dict['mldiv-winter'])
                div_dict[uname]['date'].append(datetime.date(year,3,31))
                div_dict[uname]['flow'].append(ungaged_dict['mldiv-winter'])
                div_dict[uname]['date'].append(datetime.date(year,4,1))
                div_dict[uname]['flow'].append(ungaged_dict['mldiv-spring'])
                div_dict[uname]['date'].append(datetime.date(year,4,30))
                div_dict[uname]['flow'].append(ungaged_dict['mldiv-spring'])
                div_dict[uname]['date'].append(datetime.date(year,5,1))
                div_dict[uname]['flow'].append(0)
                div_dict[uname]['date'].append(datetime.date(year,9,30))
                div_dict[uname]['flow'].append(0)
    else:
        for d,f in zip(div_dict['Allerman-c82']['date'],div_dict['Allerman-c82']['flow']):#river on regulation when EF=200cfs, Allerman=1/3 * EF during reglulation
            if f>200/3.: #river not on regulation, use estimate from unger
                div_dict[uname]['flow'].append(ungaged_dict[uname])
                div_dict[uname]['date'].append(d)
            else: #river on regulation, no diversions for these
                div_dict[uname]['date'].append(d)
                div_dict[uname]['flow'].append(0)

#convert flow from cfs to cfd
for div in div_dict:
    div_dict[div]['flow']=[f*86400 for f in div_dict[div]['flow']]

#calculate new data based on periods
print('converting to stress period\n')
ts.ts2period(div_dict,sp,period)

#get simulation days based on periods
ts.simdays(div_dict,sp,period,tinterval,datekey='sortdate')

mlconvey=1*86400*46000./5280 #Estimated 1 cubic feet per second per mile over 46,000 feet, Maurer et al 2006 p42
# Mud Lake flows coming through Indian Creek, 1879 rights appear to be ones going through IC=789 AFA, take everything available iprior=0, flow=1e20 in main
# Snowshoe2 diversion, poor records, intermittently used, more likely that water goes to ML than SS2, iprior=-3 in model, 1909 rights appear to go through SS, 2383 AFA
div_dict['c76b-ip3']={}
div_dict['c76b-ip3']['site']='c76b-ip3'
div_dict['c76b-ip3']['simday']=div_dict['mldiv']['simday']
div_dict['c76b-ip3']['sortdate']=div_dict['mldiv']['sortdate']
div_dict['c76b-ip3']['sortflow']=[f+mlconvey for f in div_dict['mldiv']['sortflow']]
div_dict['c76b-ip3']['comment']='iprior=-3 flow=Mud Lake diversion record plus '+str(mlconvey)+' to account for conveyance losses from SS2 to ML'

# copy ML diversion amount to ML outflow
div_dict['mlout']=div_dict['mldiv'].copy()
div_dict['mlout']['site']='mlout'
div_dict['mlout']['comment']='copy of ML diversion rates defined by Alpine Decree'

#write tab files
print('writing')
writeloc = os.path.join(modir,'divtabs')
if not os.path.exists(writeloc):
    os.makedirs(writeloc)
for div in div_dict:
    with open(os.path.join(writeloc,'CV-wes-diversions-'+div_dict[div]['site']+'-'+str(sp[0]).translate(None,'-')+'-'+str(sp[-1]).translate(None,'-')+'.txt'),'w+') as tabfile:
        for simday,date,flow in zip(div_dict[div]['simday'],div_dict[div]['sortdate'],div_dict[div]['sortflow']):
            if simday==0:
                com=div_dict[div]['comment']
            else:
                com=''
            line=(simday,flow,'    # '+str(date)+' '+str(com)+'\n')
            tabfile.write('%s  %12.2f %s' %line)

#write key
divsort=sorted(d for d in div_dict)
with open(writeloc+'\\'+'CV-wes-diversions-key.txt','w+') as keyfile:
    for div in divsort:
        keyfile.write(div+'\n')
